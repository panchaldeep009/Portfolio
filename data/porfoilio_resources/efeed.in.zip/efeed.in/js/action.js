﻿function acptreq(id,og,tg){
	var a = og;
	if(a == 3){
		$.get('cont_src/act.php?acreq='+id+'&acreqtyp=3');
		document.getElementById(tg).innerHTML = 
		'<div class="btn-group" id="req_btn">'
		+'<button class="btn btn-success btn-sm dropdown-toggle" data-toggle="dropdown" type="button"><i class="fa fa-check"></i> Classmates </button>'
		+'<ul class="dropdown-menu" role="menu">'
        +'    <li onclick="del_rel(\''+id+'\',\'req_btn\',\'3\')"><a><i class="fa fa-times"></i> Remove from Classmates</a></li>'
        +'</ul>'
		+'</div>';
	} else if(a == 2){
		$.get('cont_src/act.php?acreq='+id+'&acreqtyp=2');
		document.getElementById(tg).innerHTML = 
		'<div class="btn-group" id="req_btn">'
		+'<button class="btn btn-success btn-sm dropdown-toggle" data-toggle="dropdown" type="button"><i class="fa fa-check"></i> In Family </button>'
		+'<ul class="dropdown-menu" role="menu">'
        +'    <li onclick="del_rel(\''+id+'\',\'req_btn\',\'2\')"><a><i class="fa fa-times"></i> Remove from in Family</a></li>'
        +'</ul>'
		+'</div>';
	} else {
		$.get('cont_src/act.php?acreq='+id+'&acreqtyp=1');
		document.getElementById(tg).innerHTML = 
		'<div class="btn-group" id="req_btn">'
		+'<button class="btn btn-success btn-sm dropdown-toggle" data-toggle="dropdown" type="button"><i class="fa fa-check"></i> Friends </button>'
		+'<ul class="dropdown-menu" role="menu">'
        +'    <li onclick="del_rel(\''+id+'\',\'req_btn\',\'2\')"><a><i class="fa fa-times"></i> Remove from Friend</a></li>'
        +'</ul>'
		+'</div>';
	}
}
function regreq(id,tg){
	$.get('cont_src/act.php?regreq='+id);
	document.getElementById(tg).innerHTML = 
	'<div class="btn-group" id="req_btn">'
	+'	<button class="btn btn-success btn-sm dropdown-toggle" data-toggle="dropdown" type="button"><i class="fa fa-plus"></i> Request For</button>'
	+'	<ul class="dropdown-menu" role="menu">'
    +'        <li onclick="send_req(\'124354\',\'req_btn\',\''+id+'\')"><a> Friend </a></li>'
    +'        <li class="divider"></li>'
    +'        <li onclick="send_req(\'146626\,\req_btn\',\''+id+'\')"><a> Classmate </a></li>'
	+'		<li onclick="send_req(\'136636\',\'req_btn\',\''+id+'\')"><a> In Family </a></li>'
    +'    </ul>'
	+'</div>';
}
function frosend(div,btn,id){
	document.getElementById(btn).disabled = true;
	document.getElementById(div).style.display = "block";
	document.getElementById(div).innerHTML = 
	'<div class="input-group col-lg-4" align="left">'
	+'	<select id="req_typ" class="form-control">'
    +'         <option value="146646" >Friend</option>'
    +'         <option value="146636" >In Family</option>'
    +'         <option value="146626" >Classmate</option>'
    +'     </select>'
	+'	<span class="input-group-addon"><i class="fa fa-plus"></i></span>'
	+'	<button class="btn btn-success btn-flat" type="button" onclick="send_req(\'req_typ\',\'req_btn\','+id+')">Send <i class="fa fa-arrow-right"></i></button>'
	+'</div>';
}
function send_req(opt,tg,id){
	var a = opt;
	if(a == '146626'){
		$.get('cont_src/act.php?sreq='+id+'&sreqtyp=3');
		document.getElementById(tg).innerHTML = 
		 '<button class="btn btn-success btn-sm dropdown-toggle" data-toggle="dropdown" type="button"><i class="fa fa-check"></i> <span class="badge bg-yellow">Classmate</span> Request Sent</button>'
		+'	<ul class="dropdown-menu" role="menu">'
        +'       <li onclick="can_req('+id+',\'req_btn\')"><a><i class="fa fa-times"></i> Cancel Request </a></li>'
        +'       <li class="divider"></li>'
        +'       <li onclick="sw_req(\'126626\',\'3\',\'req_btn\','+id+')"><a>Switch to Friend Request</a></li>'
		+'		<li onclick="sw_req(\'136636\',\'3\',\'req_btn\','+id+')"><a>Switch to In Family Request</a></li>'
        +'   </ul>';
	} else if(a == '136636'){
		$.get('cont_src/act.php?sreq='+id+'&sreqtyp=2');
		document.getElementById(tg).innerHTML = 
		 '<button class="btn btn-success btn-sm dropdown-toggle" data-toggle="dropdown" type="button"><i class="fa fa-check"></i> <span class="badge bg-yellow">In Family</span> Request Sent</button>'
		+'	<ul class="dropdown-menu" role="menu">'
        +'       <li onclick="can_req('+id+',\'req_btn\')"><a><i class="fa fa-times"></i> Cancel Request </a></li>'
        +'       <li class="divider"></li>'
        +'       <li onclick="sw_req(\'126626\',\'2\',\'req_btn\','+id+')"><a>Switch to Friend Request</a></li>'
		+'		<li onclick="sw_req(\'146626\',\'2\',\'req_btn\','+id+')"><a>Switch to Classmate Request</a></li>'
        +'   </ul>';
	} else {
		$.get('cont_src/act.php?sreq='+id+'&sreqtyp=1');
		document.getElementById(tg).innerHTML = 
		 '<button class="btn btn-success btn-sm dropdown-toggle" data-toggle="dropdown" type="button"><i class="fa fa-check"></i> <span class="badge bg-yellow">Friend</span> Request Sent</button>'
		+'	<ul class="dropdown-menu" role="menu">'
        +'       <li onclick="can_req('+id+',\'req_btn\')"><a><i class="fa fa-times"></i> Cancel Request </a></li>'
        +'       <li class="divider"></li>'
        +'       <li onclick="sw_req(\'146626\',\'1\',\'req_btn\','+id+')"><a>Switch to Classmate Request</a></li>'
		+'		<li onclick="sw_req(\'136636\',\'1\',\'req_btn\','+id+')"><a>Switch to In Family Request</a></li>'
        +'   </ul>';
	}
}
function can_req(id,btn){
	$.get('cont_src/act.php?cereq='+id);
	document.getElementById(btn).innerHTML = 
	'<button class="btn btn-success btn-sm dropdown-toggle" data-toggle="dropdown" type="button"><i class="fa fa-plus"></i> Request For</button>'
	+'<ul class="dropdown-menu" role="menu">'
    +'      <li onclick="send_req(\'124354\',\'req_btn\','+id+')"><a> Friend </a></li>'
    +'      <li class="divider"></li>'
    +'      <li onclick="send_req(\'146626\',\'req_btn\','+id+')"><a> Classmate </a></li>'
	+'	<li onclick="send_req(\'136636\',\'req_btn\','+id+')"><a> In Family </a></li>'
    +'</ul>';
}
function del_rel(id,btn,typ){
	$.get('cont_src/act.php?del_rel='+id);
	document.getElementById(btn).innerHTML = 
	'<button class="btn btn-success btn-sm dropdown-toggle" data-toggle="dropdown" type="button"><i class="fa fa-plus"></i> Request For</button>'
	+'<ul class="dropdown-menu" role="menu">'
    +'      <li onclick="send_req(\'124354\',\'req_btn\','+id+')"><a> Friend </a></li>'
    +'      <li class="divider"></li>'
    +'      <li onclick="send_req(\'146626\',\'req_btn\','+id+')"><a> Classmate </a></li>'
	+'	<li onclick="send_req(\'136636\',\'req_btn\','+id+')"><a> In Family </a></li>'
    +'</ul>';
}
function sw_req(nty,oty,btn,id){
	if(nty == '146626'){
		$.get('cont_src/act.php?swreq='+id+'&swnty=3&swoty='+oty+'');
		document.getElementById(btn).innerHTML = 
		 '<button class="btn btn-success btn-sm dropdown-toggle" data-toggle="dropdown" type="button"><i class="fa fa-check"></i> <span class="badge bg-yellow">Classmate</span> Request Sent</button>'
		+'	<ul class="dropdown-menu" role="menu">'
        +'       <li onclick="can_req('+id+',\'req_btn\')"><a><i class="fa fa-times"></i> Cancel Request </a></li>'
        +'       <li class="divider"></li>'
        +'       <li onclick="sw_req(\'126626\',\'3\',\'req_btn\','+id+')"><a>Switch to Friend Request</a></li>'
		+'		<li onclick="sw_req(\'136636\',\'3\',\'req_btn\','+id+')"><a>Switch to In Family Request</a></li>'
        +'   </ul>';
	} else if(nty == '136636'){
		$.get('cont_src/act.php?swreq='+id+'&swnty=2&swoty='+oty+'');
		document.getElementById(btn).innerHTML = 
		 '<button class="btn btn-success btn-sm dropdown-toggle" data-toggle="dropdown" type="button"><i class="fa fa-check"></i> <span class="badge bg-yellow">In Family</span> Request Sent</button>'
		+'	<ul class="dropdown-menu" role="menu">'
        +'       <li onclick="can_req('+id+',\'req_btn\')"><a><i class="fa fa-times"></i> Cancel Request </a></li>'
        +'       <li class="divider"></li>'
        +'       <li onclick="sw_req(\'126626\',\'2\',\'req_btn\','+id+')"><a>Switch to Friend Request</a></li>'
		+'		<li onclick="sw_req(\'146626\',\'2\',\'req_btn\','+id+')"><a>Switch to Classmate Request</a></li>'
        +'   </ul>';
	} else {
		$.get('cont_src/act.php?swreq='+id+'&swnty=1&swoty='+oty+'');
		document.getElementById(btn).innerHTML = 
		 '<button class="btn btn-success btn-sm dropdown-toggle" data-toggle="dropdown" type="button"><i class="fa fa-check"></i> <span class="badge bg-yellow">Friend</span> Request Sent</button>'
		+'	<ul class="dropdown-menu" role="menu">'
        +'       <li onclick="can_req('+id+',\'req_btn\')"><a><i class="fa fa-times"></i> Cancel Request </a></li>'
        +'       <li class="divider"></li>'
        +'       <li onclick="sw_req(\'146626\',\'1\',\'req_btn\','+id+')"><a>Switch to Classmate Request</a></li>'
		+'		<li onclick="sw_req(\'136636\',\'1\',\'req_btn\','+id+')"><a>Switch to In Family Request</a></li>'
        +'   </ul>';
	}
}
function follow_p(id,btn){
	$.get('cont_src/act.php?follw='+id);
	document.getElementById(btn).innerHTML = 
	'<button id="unfolw_btn" class="btn btn-sm btn-default text-orange dropdown-toggle" data-toggle="dropdown" type="button"><i class="fa fa-hand-o-right"></i> Following</button>'+
	'<ul class="dropdown-menu" role="menu">'+
	'<li onclick="delfolw_p(\''+id+'\',\''+btn+'\')"><a><i class="fa fa-hand-o-left"></i> Remove from Following</a></li>'+
	'</ul>'
	;
}
function delfolw_p(id,btn){
	$.get('cont_src/act.php?ufolw='+id);
	document.getElementById(btn).innerHTML = 
	'<button onclick="follow_p(\''+id+'\',\''+btn+'\')" id="flow_btn" class="btn btn-sm bg-orange" type="button"><i class="fa fa-hand-o-right"></i> Follow</button>'
	;
}

function collapse_cm(id) {
	var box = document.getElementById("combox_"+id).className;
	if (box == "box box-solid collapsed-box"){
		document.getElementById("comlbox_"+id).style.display = "block";
		document.getElementById("comlsend_"+id).style.display = "block";
		document.getElementById("combox_"+id).className = "box box-solid";}
	else{
		document.getElementById("comlbox_"+id).style.display = "none";
		document.getElementById("comlsend_"+id).style.display = "none";
		document.getElementById("combox_"+id).className = "box box-solid collapsed-box";}
}
function loaddiv(link, div)
{
var xmlhttp;
if (window.XMLHttpRequest){
xmlhttp=new XMLHttpRequest();}
else {
xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");}
xmlhttp.onreadystatechange=function(){
if (xmlhttp.readyState==4 && xmlhttp.status==200) {
document.getElementById(div).innerHTML=xmlhttp.responseText; }}
xmlhttp.open("GET",link,true);
xmlhttp.send();
}

function update(link) 
{ 
$.post(link);
}

function log_out(){
	clearInterval();
	location.href = 'index.php?logout';
}

window.setInterval(function(){
	loaddiv("cont_src/msgn.php", "msgn");
	 update("cont_src/update.php");
	loaddiv("cont_src/on.php", "onmlc");
	loaddiv("cont_src/notn.php", "notn");
	loaddiv("cont_src/mailn.php", "mailn");
	loaddiv("cont_src/prow.php", "newprow");
}, 3000);

function msgnull(){
	sendd("cont_src/act.php?messages");
	loaddiv("cont_src/msgn.php", "msgn");
	loaddiv("cont_src/on.php", "onmlc");
	}
function notsnull(){
	sendd("cont_src/act.php?nots");
	loaddiv("cont_src/notn.php", "notn");
	loaddiv("cont_src/notc.php", "notc");
	}
function mailnull(){
	sendd("cont_src/act.php?mail");
	loaddiv("cont_src/mailn.php", "mailn");
	loaddiv("cont_src/mailc.php", "mailc");
	}

function notis(){
		sendd("cont_src/act.php?notis");
	}
function scroll_to(div){
var objDiv = document.getElementById(div);
objDiv.scrollTop = objDiv.scrollHeight;
}
function msg_c(){
	document.getElementById("msgc").innerHTML = '<li class="header"><i class="fa fa-clock-o"></i> Loading..</li>';
	loaddiv("cont_src/msgc.php", "msgc");
	msgnull();
}
function not_c(){
	document.getElementById("notc").innerHTML = '<li class="header"><i class="fa fa-clock-o"></i> Loading..</li>';
	loaddiv("cont_src/notc.php", "notc");
	notis();
}
function mail_c(){
	document.getElementById("mailc").innerHTML = '<li class="header"><i class="fa fa-clock-o"></i> Loading..</li>';
	loaddiv("cont_src/mailc.php", "mailc");
}
function pick(id){
		document.getElementById('kick_'+id).className = "btn btn-default btn-sm disabled";
		document.getElementById('pick_'+id).className = "btn btn-success btn-sm disabled";
		document.getElementById('pic_'+id).className = "fa fa-thumbs-up";
		document.getElementById('pick_'+id).onclick = "alert('You have already Picked this post');";
		document.getElementById('kick_'+id).onclick = "alert('You have already Picked this post So you can not kicked again');";
		if(Number(document.getElementById('kickl_'+id).innerHTML) != 0){document.getElementById('kickl_'+id).className = "label label-danger disabled";}
		document.getElementById('pickl_'+id).className = "label label-warning disabled";
		document.getElementById('pickl_'+id).innerHTML = Number(document.getElementById('pickl_'+id).innerHTML)+1;
		document.getElementById('picks_'+id).innerHTML = " Picked ";
		sendd("cont_src/act.php?pick="+id);
	}
function kick(id){
		document.getElementById('pick_'+id).className = "btn btn-default btn-sm disabled";
		document.getElementById('kick_'+id).className = "btn btn-danger btn-sm disabled";
		document.getElementById('kic_'+id).className = "fa fa-thumbs-down";
		sendd("cont_src/act.php?kick="+id);
		document.getElementById('kick_'+id).onclick = "alert('You have already Kicked this post');";
		document.getElementById('pick_'+id).onclick = "alert('You have already Kicked this post so you can not picked again');";
		document.getElementById('kickl_'+id).innerHTML = Number(document.getElementById('kickl_'+id).innerHTML)+1;
		document.getElementById('kicks_'+id).innerHTML = " Kicked ";
		if(Number(document.getElementById('pickl_'+id).innerHTML) != 0){document.getElementById('pickl_'+id).className = "label label-success disabled";}
		document.getElementById('kickl_'+id).className = "label label-warning disabled";
	}
	
function sndcom(id){
	var comtext;
	comtext = document.getElementById('comtx_'+id).value;
	document.getElementById('comtx_'+id).value = "";
	sendd("cont_src/act.php?com="+id+"&text="+comtext);
	document.getElementById('coms_'+id).innerHTML = Number(document.getElementById('coms_'+id).innerHTML)+1;
	document.getElementById('tempcom_'+id).innerHTML = 
	"<div class='box box-danger box-header' valign='middle'><span class='pull-left'><a><strong class='text-default'> You </strong><br/><i> - "+comtext+" .<i class='fa fa-quote-right'></i></i></a></span><span class='pull-right'><a data-toggle='tooltip' title='Cannot Pick your own comment'><strong class='label label-success'> <i class='fa fa-thumbs-o-up'></i> 0</strong></a> - <a data-toggle='tooltip' title='Cannot Kick your own comment'><strong class='label label-danger' onclick=''> <i class='fa fa-thumbs-o-down'></i> 0</strong></a></span></div>"+document.getElementById('tempcom_'+id).innerHTML;
	}
	
function sndcompic(id){
	document.getElementById('cp_'+id).innerHTML = Number(document.getElementById('cp_'+id).innerHTML)+1;
	document.getElementById('cbp_'+id).onclick = "";
	document.getElementById('cbk_'+id).onclick = "";
	document.getElementById('cicp_'+id).className = "fa fa-thumbs-up";
	sendd("cont_src/act.php?comp="+id);
	}

function sndcomkic(id){
	document.getElementById('ck_'+id).innerHTML = Number(document.getElementById('ck_'+id).innerHTML)+1;
	document.getElementById('cbp_'+id).onclick = "";
	document.getElementById('cbk_'+id).onclick = "";
	document.getElementById('cick_'+id).className = "fa fa-thumbs-down";
	sendd("cont_src/act.php?comk="+id);
	}
	
function posts(){

	var text = document.getElementById("text1").value;
	var dataString = 'text1=' + text;
	if (text == '') {
		document.getElementById('erops1').innerHTML = "You can't post empty !";
	} else {
	document.getElementById('posts-modal').modal = "hide";
	document.getElementById("text1").value = "";
	$('#posts-modal').modal('hide');
	var imp = "<div class='box'><div class='box-header'><h3 class='box-title'><img class='img-circle'  alt='user image' style='width:40px;'></img> You</h3><div class='box-tools pull-right'><span class='time'><i class='fa fa-clock-o'></i> Just now </span><button type='button' class='btn btn-default dropdown-toggle' data-toggle='dropdown' ><span class='fa fa-ellipsis-v' data-toggle='tooltip' title='Option'></span></button></div></div><div class='box-body'>"+text+"</div><div class='overlay'></div><ul class='loader'><li></li></ul><div class='box-footer'><div class='box box-solid collapsed-box'><div class='box-header'><h3 class='box-title'><button class='btn btn-success' id='pick_' data-toggle='tooltip' title='Hit for Pick'><i class='fa fa-thumbs-o-up' id='pic_'></i><span id='picks_'> Pick </span></button> <button class='btn btn-primary' id='kick_' data-toggle='tooltip' title='Hit for Kick'><i class='fa fa-thumbs-o-down' id='kic_'></i><span id='kicks_'> Kick </span></button> <button class='btn btn-default' data-toggle='tooltip' title='View Comments' data-widget='collapse'><i class='fa fa-quote-left'></i> Comment  <i class='fa fa-angle-double-down'></i></button></h3></div></div></div></div>";
	document.getElementById('current_post').innerHTML = document.getElementById('current_post').innerHTML + imp;
	$.ajax({
	type: "POST",
	url: "posts.php",
	data: dataString,
	cache: false,
	success: function(html) {
	document.getElementById('cpr').value = Number(document.getElementById('cpr').value)+1;
	reload_feed();
	}
	});
	}
	return false;
}
function postnc(){
	var text = document.getElementById("nctext").value;
	var dtl = document.getElementById("ncdtl").value;
	if (text.length < 6) {
		document.getElementById('eropsnc').innerHTML = "You can't post notice empty or less then 6 characters !";
	} else if (text.length > 40) {
		document.getElementById('eropsnc').innerHTML = "You must use only 40 characters for the notice !";
	} else {
	document.getElementById('postnc-modal').modal = "hide";
	document.getElementById("nctext").value = "";
	$('#postnc-modal').modal('hide');
	var newnc = '<a class="btn btn btn-primary" disabled><i class="fa fa-edit"></i> Posted</a>';
	sendd('cont_src/act.php?nctext='+text+'&dtl='+dtl);
	document.getElementById('current_nc').innerHTML = newnc;
	}
	return false;
}

function lmp(limit){
	var pid = limit-10;
	document.getElementById('lm').style.display = 'none';
	document.getElementById('lmpstl').style.display = 'block';
	loaddiv("src/feed_row.php?limit="+limit+"", "feed_row");
	var node = document.getElementById('p_'+pid);
	window.scroll(0, node.offsetTop);
}
function prlmp(limit,id){
	var pid = limit-10;
	document.getElementById('lm').style.display = 'none';
	document.getElementById('lmpstl').style.display = 'block';
	loaddiv("src/p_feed_row.php?limit="+limit+"&prid="+id, "feed_row");
	var node = document.getElementById('p_'+pid);
	window.scroll(0, node.offsetTop);
}

function reload_feed(){
	var limit = document.getElementById("limit_p").value;
	loaddiv("src/feed_row.php?limit="+limit+"", "feed_row");
	var node = document.getElementById('p_1');
	window.scroll(0, node.offsetTop);
	document.getElementById('ref_btn').style.display = 'none';
	window.setInterval(function(){document.getElementById('ref_btn').style.display = 'block';}, 10000);
}
function reload_prfeed(id){
	var limit = document.getElementById("limit_p").value;
	loaddiv("src/p_feed_row.php?limit="+limit+"&prid="+id, "feed_row");
	var node = document.getElementById('p_1');
	window.scroll(0, node.offsetTop);
	document.getElementById('ref_btn').style.display = 'none';
}
function check_feed(limit){
	var curent_row = Number(document.getElementById('cpr').value);
   var checked_row = document.getElementById('npr').innerHTML;
   document.getElementById('npr').innerHTML = checked_row;
   if (curent_row != checked_row)
   {
	topNoti('fa fa-refresh','New feed <u href=#p_1 >Need to Reload</u>.');
	document.getElementById('ref_btn').style.display = 'block';
	document.getElementById('cpr').value = checked_row;
   }
}
function load_com(id){
loaddiv("cont_src/compt.php?pid="+id, "com_pid_"+id);
}
function picks_m(id){
document.getElementById("m_blnk_cont").innerHTML = '<div class="modal-header"><button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button><h4 class="modal-title"> Loading... </h4></div>';
loaddiv("cont_src/picks.php?pid="+id, "m_blnk_cont");
}
function kicks_m(id){
document.getElementById("m_blnk_cont").innerHTML = '<div class="modal-header"><button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button><h4 class="modal-title"> Loading... </h4></div>';
loaddiv("cont_src/kicks.php?pid="+id, "m_blnk_cont");
}
function lod_msgm(){
document.getElementById("m_blnk_cont").innerHTML = '<div class="modal-header"><button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button><h4 class="modal-title"> Loading... </h4></div>';
loaddiv("cont_src/msgm.php", "m_blnk_cont");
}
function lod_msgm2(){
document.getElementById("m_blnk_cont").innerHTML = '<div class="modal-header"><button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button><h4 class="modal-title"> Loading... </h4></div>';
loaddiv("cont_src/msgm.php?f", "m_blnk_cont");
}
function fill_blnk_m(tag){
document.getElementById("m_blnk_c").innerHTML = '<div class="modal-header"><button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button><h4 class="modal-title"> Loading... </h4></div>';
loaddiv("cont_src/"+tag+".php", "m_blnk_c");
}
function st_save(tag){
document.getElementById("m_blnk_c").innerHTML = '<div class="modal-header"><button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button><h4 class="modal-title"> Loading.... </h4></div>';
var val = document.getElementById(tag).value;
loaddiv("cont_src/stet.php?q="+encodeURIComponent(val), "m_blnk_c");
}
function na_save(t1,t2){
var fa = document.getElementById(t1).value;
var la = document.getElementById(t2).value;
document.getElementById("m_blnk_c").innerHTML = '<div class="modal-header"><button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button><h4 class="modal-title"> Loading.... </h4></div>';
loaddiv("cont_src/chname.php?q1="+encodeURIComponent(fa)+"&q2="+encodeURIComponent(la), "m_blnk_c");
}
function bd_save(da,mo,yr){
var date = document.getElementById(da).value;
var month = document.getElementById(mo).value;
var year = document.getElementById(yr).value;
document.getElementById("m_blnk_c").innerHTML = '<div class="modal-header"><button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button><h4 class="modal-title"> Loading.... </h4></div>';
loaddiv("cont_src/chdate.php?q1="+date+"&q2="+month+"&q3="+year, "m_blnk_c");
}
function pn_save(tag){
var mn = document.getElementById(tag).value;
document.getElementById("m_blnk_c").innerHTML = '<div class="modal-header"><button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button><h4 class="modal-title"> Loading.... </h4></div>';
loaddiv("cont_src/chpn.php?q="+mn, "m_blnk_c");
}
function pass_save(op,np,cp){
var opss = document.getElementById(op).value;
var npss = document.getElementById(np).value;
var cpss = document.getElementById(cp).value;
document.getElementById(op).value = '';
document.getElementById(np).value = '';
document.getElementById(cp).value = '';
document.getElementById("m_blnk_c").innerHTML = '<div class="modal-header"><button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button><h4 class="modal-title"> Loading.... </h4></div>';
loaddiv("cont_src/chgpass.php?op="+encodeURIComponent(opss)+"&np="+encodeURIComponent(npss)+"&cp="+encodeURIComponent(cpss), "m_blnk_c");
}
function em_save(em,ps){
var emil = document.getElementById(em).value;
var pss = document.getElementById(ps).value;
document.getElementById(ps).value = '';
document.getElementById("m_blnk_c").innerHTML = '<div class="modal-header"><button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button><h4 class="modal-title"> Loading.... </h4></div>';
loaddiv("cont_src/chem.php?em="+encodeURIComponent(emil)+"&ps="+encodeURIComponent(pss), "m_blnk_c");
}
function un_save(un,ps){
var una = document.getElementById(un).value;
var pss = document.getElementById(ps).value;
document.getElementById(ps).value = '';
document.getElementById("m_blnk_c").innerHTML = '<div class="modal-header"><button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button><h4 class="modal-title"> Loading.... </h4></div>';
loaddiv("cont_src/chun.php?un="+encodeURIComponent(una)+"&ps="+encodeURIComponent(pss), "m_blnk_c");
}
function emwp_save(em){
var emil = document.getElementById(em).value;
document.getElementById("m_blnk_c").innerHTML = '<div class="modal-header"><button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button><h4 class="modal-title"> Loading.... </h4></div>';
loaddiv("cont_src/chem.php?em="+encodeURIComponent(emil)+"&ps='codw'", "m_blnk_c");
}
function unwp_save(un){
var una = document.getElementById(un).value;
document.getElementById("m_blnk_c").innerHTML = '<div class="modal-header"><button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button><h4 class="modal-title"> Loading.... </h4></div>';
loaddiv("cont_src/chun.php?un="+encodeURIComponent(una)+"&ps='codw'", "m_blnk_c");
}
function chsstet(val,tg,st){
	var ste = document.getElementById(val).value;
	document.getElementById(tg).style.display = 'none';
	document.getElementById("m_blnk_c").innerHTML = '<div class="modal-header"><button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button><h4 class="modal-title"> Loading.... </h4></div>';
	loaddiv("cont_src/stet.php?q="+encodeURIComponent(ste), "m_blnk_c");
	document.getElementById(st).innerHTML = '\''+ste+'\' <a  onclick="onp_tg(\'ste_tg\')" ><i class="fa fa-pencil" ></i></a>';
}
var chat_id_m;
var chat_no_m;
window.setInterval(function(){chats_m3(chat_id_m,chat_no_m)},1000);
function chats_m(id){
document.getElementById("m_blnk_cont").innerHTML = '<div class="modal-header"><button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button><h4 class="modal-title"> Loading... </h4></div>';
loaddiv("cont_src/msgs.php?id="+id, "m_blnk_cont");
window.chat_id_m = id;
window.chat_no_m = '4';
}
function chats_m2(id,no){
document.getElementById("ms_lodcont").innerHTML = '<div><ul class="loader"><li></li></ul></div>';
window.chat_id_m = id;
window.chat_no_m = no;
}

function chats_m3(id,no){
if(document.getElementById("chat_cont") != null && id != null && no != null){
loaddiv("cont_src/msgs_c.php?id="+id+"&no="+no, "chat_cont");
if(document.getElementById("red_chat_s") != null){
loaddiv("cont_src/msgs_s.php?id="+id, "red_chat_s");
}
}
}
function clr_chat(){
window.chat_id_m = null;
window.chat_no_m = null;
}
function clr_mod(){
window.chat_id_m = null;
window.chat_no_m = null;
document.getElementById("m_blnk_cont").innerHTML = '<div class="modal-header"><button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button><h4 class="modal-title"> Loading... </h4></div>';
$('#blank_m').modal('hide');
}
function send_msg_u(txt,id,no){
msg = document.getElementById(txt).value;
if(msg != ''){
document.getElementById("dummy_msg").style.display = 'block';
document.getElementById("dummy_msg").innerHTML += '<div class="msgr"><div class="msgtxt">'+msg+'</div><div class="timemsg"> <i class="fa fa-clock-o"></i></div></div>';
document.getElementById(txt).value = '';
scroll_to('chat_cont');
sendd("cont_src/act.php?s_msg="+msg+"&to="+id);
}
scroll_to('chat_cont');
}
function typing_st(id){
sendd("cont_src/act.php?ty_msg="+id);
}
function delete_post(id){
	sendd("cont_src/act.php?d_post="+id);
	document.getElementById('post_'+id).style.display = 'none';
}
function bm_post(id){
	sendd("cont_src/act.php?bm_post="+id);
	document.getElementById('bm_post_o_'+id).style.display = 'none';
	document.getElementById('bm_post_s_'+id).style.display = 'block';
}
function onp_tg(tg){
document.getElementById(tg).style.display = 'block';
}
function loaddiv(link, div)
{
var xmlhttp;
if (window.XMLHttpRequest){
xmlhttp=new XMLHttpRequest();}
else {
xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");}
xmlhttp.onreadystatechange=function(){
if (xmlhttp.readyState==4 && xmlhttp.status==200) {
document.getElementById(div).innerHTML=xmlhttp.responseText; }}
xmlhttp.open("GET",link,true);
xmlhttp.send();
}



function isValidURL(url){
		var RegExp = /(ftp|http|https):\/\/(\w+:{0,1}\w*@)?(\S+)(:[0-9]+)?(\/|\/([\w#!:.?+=&%@!\-\/]))?/;
		if(RegExp.test(url)){
			return true;
		}else{
			return false;
		}
	}
	
function isNum(evt) {
	evt = (evt) ? evt : window.event;
	var charCode = (evt.which) ? evt.which : evt.keyCode;
	if (charCode > 31 && (charCode < 48 || charCode > 57)) {
		return false;
	}
	return true;
}
	
function show_url(str) {
     if (str.length == 0) {
         document.getElementById("result_url").innerHTML = "";
		 document.getElementById("error_url").innerHTML = "";
         return;
     } else {
		if(isValidURL(str)){
			document.getElementById("preview_url").innerHTML = "[   Loading.. ]";
			loaddiv("inc_src/url_fetch.php?url="+encodeURIComponent(str), "result_url");
			getPreview_url_info();
		} else {
			var RegExp;
			if(str.length == 1){
				RegExp = /(f|h)/;
				if(!RegExp.test(str)){
					document.getElementById("error_url").innerHTML = "You must start with http://";
				} else { document.getElementById("error_url").innerHTML = ""; }
			}
			else if(str.length == 2){
				RegExp = /(ft|ht)/;
				if(!RegExp.test(str)){
					document.getElementById("error_url").innerHTML = "You must start with http://";
				} else { document.getElementById("error_url").innerHTML = ""; }
			}
			else if(str.length == 3){
				RegExp = /(ftp|htt)/;
				if(!RegExp.test(str)){
					document.getElementById("error_url").innerHTML = "You must start with http://";
				} else { document.getElementById("error_url").innerHTML = ""; }
			}
			else if(str.length == 4){
				RegExp = /(ftp:|http)/;
				if(!RegExp.test(str)){
					document.getElementById("error_url").innerHTML = "You must start with http://";
				} else { document.getElementById("error_url").innerHTML = ""; }
			}
			else if(str.length == 5){
				RegExp = /(ftp:\/|http:|https)/;
				if(!RegExp.test(str)){
					document.getElementById("error_url").innerHTML = "You must start with http://";
				} else { document.getElementById("error_url").innerHTML = ""; }
			}
			else if(str.length == 6){
				RegExp = /(ftp:\/\/|http:\/|https:)/;
				if(!RegExp.test(str)){
					document.getElementById("error_url").innerHTML = "You must start with http://";
				} else { document.getElementById("error_url").innerHTML = ""; }
			}
			else if(str.length == 7){
				RegExp = /(http:\/\/|https:\/)/;
				if(!RegExp.test(str)){
					document.getElementById("error_url").innerHTML = "You must start with http://";
				} else { document.getElementById("error_url").innerHTML = ""; }
			}
			else if(str.length == 8){
				RegExp = /(https:\/\/)/;
				if(!RegExp.test(str)){
					document.getElementById("error_url").innerHTML = "You must start with http://";
				} else { document.getElementById("error_url").innerHTML = ""; }
			}
			else{
				RegExp = /(ftp|http|https):\/\/(\w+:{0,1}\w*@)?(\S+)(:[0-9]+)?(\/|\/([\w#!:.?+=&%@!\-\/]))?/;
				if(!RegExp.test(str)){
					document.getElementById("error_url").innerHTML = "Enter a valid Link";
				} else { document.getElementById("error_url").innerHTML = ""; }
			}
		}
     }
}

function getPreview_url_info(){
	var result = document.getElementById("result_url").innerHTML;
	document.getElementById("preview_url").innerHTML = result;
}

function remove_loader(id)
{
document.getElementById(id).style.display = 'none';
}
var oxmlHttpSend;
function sendd(action)
{
    if(typeof XMLHttpRequest != "undefined")
    {
        oxmlHttpSend = new XMLHttpRequest();
    }
    else if (window.ActiveXObject)
    {
       oxmlHttpSend = new ActiveXObject("Microsoft.XMLHttp");
    }
    if(oxmlHttpSend == null)
    {
       alert("Browser does not support XML Http Request");
       return;
    }
    oxmlHttpSend.open("GET",action,true);
    oxmlHttpSend.send(null);
}
