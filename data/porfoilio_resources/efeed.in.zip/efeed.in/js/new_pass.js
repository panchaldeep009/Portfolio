
document.getElementById("password").onkeyup = function() {
	if (CapsLock.isOn()){
		document.getElementById('pass_stet').className = "input-group has-warning";
		document.getElementById('pass_war_label').innerHTML = '<i class="fa fa-warning"></i> Warning - CapsLock is on.';
		document.getElementById('pass_error_label').innerHTML = '';
	}
	if (!CapsLock.isOn()){
		document.getElementById('pass_stet').className = "input-group";
		document.getElementById('pass_war_label').innerHTML = "";
	}
};

document.getElementById("password2").onkeyup = function() {
	if (CapsLock.isOn()){
		document.getElementById('pass_stet').className = "input-group has-warning";
		document.getElementById('pass_war_label').innerHTML = '<i class="fa fa-warning"></i> Warning - CapsLock is on.';
		document.getElementById('pass_error_label').innerHTML = '';
	}
	if (!CapsLock.isOn()){
		document.getElementById('pass_stet').className = "input-group";
		document.getElementById('pass_war_label').innerHTML = "";
	}
};
	
document.getElementById("password").onchange = function() {passcheck()};
function passcheck() {
	var perameter = document.getElementById("password").value;
	if(perameter.length != 0){
		if(perameter.length < 6){
			document.getElementById('pass_error_label').innerHTML = '<i class="fa fa-times-circle-o"></i> Minimum six characters are required for Password';
			document.getElementById('pass_stet').className = 'input-group has-error';
			document.getElementById('pass_war_label').innerHTML = '';
			document.getElementById('pass_comp_label').innerHTML = '';
		} else {
			document.getElementById('pass_war_label').innerHTML = '';
			document.getElementById('pass_error_label').innerHTML = '';
			document.getElementById('pass_comp_label').innerHTML = '';
			document.getElementById('pass_stet').className = 'input-group';
		}
	} else {
		document.getElementById('pass_war_label').innerHTML = '';
		document.getElementById('pass_error_label').innerHTML = '';
		document.getElementById('pass_comp_label').innerHTML = '';
		document.getElementById('pass_stet').className = 'input-group';
	}
}
	
document.getElementById("password2").onchange = function() {
	var pass = document.getElementById("password").value;
	var pass2 = document.getElementById("password2").value;
	if(pass.length > 5){
		if (pass != pass2){
			document.getElementById('pass_war_label').innerHTML = '';
			document.getElementById('pass_comp_label').innerHTML = '';
			document.getElementById('pass_error_label').innerHTML = '<i class="fa fa-times-circle-o"></i> Confirm password is not geting match';
			document.getElementById('pass_stet').className = 'input-group has-error';
		} else {
			document.getElementById('pass_war_label').innerHTML = '';
			document.getElementById('pass_error_label').innerHTML = '';
			document.getElementById('pass_comp_label').innerHTML = '<i class="fa fa-check"></i> Successfully match.';
			document.getElementById('pass_stet').className = 'input-group has-success';
		}
	} else {
	passcheck();
	}
};

var CapsLock = (function(){
  var capsLock = false;
  var listeners = [];
  var isMac = /Mac/.test(navigator.platform);
  function isOn(){
	return capsLock;
  }
  function addListener(listener){
	listeners.push(listener);

  }
  function handleKeyPress(e){
	if (!e) e = window.event;
	var priorCapsLock = capsLock;
	var charCode = (e.charCode ? e.charCode : e.keyCode);
	if (charCode >= 97 && charCode <= 122){
	  capsLock = e.shiftKey;
	}else if (charCode >= 65 && charCode <= 90 && !(e.shiftKey && isMac)){
	  capsLock = !e.shiftKey;
	}
	if (capsLock != priorCapsLock){
	  for (var index = 0; index < listeners.length; index ++){
		listeners[index](capsLock);
	  }
	}

  }
  if (window.addEventListener){
	window.addEventListener('keypress', handleKeyPress, false);
  }else{
	document.documentElement.attachEvent('onkeypress', handleKeyPress);
  }
  return {
	isOn        : isOn,
	addListener : addListener
  };

})();

function validform(){
	var pass = document.getElementById("password").value;
	var pass2 = document.getElementById("password2").value;
	if(pass.length < 6){
		document.getElementById('pass_error_label').innerHTML = '<i class="fa fa-times-circle-o"></i> Minimum six characters are required for Password';
		document.getElementById('ercont').innerHTML = 'Solve error before submit.';
		return false;
	}
	else if(pass2 != pass){
		document.getElementById('pass_error_label').innerHTML = '<i class="fa fa-times-circle-o"></i> Confirm password is not geting match';
		document.getElementById('ercont').innerHTML = 'Solve error before submit.';
		return false;
	}
	else{return true;}
}
