<?php 
require("../common.php");
ob_start();
session_start();
$mailsql = "select * from connt where rid = ".$_SESSION['user']['id']." AND typ = '0' AND rtyp != '0' order by times desc LIMIT 10";
$rowmail = mysqli_query($conn, $mailsql);
$num_mail = mysqli_num_rows(mysqli_query($conn, "select * from connt where rid = ".$_SESSION['user']['id']." AND typ = '0' AND rtyp != '0'"));
?>
	<li class="header"><?php if($num_mail != 0){ echo "You have ".($num_mail)." Requests padding <div align='right'></div>"; } else { echo "No requests";}?></li>
	<li>
		<ul class="menu">
		<?php while($req = mysqli_fetch_array($rowmail)) {?>
		
			<li>
				<a>
					<div class="pull-left">
					<img src="<?php defindsql($conn,"propic","users","id","".$req['sid']."",0,0,0,0,0,0);?>" class="img-circle" alt="User Image" width="50px"/>
					</div>
					<h3 align="center"><?php defindsql($conn,"fname","users","id","".$req['sid']."",0,0,0,0,0,0);echo " ";defindsql($conn,"lname","users","id","".$req['sid']."",0,0,0,0,0,0);?>
						<small class="pull-right"><i class="fa fa-clock-o"></i><?php echo " ".timeago($req['times']);?></small>
					</h3>
					<p>
					<?php if($req['rtyp'] == 3){?>
					<div align="center" id="req_btnc">
						<button type="button" class="btn btn-success btn-xs" onclick="acptreq('<?php echo $req['sid'];?>','3','req_btnc')"><i class="fa fa-check"></i> Accept <span class="badge bg-yellow">Classmate</span></button>
						<button type="button" class="btn btn-primary btn-xs" onclick="regreq('<?php echo $req['sid'];?>','req_btnc')"><i class="fa fa-times"></i> Reject </button>
					</div>
					<?php }
					else if($req['rtyp'] == 2){?>
					<div align="center" id="req_btnc">
						<button type="button" class="btn btn-success btn-xs" onclick="acptreq('<?php echo $req['sid'];?>','2','req_btnc')"><i class="fa fa-check"></i> Accept <span class="badge bg-yellow">In Family</span></button>
						<button type="button" class="btn btn-primary btn-xs" onclick="regreq('<?php echo $req['sid'];?>','req_btnc')"><i class="fa fa-times"></i> Reject </button>
					</div>
					<?php } else {?>
					<div align="center" id="req_btnc">
                        <div class="btn-group" data-toggle="btn-toggle">
                            <button type="button" class="btn btn-success btn-xs" onclick="acptreq('<?php echo $req['sid'];?>','1','req_btnc')"><i class="fa fa-check"></i> Accept <span class="badge bg-yellow">Friend</span></button>
                            <button type="button" class="btn btn-primary btn-xs" onclick="regreq('<?php echo $req['sid'];?>','req_btnc')"><i class="fa fa-times"></i> Reject </button>
                        </div>
                    </div>
					<?php } ?>
					</p>
				</a>
			</li>
			
		<?php }?>
		</ul>
		<?php $rlnum_mail = mysqli_num_rows($rowmail);
		if($rlnum_mail > 10){
		$leftmail = $rlnum_mail - 10;?>
		<div align="center"><?php echo $leftmail." ";?> More</div><?php }?>
	</li>
	<li class="footer"><a href="#">View all Requests</a></li>