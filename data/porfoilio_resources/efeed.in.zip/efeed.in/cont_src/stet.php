<?php 
require("../common.php");
ob_start();
session_start();
$login_ok = false;
if(isset($_GET['q'])){
	if(urldecode(trim($_GET['q'])) == null || urldecode(trim($_GET['q'])) == ""){
		$error = "<i class='fa fa-times-circle-o'></i> Can't save empty !";
	} else {
		mysqli_query($conn, "UPDATE users SET stet='".urldecode($_GET['q'])."' WHERE id=".$_SESSION['user']['id']);
		$error = '<i class="fa fa-check"></i> Status successfully changed.';
	}
} ?>
<div class="modal-header"><button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button><h4 class="modal-title"><?php if(isset($error)){echo $error;} else {echo 'Unknown error';} ?></h4></div>