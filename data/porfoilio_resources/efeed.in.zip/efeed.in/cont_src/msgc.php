<?php 
require("../common.php");
ob_start();
session_start();
$data = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM users WHERE id = ".$_SESSION['user']['id']));
$msgsql = "SELECT a.id, a.sendid, a.revid, a.d, a.m, a.y, a.th, a.tm, a.ts, a.tap, a.times, a.msg, a.state 
FROM msg a 
INNER JOIN (SELECT a.sendid, MAX(a.id) id 
            FROM msg a 
            WHERE a.revid = ".$_SESSION['user']['id']."
            GROUP BY a.sendid
           ) AS b ON a.sendid = b.sendid AND a.id = b.id
		   order by a.times desc LIMIT 10
		   ;";
$rowmsg = mysqli_query($conn, $msgsql);
$num_msg = mysqli_num_rows(mysqli_query($conn, "SELECT * FROM msg WHERE revid = ".$_SESSION['user']['id']." AND state = 1"));
$sql = "UPDATE users SET nmsg='".$num_msg."' WHERE id=".$_SESSION['user']['id'];
$data['nmsg'] = $num_msg;?>
<li class="header">You have <?php if($data['nmsg'] != 0){ echo ($data['nmsg'])." new messages "; } else { echo "no new messages";}?></li>
	<li>
		<ul class="menu">
			<?php while($msg = mysqli_fetch_array($rowmsg)) {?>
			<?php if($msg['state'] == '1'){ ?><li class="bg-gray"><?php } else { ?><li><?php } ?>
				<a href="" onclick="chats_m(<?php echo $msg['sendid'];?>)" data-toggle="modal" data-target="#blank_m">
					<div class="pull-left">
					<img src="<?php defindsql($conn,"propic","users","id","".$msg['sendid']."",0,0,0,0,0,0);?>" class="img-circle" alt="User Image"/>
					</div>
					<?php
					$num_umsg = mysqli_num_rows(mysqli_query($conn, "SELECT * FROM msg WHERE revid = ".$_SESSION['user']['id']." AND state = 1 AND sendid = ".$msg['sendid'].""));
					?>
					<h4><?php defindsql($conn,"fname","users","id","".$msg['sendid']."",0,0,0,0,0,0);echo " ";defindsql($conn,"lname","users","id","".$msg['sendid']."",0,0,0,0,0,0);?>
						<small><i class="fa fa-clock-o"></i> <?php echo timeago($msg['times']);if(time() - setssql($conn,"llog","users","id","".$msg['sendid']."",0,0,0,0,0,0) < 5){?><br /><br /><span class="time text-success"><i class="fa fa-certificate"></i> Online</span><?php }?></small>
					</h4>
					<p><?php echo $msg['msg'];echo " ";if($num_umsg > 1){ echo " <span class='label label-success'>".$num_umsg."</span>";}?></p>
				</a>
			</li><!-- end message -->
			<?php } ?>
		</ul>
		<?php $rlnum_msg = mysqli_num_rows($rowmsg);
		if($rlnum_msg > 10){
		$leftmsg = $rlnum_msg - 10;?>
		<div align="center"><?php echo $leftmsg." ";?> More</div><?php }?>
	</li>
<li class="footer" onclick="lod_msgm()" data-toggle="modal" data-target="#blank_m"><a>Get to Messages</a></li>