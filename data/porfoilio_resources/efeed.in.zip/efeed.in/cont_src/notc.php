<?php 
require("../common.php");
ob_start();
session_start();
$data = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM users WHERE id = ".$_SESSION['user']['id']));
$notsql = "SELECT * FROM nots WHERE revid = '".$_SESSION['user']['id']."' OR revid = '0' order by times desc LIMIT 5";
$rownot = mysqli_query($conn, $notsql);
$num_not = mysqli_num_rows(mysqli_query($conn, "SELECT * FROM nots WHERE revid = '".$_SESSION['user']['id']."' AND state = '1' OR revid = '0' AND state = '1'"));
$sql = "UPDATE users SET nnot='".$num_not."' WHERE id=".$_SESSION['user']['id'];
$data['nnot'] = $num_not;?>
	<li class="header">You have <?php if($data['nnot'] != 0){ echo ($data['nnot'])." new notifications "; } else { echo "no new notifications";}?></li>
	<li>
		<ul class="menu">
			<?php while($not = mysqli_fetch_array($rownot)) {
			if($not['state'] == '1'){
			?>
			<li class="bg-gray">
			<?php } else {?>
			<li>
			<?php } 
			if($not['atb2'] == 'post'){?>
				<a href="index.php?post=<?php echo $not['aid2'];?>">
			<?php }else if($not['atb2'] == 'user'){?>
				<a href="index.php?user=<?php echo $not['aid2'];?>">
			<?php } else {?>	
				<a href="#">
			<?php }?>	
					<i class="<?php echo $not['ic'];?>"></i>
					<?php echo setssql($conn,'fname','users','id',$not['aid'],'0','0','0','0','0','0')." ".setssql($conn,'lname','users','id',$not['aid'],'0','0','0','0','0','0')." ".$not['nots']." ".$not['atxt2'];?>
				</a>
			</li>
			<?php } ?>
		</ul>
		<?php $rlnum_nots = mysqli_num_rows($rownot);
		if($rlnum_nots > 10){
		$leftnots = $rlnum_nots - 10;?>
		<div align="center"><?php echo $leftmsg." ";?> More</div><?php }?>
	</li>
	<li class="footer"><a href="index.php?notifications">View all</a></li>