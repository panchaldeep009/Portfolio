<?php 
require("../common.php");
ob_start();
session_start();
$pid = $_GET['pid'];
function check_lk($pid,$uid,$type,$conn)
{
$num = mysqli_num_rows(mysqli_query($conn, "SELECT * FROM pkc WHERE types = '".$type."' AND pid = ".$pid." AND usid =".$uid));
if($num > 0){ return true;}
else { return false; }
}
$no = mysqli_num_rows(mysqli_query($conn, "SELECT * FROM pkc WHERE types = '2' AND pid = ".$pid));
?>
<div class="modal-header">
    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
    <h4 class="modal-title"><i class="fa fa-thumbs-o-down"></i><?php if($no > 0){ echo " Kicks <span class='label label-warning disabled'>".$no."</span>";} else { echo " No Kicks for this Post.";}?></h4>
<?php if($no > 0){ ?>
</div>
<div class="modal-body">
	<div align="center">
	<?php 
	if(check_lk($pid,$_SESSION['user']['id'],'1',$conn)) {echo "<small>(You Picked this Post)</small>";}
	else if(check_lk($pid,$_SESSION['user']['id'],'2',$conn)) {echo "<small>(You kicked this Post)</small>";}?>
	<br/><b> Give Kicks</b>
	<?php $t = mysqli_query($conn, "SELECT * FROM pkc WHERE types = '2' AND pid = ".$pid);
while($id = mysqli_fetch_array($t)) { ?>
	<a href="?user=<?php echo $id['usid'];?>"><h4 style="border-top: 1.5px solid #f4f4f4" ><img src="<?php echo defindsql($conn,"propic","users","id","".$id['usid']."",0,0,0,0,0,0);?>" class="img-circle"  alt="user image" style="width:30px;"/>  <?php echo defindsql($conn,"fname","users","id",$id['usid'],0,0,0,0,0,0);echo"  ";echo defindsql($conn,"lname","users","id",$id['usid'],0,0,0,0,0,0); ?></h4></a>
<?php } ?>
	</div>
</div>
<div class="modal-footer clearfix">
<?php } ?>
    <button class="pull-right btn btn-success" onclick="picks_m(<?php echo $pid;?>)"><i class="fa fa-thumbs-o-up"></i> View Picks</li><br/>
</div>