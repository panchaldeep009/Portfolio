<?php 
require("../common.php");
ob_start();
session_start();
if(isset($_GET['q1']) && isset($_GET['q2'])){
	if(trim($_GET['q1']) == null || trim($_GET['q1']) == ""){
		$error = "<i class='fa fa-times-circle-o'></i> Can't save first name empty !";
	} else if(trim($_GET['q2']) == null || trim($_GET['q2']) == ""){
		$error = "<i class='fa fa-times-circle-o'></i> Can't save last name empty !";
	} else {
		mysqli_query($conn, "UPDATE users SET fname='".urldecode($_GET['q1'])."' WHERE id=".$_SESSION['user']['id']);
		mysqli_query($conn, "UPDATE users SET lname='".urldecode($_GET['q2'])."' WHERE id=".$_SESSION['user']['id']);
		$error = '<i class="fa fa-check"></i> Name successfully changed.';
	}
} ?>
<div class="modal-header"><button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button><h4 class="modal-title"><?php if(isset($error)){echo $error;} else {echo 'Unknown ERROR';} ?></h4></div>