<?php 
require("../common.php");
ob_start();
session_start();
?>
<div class="modal-header">
    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
    <h4 class="modal-title"><i class="fa fa-edit"></i>Change Profile Info</h4>
</div>
<div class="modal-body">
	<div class="box box-primary" onclick="fill_blnk_m('prop')" data-toggle="modal" data-target="#blank_msg">
		<div class="box-body">
			<h4><i class="fa fa-picture-o"></i> Profile Picture</h4>
		</div>
	</div>
	<?php 
	$ch = setssql($conn,"gen","users","id",$_SESSION['user']['id'],0,0,0,0,0,0); 
	if($ch != 'page'){ ?>
	<div class="box box-primary">
		<div class="box-body" onclick="onp_tg('name_tg')">
			<h4><i class="fa fa-credit-card"></i> Name</h4>
			<div id="name_tg" style="display:none;">
			<div class="input-group">
				<span class="input-group-addon">First </span>
				<input type="text" class="form-control" name="fna" id="fna" value="<?php echo defindsql($conn,"fname","users","id",$_SESSION['user']['id'],0,0,0,0,0,0); ?>" placeholder="First Name">
				<span class="input-group-addon" id="efna" onclick="onclkune('fna')">😆</span>
			</div>
			<div id="contfna"></div>
			<div class="input-group">
				<span class="input-group-addon">Last </span>
				<input type="text" class="form-control" name="lna" id="lna" value="<?php echo defindsql($conn,"lname","users","id",$_SESSION['user']['id'],0,0,0,0,0,0); ?>" placeholder="Last Name">			
				<span class="input-group-addon" id="elna" onclick="onclkune('lna')">😆</span>
			</div>
			<div id="contlna"></div>
			<button class="btn btn-success btn-flat" type="button" onclick="na_save('fna','lna')"><i class="fa fa-save"></i> Save</button>
			</div>
		</div>
	</div>
	<?php } else { ?>
	<div class="box box-primary">
		<div class="box-body" onclick="onp_tg('name_tg')">
			<h4><i class="fa fa-credit-card"></i> Name and Category</h4>
			<div id="name_tg" style="display:none;">
			<div class="input-group">
				<span class="input-group-addon"> Name </span>
				<input type="text" class="form-control" name="fna" id="fna" value="<?php echo defindsql($conn,"fname","users","id",$_SESSION['user']['id'],0,0,0,0,0,0); ?>" placeholder="Name of Page">
				<span class="input-group-addon" id="efna" onclick="onclkune('fna')">😆</span>
			</div>
			<div id="contfna"></div>
			<div class="input-group">
				<span class="input-group-addon"> Category </span>
				<input type="text" class="form-control" name="lna" id="lna" value="<?php echo defindsql($conn,"lname","users","id",$_SESSION['user']['id'],0,0,0,0,0,0); ?>" placeholder="Type of Page">			
				<span class="input-group-addon" id="elna" onclick="onclkune('lna')">😆</span>
			</div>
			<div id="contlna"></div>
			<button class="btn btn-success btn-flat" type="button" onclick="na_save('fna','lna')"><i class="fa fa-save"></i> Save</button>
			</div>
		</div>
	</div>
	<?php  }
	$date = setssql($conn,"bdate","users","id",$_SESSION['user']['id'],0,0,0,0,0,0);
	$year = substr(strrchr($date,"/"), 1);
	$month = strchr(substr(strchr($date,"/"), 1),"/",true);
	$day = strchr($date,'/',true);
	if($ch != 'page'){ 
	?>
	<div class="box box-primary">
		<div class="box-body" onclick="onp_tg('bd_tg')" >
			<h4><i class="fa fa-calendar-o"></i> Birthday</h4>
			<div id="bd_tg" style="display:none;">
			<div id="bday_stet" class="input-group">
				<span class="input-group-addon">DD<br/><div>-------</div>MM<br/><div>-------</div>YYYY</span>
				<input type="text" class="form-control" name="da" value="<?php echo $day;?>" onkeypress="return isNum(event)" id="da" placeholder="Date"/>
				<input type="text" class="form-control" name="mon" value="<?php echo $month;?>" onkeypress="return isNum(event)" id="mon" placeholder="Month"/>
				<input type="text" class="form-control" name="yar" value="<?php echo $year;?>" onkeypress="return isNum(event)" id="yar" placeholder="Year"/>	
			</div>
			<button class="btn btn-success btn-flat" type="button" onclick="bd_save('da','mon','yar')"><i class="fa fa-save"></i> Save</button>
			</div>
		</div>
	</div>
	<?php } ?>
	<div class="box box-primary">
		<div class="box-body" onclick="onp_tg('pn_tg')" >
			<h4><i class="fa fa-phone"></i> Phone</h4>
			<div id="pn_tg" style="display:none;">
			<div id="pn_stet" class="input-group">
				<div class="input-group-addon"><i class="fa fa-phone"></i></div>
				<input type="text" id="phonen" maxlength="10" placeholder="Your Phone Number" value="<?php echo defindsql($conn,"mobn","users","id",$_SESSION['user']['id'],0,0,0,0,0,0); ?>" class="form-control" onkeypress="return isNum(event)"/>
			</div>
			<button class="btn btn-success btn-flat" type="button" onclick="pn_save('phonen')"><i class="fa fa-save"></i> Save</button>
			</div>
		</div>
	</div>
</div>