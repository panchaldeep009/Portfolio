<?php 
require("../common.php");
ob_start();
session_start();
if(isset($_GET['no'])){$now_msg = $_GET['no'];}else{$now_msg = 6;}
$msg_row = mysqli_query($conn, "SELECT * FROM(SELECT * FROM msg WHERE revid = ".$_SESSION['user']['id']." AND sendid = ".$_GET['id']." OR revid = ".$_GET['id']." AND sendid = ".$_SESSION['user']['id']." ORDER BY times DESC LIMIT ".$now_msg." )sub ORDER BY times"); 
$no_msg = mysqli_num_rows(mysqli_query($conn, "SELECT * FROM msg WHERE revid = ".$_SESSION['user']['id']." AND sendid = ".$_GET['id']." OR revid = ".$_GET['id']." AND sendid = ".$_SESSION['user']['id']));
if($no_msg > $now_msg){ ?>
	<div id="ms_lodcont">
	<div onclick="chats_m2(<?php echo $_GET['id'];?>,<?php echo $now_msg+6;?>)" style="clear: both;float: left;position: relative;padding: 7px;">
		<a class="red-text"><h5>Load more old messages</h5></a>
	</div>
	</div>
<?php } 
	$dmsd_Y = '';
	$dmsd_DM = '';
	while($msg = mysqli_fetch_array($msg_row)) { 
	if($_SESSION['user']['id'] == $msg['sendid']) {
	if ($dmsd_Y != date("Y", $msg['times'])){
	?>
	<div align="center" style="clear: both;position: relative;padding: 7px;">
		<p class="label label-success"> <?php echo $dmsd_Y = date("Y", $msg['times']);?> </p>
	</div>
	<?php } if ($dmsd_DM != date("jS F - l", $msg['times'])){ ?>
	<div align="center" style="clear: both;position: relative;padding: 7px;">
		<p class="label label-warning"> <?php echo $dmsd_DM = date("jS F - l", $msg['times']);?> </p>
	</div>
	<?php } ?>
	<div class="msgr">
		<div class="msgtxt">
			<?php echo $msg['msg'];?>
		</div>
		<div class="timemsg">
			<?php echo date("h:i A", $msg['times']);?> <?php if($msg['state'] == '0'){ ?><i class="fa fa-check-circle-o"></i><?php } else { ?><i class="fa fa-check"></i><?php } ?>
		</div>
	</div>
	<?php } else { 
	mysqli_query($conn, "UPDATE msg SET state='0' WHERE id = ".$msg['id']);
	if ($dmsd_Y != date("Y", $msg['times'])){
	?>
	<div align="center" style="clear: both;position: relative;padding: 7px;">
		<p class="label label-success"> <?php echo $dmsd_Y = date("Y", $msg['times']);?> </p>
	</div>
	<?php } if ($dmsd_DM != date("jS F - l", $msg['times'])){ ?>
	<div align="center" style="clear: both;position: relative;padding: 7px;">
		<p class="label label-warning"> <?php echo $dmsd_DM = date("jS F - l", $msg['times']);?> </p>
	</div>
	<?php } ?>
	<div class="msgl">
		<div class="msgtxt">
			<?php echo $msg['msg'];?>
		</div>
		<div class="timemsg">
			<?php echo date("h:i A", $msg['times']);?>
		</div>
	</div>
	<?php } } ?>
	<div id="dummy_msg" style="display:none;">
		<?php if ($dmsd_Y != date("Y")){ ?>
		<div align="center" style="clear: both;position: relative;padding: 7px;">
			<p class="label label-success"> <?php echo $dmsd_Y = date("Y");?> </p>
		</div>
		<?php } if ($dmsd_DM != date("jS F - l")){ ?>
		<div align="center" style="clear: both;position: relative;padding: 7px;">
			<p class="label label-warning"> <?php echo $dmsd_DM = date("jS F - l");?> </p>
		</div>
		<?php } ?>
	</div>