<?php 
require("../common.php");
ob_start();
session_start();
$login_ok = false;
if(isset($_GET['q'])){
$mn = trim($_GET['q']);
	if(trim($_GET['q']) == null || trim($_GET['q']) == ""){
		$error = "<i class='fa fa-times-circle-o'></i> Can't save empty !";
	} else if (strlen($mn) < 10 || strlen($mn) > 10 || !is_numeric($mn)){
		$error = "<i class='fa fa-times-circle-o'></i> Invalid your phone number !";
	} else {
		mysqli_query($conn, "UPDATE users SET mobn='".$_GET['q']."' WHERE id=".$_SESSION['user']['id']);
		$error = '<i class="fa fa-check"></i> Phone Number successfully changed.';
	}
} ?>
<div class="modal-header"><button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button><h4 class="modal-title"><?php if(isset($error)){echo $error;} ?></h4></div>