<?php 
require("../common.php");
ob_start();
session_start();
$data = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM users WHERE id = ".$_SESSION['user']['id']));
 if(!isset($_GET['f'])){
$msgsql = "SELECT a.id, a.sendid, a.revid, a.d, a.m, a.y, a.th, a.tm, a.ts, a.tap, a.times, a.msg, a.state 
FROM msg a 
INNER JOIN (SELECT a.sendid, MAX(a.id) id 
            FROM msg a 
            WHERE a.revid = ".$_SESSION['user']['id']."
            GROUP BY a.sendid
           ) AS b ON a.sendid = b.sendid AND a.id = b.id
		   order by a.times desc LIMIT 6
		   ;";
$rowmsg = mysqli_query($conn, $msgsql);
$num_msg = mysqli_num_rows(mysqli_query($conn, "SELECT * FROM msg WHERE revid = ".$_SESSION['user']['id']." AND state = 1"));
$sql = "UPDATE users SET nmsg='".$num_msg."' WHERE id=".$_SESSION['user']['id'];
$data['nmsg'] = $num_msg;?>
<div class="modal-header">
    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
    <h4 class="modal-title">Most Recent Content </h4>
</div>
<br/>
<div class="modal-body clearfix" style="height: 50%; max-height: 400px; overflow-y: auto;">
<h5 style="margin-top: -27px;"/>
<?php while($msg = mysqli_fetch_array($rowmsg)) {?>
<h4 style="border-bottom: 1.5px solid #f4f4f4"/>
<?php if($msg['state'] == '1'){ ?><div class="bg-gray"><?php } else { ?><div><?php } ?>
	<div class="box-body" href="" onclick="chats_m(<?php echo $msg['sendid'];?>)" data-toggle="modal" data-target="#blank_m">
		<div class="pull-left" style="margin-right: 10px;">
		<img src="<?php defindsql($conn,"propic","users","id","".$msg['sendid']."",0,0,0,0,0,0);?>" width="35px" class="img-circle" alt="User Image"/>
		</div>
		<h5> <?php defindsql($conn,"fname","users","id","".$msg['sendid']."",0,0,0,0,0,0);echo " ";defindsql($conn,"lname","users","id","".$msg['sendid']."",0,0,0,0,0,0);?>
		<?php $num_umsg = mysqli_num_rows(mysqli_query($conn, "SELECT * FROM msg WHERE revid = ".$_SESSION['user']['id']." AND state = 1 AND sendid = ".$msg['sendid'].""));?>
		<small><?php if(time() - setssql($conn,"llog","users","id","".$msg['sendid']."",0,0,0,0,0,0) < 5){?> <span class="time text-success"><i class="fa fa-certificate"></i> Online</span><?php } else {?> <i class="fa fa-clock-o"></i> <?php echo timeago(setssql($conn,"llog","users","id","".$msg['sendid']."",0,0,0,0,0,0)); } ?></small>
		<br/><small><i><?php echo $msg['msg'];echo " ";if($num_umsg > 1){ echo " <span class='label label-success'>".$num_umsg."</span>";}?></i></small>
		</h5>
	</div>
</div>
<?php } ?>
<br/><h5 onclick="lod_msgm2()" class="text-red"> View all Content</h5>
<?php } else {
$rows = mysqli_query($conn, "select * from connt where ".$_SESSION['user']['id']." = rid OR ".$_SESSION['user']['id']." = sid");?>
<div class="modal-header">
    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
    <h4 class="modal-title">All Content </h4>
</div>
<br/>
<div class="modal-body clearfix" style="height: 50%; max-height: 400px; overflow-y: auto;">
<h5 style="margin-top: -25px;"/>
<?php while($msg = mysqli_fetch_array($rows)) {
if($msg['sid'] == $_SESSION['user']['id']){ $id = $msg['rid'];} else { $id = $msg['sid'];} ?>
<h4 style="border-bottom: 1.5px solid #f4f4f4"/>
<div>
	<div class="box-body" href="" onclick="chats_m(<?php echo $id;?>)" data-toggle="modal" data-target="#blank_m">
		<div class="pull-left" style="margin-right: 10px;">
		<img src="<?php defindsql($conn,"propic","users","id","".$id."",0,0,0,0,0,0);?>" width="35px" class="img-circle" alt="User Image"/>
		</div>
		<h5> <?php defindsql($conn,"fname","users","id","".$id."",0,0,0,0,0,0);echo " ";defindsql($conn,"lname","users","id","".$id."",0,0,0,0,0,0);?>
		<br/><small><?php if(time() - setssql($conn,"llog","users","id","".$id."",0,0,0,0,0,0) < 5){?> <span class="time text-success"><i class="fa fa-certificate"></i> Online</span><?php } else {?> <i class="fa fa-clock-o"></i> <?php echo timeago(setssql($conn,"llog","users","id","".$id."",0,0,0,0,0,0)); } ?></small>
		</h5>
	</div>
</div>
<?php } } ?>