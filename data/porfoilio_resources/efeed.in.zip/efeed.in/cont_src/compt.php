<?php 
require("../common.php");
ob_start();
session_start();
$pid = $_GET['pid'];
	$cmtsql = "SELECT * FROM pkc WHERE types = '3' AND pid=".$pid;
	$rowcmt = mysqli_query($conn, $cmtsql);$numcom = '';
	if(mysqli_num_rows($rowcmt) > 0){$numcom = mysqli_num_rows($rowcmt);}
	?>
	<a id="tempcom_<?php echo $pid;?>">
		</a>
		<!-- ROW OF Comment -->
<?php 
	while($cmt = mysqli_fetch_array($rowcmt)) {
		$cpn = mysqli_num_rows(mysqli_query($conn, "SELECT * FROM pkc WHERE types = '4' AND pid=".$cmt['id']));
		$ckn = mysqli_num_rows(mysqli_query($conn, "SELECT * FROM pkc WHERE types = '5' AND pid=".$cmt['id']));
		if((mysqli_num_rows(mysqli_query($conn, "SELECT * FROM pkc WHERE types = '4' AND pid=".$cmt['id']." AND usid=".$_SESSION['user']['id']))) > 0 ){$act = "picked";} else if((mysqli_num_rows(mysqli_query($conn, "SELECT * FROM pkc WHERE types = '5' AND pid=".$cmt['id']." AND usid=".$_SESSION['user']['id']))) > 0 ){$act = "kicked";} else {$act = "none";}
		if($act == "picked"){$cbp = "";$cbk = "";$cicp = "fa fa-thumbs-up";$cick = "fa fa-thumbs-o-down";} else if($act == "kicked"){$cbp = "";$cbk = "";$cicp = "fa fa-thumbs-o-up";$cick = "fa fa-thumbs-down";} else if($act == "none"){$cbp = "sndcompic(".$cmt['id'].")";$cbk = "sndcomkic(".$cmt['id'].")";$cicp = "fa fa-thumbs-o-up";$cick = "fa fa-thumbs-o-down";}
		IF($cmt['usid'] != $_SESSION['user']['id']){						
		?>
		<div class="box box-default box-header" valign="middle">
			<a class="pull-left">
			<img src="<?php echo defindsql($conn,"propic","users","id","".$cmt['usid']."",0,0,0,0,0,0);?>" class="img-circle"  alt="user image" style="width:40px;"/>
			</a>
			<span class="pull-left">
			<a><strong class="text-default"> <?php echo defindsql($conn,"fname","users","id",$cmt['usid'],0,0,0,0,0,0);echo"  ";echo defindsql($conn,"lname","users","id",$cmt['usid'],0,0,0,0,0,0); ?> </strong><br/><i> -  <?php echo $cmt['com']; ?> .<i class="fa fa-quote-right"></i></i></a>
			</span>
			<span class="pull-right">
			<a><strong class="label label-success" id="cbp_<?php echo $cmt['id'];?>" onclick="<?php echo $cbp;?>"> <i id="cicp_<?php echo $cmt['id'];?>" class="<?php echo $cicp;?>"></i> <i id="cp_<?php echo $cmt['id'];?>"><?php echo $cpn;?></i></strong></a> - 
			<a><strong class="label label-danger" id="cbk_<?php echo $cmt['id'];?>" onclick="<?php echo $cbk;?>"> <i id="cick_<?php echo $cmt['id'];?>" class="<?php echo $cick;?>"></i> <i id="ck_<?php echo $cmt['id'];?>"><?php echo $ckn;?></i></strong></a> 
			</span>
		</div>
<?php	}
		else{ ?>
		<div class="box box-danger box-header" valign="middle">
		<span class="pull-left">
		<a><strong class="text-default"> You </strong><br/><i> - <?php echo $cmt['com']; ?> .<i class="fa fa-quote-right"></i></i></a>
		</span>
		<span class="pull-right">
		<a data-toggle="tooltip" title="Cannot Pick your own comment"><strong class="label label-success"> <i class="<?php echo $cicp;?>">
		</i> <?php echo $cpn;?></strong></a> - <a data-toggle="tooltip" title="Cannot Kick your own comment"><strong class="label label-danger" onclick=""> <i class="<?php echo $cick;?>">
		</i> <?php echo $ckn;?></strong></a> 
		</span>
		</div>
<?php	}
	}?>
		
<div class="box-footer">
	<div class="input-group margin">
		<span class="input-group-addon" id="ecomtx_<?php echo $pid;?>" onclick="onclkune('comtx_<?php echo $pid;?>')">😆</span>
		<textarea type="text" class="form-control" id="comtx_<?php echo $pid;?>"></textarea>
		<span class="input-group-btn">
			<button class="btn btn-primary btn-flat" onclick="sndcom(<?php echo $pid;?>)" type="button"><i class="fa fa-chevron-right"></i><i class="fa fa-chevron-right"></i><i class="fa fa-chevron-right"></i></button>
		</span>
	</div>
	<div id="contcomtx_<?php echo $pid;?>"></div>
</div>