<?php 
require("../common.php");
ob_start();
session_start();
$data = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM users WHERE id = ".$_SESSION['user']['id']));
?>
<div class="box-header" data-toggle="collapse" data-widget="collapse">
	<h3 class="box-title">Messages</h3>
</div>
<div class="box-body">											   
	<?php
	$quryrowou = "select a.*, count(m.id) as msg_count
					from users a
					left join msg m on a.`id` = m.`sendid` AND ".$_SESSION['user']['id']." = m.`revid` OR a.`id` = m.`revid` AND ".$_SESSION['user']['id']." = m.`sendid`
					left join connt b on b.`typ` != '0' where a.`id` = b.`sid` AND ".$_SESSION['user']['id']." = b.`rid` AND b.`typ` != '0' OR a.`id` = b.`rid` AND ".$_SESSION['user']['id']." = b.`sid` AND b.`typ` != '0'
					group by a.id
					order by msg_count desc limit 6 ";
	$rowinfo = mysqli_query($conn, $quryrowou);
	$nums = mysqli_num_rows(mysqli_query($conn, "SELECT * FROM users WHERE id != ".$_SESSION['user']['id']." AND ".time()." - llog < 5"));
	while($info = mysqli_fetch_array($rowinfo)) {
	if($info['id'] != $_SESSION['user']['id'] && time() - $info['llog'] < 5){?>
	<a>
		<div class="box" onclick="chats_m(<?php echo $info['id'];?>)" data-toggle="modal" data-target="#blank_m">
			<div class="box-header" data-toggle="collapse" data-widget="collapse">
				<h3 class="box-title">
					<a href="#"><img src="<?php echo $info['propic'];?>" class="img-circle"  alt="user image" style="width:40px;"/><?php echo " ".$info['fname']." ";if($info['gen'] != 'page'){echo $info['lname'];}?></a>
				</h3>
			    <div class="box-tools pull-right">
					<span class="time text-success"><i class="fa fa-certificate"></i> Online</span>
				</div>
			</div>
		</div>
	</a>
	<?php }
	else if($info['id'] != $_SESSION['user']['id']){?>
	<a>
		<div onclick="chats_m(<?php echo $info['id'];?>)" class="box" data-toggle="modal" data-target="#blank_m">
			<div class="box-header" data-toggle="collapse" data-widget="collapse">
				<h3 class="box-title">
					<a href="#"><img src="<?php echo $info['propic'];?>" class="img-circle"  alt="user image" style="width:40px;"/><?php echo " ".$info['fname']." ";if($info['gen'] != 'page'){echo $info['lname'];}?></a>
				</h3>
				<div class="box-tools pull-right">
					<span class="time"><i class="fa fa-clock-o"></i> <?php  echo timeago($info['llog']);?></span>
				</div>
			</div>
		</div>
	</a>
	<?php }	}?>						
</div><!-- /.box-body -->