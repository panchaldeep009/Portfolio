<?php 
require("../common.php");
ob_start();
session_start();
if(isset($_GET['no'])){$now_msg = $_GET['no'];}else{$now_msg = 4;}
$no_msg = mysqli_num_rows(mysqli_query($conn, "SELECT * FROM msg WHERE revid = ".$_SESSION['user']['id']." AND sendid = ".$_GET['id']." OR revid = ".$_GET['id']." AND sendid = ".$_SESSION['user']['id']));
 ?>
<div class="modal-header">
	<button type="button" onclick="clr_mod();" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
	<h4 class="modal-title"> 
	<h4 class="pull-left text-red" onclick="lod_msgm()"><i class="fa fa-arrow-left"></i> All</h4>
	<div align="center">
	<img src="<?php echo defindsql($conn,"propic","users","id","".$_GET['id']."",0,0,0,0,0,0);?>" class="img-circle" alt="user image" style="width:40px;"> <?php echo defindsql($conn,"fname","users","id",$_GET['id'],0,0,0,0,0,0);echo"  ";echo defindsql($conn,"lname","users","id",$_GET['id'],0,0,0,0,0,0); ?> 
	<br/><small class="text-Gray" id="red_chat_s"><?php 
	$llog = setssql($conn,"llog","users","id","".$_GET['id']."",0,0,0,0,0,0);
	if(time() - $llog < 5){ echo '<i class="fa fa-certificate"></i> Online';} else {echo 'Active '.timeago($llog);} ?></small>
	</div>
	</h4>
</div><br/>
<div id="chat_cont" class="modal-body clearfix" style="height: 50%; max-height: 400px; overflow-y: auto;">
<?php $msg_row = mysqli_query($conn, "SELECT * FROM(SELECT * FROM msg WHERE revid = ".$_SESSION['user']['id']." AND sendid = ".$_GET['id']." OR revid = ".$_GET['id']." AND sendid = ".$_SESSION['user']['id']." ORDER BY times DESC LIMIT ".$now_msg." )sub ORDER BY times"); 
if($no_msg > $now_msg){ ?>
	<div id="ms_lodcont">
	<div onclick="chats_m2('<?php echo $_GET['id'];?>','<?php echo $now_msg+6;?>')" style="clear: both;float: left;position: relative;padding: 7px;">
		<a class="red-text"><h5>Load more old messages</h5></a>
	</div>
	</div>
<?php } else {?>
<div id="ms_lodcont"></div>
<?php } ?>
	<?php 
	$dmsd_Y = '';
	$dmsd_DM = '';
	while($msg = mysqli_fetch_array($msg_row)) { 
	if($_SESSION['user']['id'] == $msg['sendid']) {
	if ($dmsd_Y != date("Y", $msg['times'])){
	?>
	<div align="center" style="clear: both;position: relative;padding: 7px;">
		<p class="label label-success"> <?php echo $dmsd_Y = date("Y", $msg['times']);?> </p>
	</div>
	<?php } if ($dmsd_DM != date("jS F - l", $msg['times'])){ ?>
	<div align="center" style="clear: both;position: relative;padding: 7px;">
		<p class="label label-warning"> <?php echo $dmsd_DM = date("jS F - l", $msg['times']);?> </p>
	</div>
	<?php } ?>
	<div class="msgr">
		<div class="msgtxt">
			<?php echo $msg['msg'];?>
		</div>
		<div class="timemsg">
			<small><?php echo date("h:i A", $msg['times']);?></small><?php if($msg['state'] == '0'){ ?><i class="fa fa-check-circle-o"></i><?php } else { ?><i class="fa fa-check"></i><?php } ?>
		</div>
	</div>
	<?php } else { 
	mysqli_query($conn, "UPDATE msg SET state='0' WHERE id = ".$msg['id']);
	if ($dmsd_Y != date("Y", $msg['times'])){
	?>
	<div align="center" style="clear: both;position: relative;padding: 7px;">
		<p class="label label-success"> <?php echo $dmsd_Y = date("Y", $msg['times']);?> </p>
	</div>
	<?php } if ($dmsd_DM != date("jS F - l", $msg['times'])){ ?>
	<div align="center" style="clear: both;position: relative;padding: 7px;">
		<p class="label label-warning"> <?php echo $dmsd_DM = date("jS F - l", $msg['times']);?> </p>
	</div>
	<?php } ?>
	<div class="msgl">
		<div class="msgtxt">
			<?php echo $msg['msg'];?>
		</div>
		<div class="timemsg">
			<small><?php echo date("h:i A", $msg['times']);?></small>
		</div>
	</div>
	<?php } } ?>
	<div id="dummy_msg" style="display:none;">
		<?php if ($dmsd_Y != date("Y")){ ?>
		<div align="center" style="clear: both;position: relative;padding: 7px;">
			<p class="label label-success"> <?php echo $dmsd_Y = date("Y");?> </p>
		</div>
		<?php } if ($dmsd_DM != date("jS F - l")){ ?>
		<div align="center" style="clear: both;position: relative;padding: 7px;">
			<p class="label label-warning"> <?php echo $dmsd_DM = date("jS F - l");?> </p>
		</div>
		<?php } ?>
	</div>
</div>
<script>scroll_to('chat_cont');</script>
<div class="modal-footer clearfix">
    <div class="input-group">
		<span class="input-group-addon" id="enxrtxt" onclick="onclkune('nxrtxt')">😆</span>
		<input onchange="typing_st(<?php echo $_GET['id'];?>);" type="text" id="nxrtxt" name="msg" class="form-control"/>
		<span class="input-group-btn">
			<button type='button' onclick="send_msg_u('nxrtxt','<?php echo $_GET['id'];?>','<?php echo $now_msg+1;?>');" name='seach' id='search-btn' class="btn btn-flat"><i class="fa fa-arrow-right"></i></button>
		</span>
	</div>
	<div id="contnxrtxt"></div>
</div>