<?php 
require("../common.php");
ob_start();
session_start();
if(isset($_GET['q1']) && isset($_GET['q2']) && isset($_GET['q3'])){

$d = trim($_GET['q1']);
$m = trim($_GET['q2']);
$y = trim($_GET['q3']);

if ($d == null || $d == ""){
	$er = "<i class='fa fa-times-circle-o'></i> Enter the Date!";}
else if ($d > 31 || !is_numeric($d)){
	$er = "<i class='fa fa-times-circle-o'></i> Invalide Date!";}
else if ($m == null || $m == ""){
	$er = "<i class='fa fa-times-circle-o'></i> Enter the Month!";}
else if ($m > 12 || !is_numeric($m)){
	$er = "<i class='fa fa-times-circle-o'></i> Invalide Month!";}
else if ($y == null || $y == ""){
	$er = "<i class='fa fa-times-circle-o'></i> Enter the Year!";}
else if (strlen($y) < 4 || strlen($y) > 4 || !is_numeric($y)){
	$er = "<i class='fa fa-times-circle-o'></i> Invalide Year!";}
else if ($y >= ((date('Y'))-13) || $y < 1900){
	$er = "<i class='fa fa-times-circle-o'></i> You must are not be under the age!";}
else {
	$date = $d.'/'.$m.'/'.$y;
	mysqli_query($conn, "UPDATE users SET bdate='".$date."' WHERE id=".$_SESSION['user']['id']);
	$er = '<i class="fa fa-check"></i> Birthday successfully changed.';
}
} ?>
<div class="modal-header"><button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button><h4 class="modal-title"><?php if(isset($er)){echo $er;} else {echo 'Unknown ERROR';} ?></h4></div>