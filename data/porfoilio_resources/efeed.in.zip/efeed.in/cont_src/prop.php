<?php 
require("../common.php");
ob_start();
session_start(); ?>
<div class="modal-header">
    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
    <h4 class="modal-title"><a type="button" onclick="fill_blnk_m('prof')"><i class="fa fa-chevron-left"></i></a>    <i class="fa fa-edit"></i> Profile Picture</h4>
</div>
<form name="photo" enctype="multipart/form-data" action="pp.php" method="post">
    <div class="modal-body">
		<div align="center"><img src="<?php echo setssql($conn,"propt","users","id",$_SESSION['user']['id'],0,0,0,0,0,0);?>" id="pp1" width="300px"  style="border: 3px solid red; border-radius: 3%;"/>
			<br/><br/>
			<div class="ppupload btn btn-flat">
				<div id="slbtn" class="btn btn-primary btn-flat">Choose for Change</div>
				<input id="uploadpp" type="file" name="image" class="upload" size="30" accept="image/*"/> 
			</div>
			<a id="downprop" href="<?php echo setssql($conn,"propt","users","id",$_SESSION['user']['id'],0,0,0,0,0,0);?>" download="<?php echo setssql($conn,"fname","users","id",$_SESSION['user']['id'],0,0,0,0,0,0);?>_<?php echo setssql($conn,"lname","users","id",$_SESSION['user']['id'],0,0,0,0,0,0);?>_Profile_Picture" class="btn btn-primary btn-flat"><i class="fa fa-download"></i></a>
			<input id="upbtn" class="btn btn-success btn-flat" type="submit" name="upload" value="Upload" />
		</div>
	</div>
    <div class="modal-footer clearfix">
        <button type="button" class="btn btn-danger pull-left" data-dismiss="modal"><i class="fa fa-times"></i> Discard</button>
    </div>
</form>
<script>
$(function(){
	$("#upbtn").hide();
	$("#uploadpp").change(function(){
		$("#upbtn").show();
		$("#downprop").hide();
		$("#slbtn").html('Choose another');
	});
});
document.getElementById('uploadpp').onchange = function (evt) { 
var tgt = evt.target || window.event.srcElement, files = tgt.files;
if (FileReader && files && files.length) {
var fr = new FileReader();
fr.onload = function () 
{document.getElementById('pp1').src = fr.result;} 
fr.readAsDataURL(files[0]); }
};
</script>