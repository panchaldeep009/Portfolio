<?php 
require("../common.php");
ob_start();
session_start();
$login_ok = false;
if(isset($_GET['ps'])){
	$pass = urldecode(trim($_GET['ps']));
	if($pass != "codw"){
	if($pass == null || $pass == ""){
		$error = "<i class='fa fa-times-circle-o'></i> Enter Current Password !";
	} else {
		$row = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM users WHERE id = ".$_SESSION['user']['id']));
		if($row)
        {
		
            $check_password = hash('sha256', $pass . $row['salt']);
            for($round = 0; $round < 65536; $round++)
            {
                $check_password = hash('sha256', $check_password . $row['salt']);
            }
            
            if($check_password === $row['pass'])
            {
                $login_ok = true;
            }
			else
            { 
				$error = "<i class='fa fa-times-circle-o'></i> Wrong Password !";
            }
        }
	}
	} else { $login_ok = true; }
} else { $error = "<i class='fa fa-times-circle-o'></i> Error 1 !"; }
if(isset($_GET['em'])){
if($login_ok){
$em = urldecode(trim($_GET['em']));
	$row = mysqli_num_rows(mysqli_query($conn, "SELECT * FROM users WHERE email = '".$em."'"));
	if ($em == null || $em == ""){
		$error = "<i class='fa fa-times-circle-o'></i> Enter your correct email address!";}
	else if(!$row == 0){
		$error = "<i class='fa fa-times-circle-o'></i> This email address already used.";
	}
	else if (!filter_var($em, FILTER_VALIDATE_EMAIL)) {
		$error = "<i class='fa fa-times-circle-o'></i> Invalid email format"; }
	else {
		mysqli_query($conn, "UPDATE users SET email='".$em."' WHERE id = ".$_SESSION['user']['id']);
		$error = '<i class="fa fa-check"></i> Email Address successfully changed.';
	}
}} else { $error = "<i class='fa fa-times-circle-o'></i> Error 2 !"; }
?>
<div class="modal-header"><button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button><h4 class="modal-title"><?php if(isset($error)){echo $error;} else {echo 'Unknown error';} ?></h4></div>