<?php 
require("../common.php");
ob_start();
session_start();
if(isset($_GET['q'])){
$qry = "select * from post where id = ".$_GET['q'];
$post = mysqli_fetch_assoc(mysqli_query($conn, $qry));
echo $post['text'];?>
<br /><br />
<div class="row" align="center">
<?php 
$e=0;
if($post['typ1'] != ''){$e = $e+1;}
if($post['typ2'] != ''){$e = $e+1;}
if($post['typ3'] != ''){$e = $e+1;}
if($post['typ4'] != ''){$e = $e+1;}
$use = 'not';
if($post['typ1'] != ''){
	if($use == 'not'){if($e == 1 || $e == 3){$col = '12';$use = 'yes';}else{$col = '6';$use = 'yes';}}else{$col = '6';}
	echo '<div class="col-lg-'.$col.' col-xs-12 col-md-'.$col.'"><img width="100%" src="data:'.$post['typ1'].';base64,'.$post['pic1'].'"></div>';}
if($post['typ2'] != ''){ 
	if($use == 'not'){if($e == 1 || $e == 3){$col = '12';$use = 'yes';}else{$col = '6';$use = 'yes';}}else{$col = '6';}
	echo '<div class="col-lg-'.$col.' col-xs-12 col-md-'.$col.'"><img width="100%" src="data:'.$post['typ2'].';base64,'.$post['pic2'].'"></div>';}
if($post['typ3'] != ''){ 
	if($use == 'not'){if($e == 1 || $e == 3){$col = '12';$use = 'yes';}else{$col = '6';$use = 'yes';}}else{$col = '6';}
	echo '<div class="col-lg-'.$col.' col-xs-12 col-md-'.$col.'"><img width="100%" src="data:'.$post['typ3'].';base64,'.$post['pic3'].'"></div>';}
if($post['typ4'] != ''){ 
	if($use == 'not'){if($e == 1 || $e == 3){$col = '12';$use = 'yes';}else{$col = '6';$use = 'yes';}}else{$col = '6';}
	echo '<div class="col-lg-'.$col.' col-xs-12 col-md-'.$col.'"><img width="100%" src="data:'.$post['typ4'].';base64,'.$post['pic4'].'"></div>';}?>
</div>
<?php } ?>