<?php 
require("../common.php");
ob_start();
session_start();
$num_mail = mysqli_num_rows(mysqli_query($conn, "select * from connt where rid = ".$_SESSION['user']['id']." AND typ = '0' AND rtyp != '0'"));
?>
<i class="fa fa-link"></i>
<?php if($num_mail !=	0){
	echo "<span class='label label-danger'>";echo ($num_mail);echo "</span>";
} ?>