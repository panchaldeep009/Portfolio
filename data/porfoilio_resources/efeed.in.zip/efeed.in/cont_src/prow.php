<?php 
require("../common.php");
ob_start();
session_start();
$num_POST = mysqli_num_rows(mysqli_query($conn, "SELECT * FROM post"));
?>
<p id="npr" style="display:none;"><?php echo $num_POST;?></p>