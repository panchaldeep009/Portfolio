<?php 
require("../common.php");
ob_start();
session_start();
if(isset($_GET['messages'])){
$sql = "UPDATE users SET nmsg='0' WHERE id=".$_SESSION['user']['id'];
mysqli_query($conn, $sql);
$sql = "UPDATE msg SET state='0' WHERE revid = ".$_SESSION['user']['id']." AND state = 1";
mysqli_query($conn, $sql);
}
if(isset($_GET['nots'])){

$sql = "UPDATE users SET nnot='0' WHERE id=".$_SESSION['user']['id'];
mysqli_query($conn, $sql);
$sql = "UPDATE nots SET state='0' WHERE revid = ".$_SESSION['user']['id']." AND state = 1 revid != 0 ";
mysqli_query($conn, $sql);
} 
if(isset($_GET['notis'])){

$sql = "UPDATE users SET nnot='0' WHERE id=".$_SESSION['user']['id'];
mysqli_query($conn, $sql);
$sql = "UPDATE nots SET state='0' WHERE revid = '".$_SESSION['user']['id']."' AND state = '1' OR revid = '0' AND state = '1'";
mysqli_query($conn, $sql);
} 
if(isset($_GET['mail'])){

$sql = "UPDATE users SET nmail='0' WHERE id=".$_SESSION['user']['id'];
mysqli_query($conn, $sql);
$sql = "UPDATE mail SET state='0' WHERE revid = ".$_SESSION['user']['id']." AND state = 1";
mysqli_query($conn, $sql);

} 
if(isset($_GET['crd5'])){
$sql = "UPDATE users SET crd=5 WHERE id = ".$_SESSION['user']['id']."";
mysqli_query($conn, $sql);
} 
if(isset($_GET['pick']) && $_GET['pick'] != '' && $_GET['pick'] != null){
mysqli_query($conn, "INSERT into pkc(types,pid,usid,times) values ('1','".$_GET['pick']."','".$_SESSION['user']['id']."','".time()."')");
$num = mysqli_num_rows(mysqli_query($conn, "SELECT * FROM pkc WHERE types = '1' AND pid = ".$_GET['pick']));
mysqli_query($conn, "UPDATE post SET npic='".$num."' WHERE id=".$_GET['pick']);
$pid = setssql($conn,'pid','post','id',$_GET['pick'],'0','0','0','0','0','0');
if($pid != $_SESSION['user']['id']){
mysqli_query($conn, "INSERT into nots(revid,nots,ic,aid,atb,atxt,aid2,atb2,atxt2,times,state) values ('".$pid."',' is give Pick your ','fa fa-thumbs-o-up bg-green','".$_SESSION['user']['id']."','user','','".$_GET['pick']."','post','Post','".time()."','1')");
}
} 
if(isset($_GET['kick']) && $_GET['kick'] != '' && $_GET['kick'] != null){
mysqli_query($conn, "INSERT into pkc(types,pid,usid,times) values ('2','".$_GET['kick']."','".$_SESSION['user']['id']."','".time()."')");
$num = mysqli_num_rows(mysqli_query($conn, "SELECT * FROM pkc WHERE types = '2' AND pid = ".$_GET['kick']));
mysqli_query($conn, "UPDATE post SET nkic='".$num."' WHERE id=".$_GET['kick']);
$pid = setssql($conn,'pid','post','id',$_GET['kick'],'0','0','0','0','0','0');
if($pid != $_SESSION['user']['id']){
mysqli_query($conn, "INSERT into nots(revid,nots,ic,aid,atb,atxt,aid2,atb2,atxt2,times,state) values ('".$pid."',' is give Kick your ','fa fa-thumbs-o-down bg-red','".$_SESSION['user']['id']."','user','','".$_GET['kick']."','post','Post','".time()."','1')");
}
} 
if(isset($_GET['com']) && $_GET['text'] != '' && $_GET['text'] != null){
mysqli_query($conn, "INSERT into pkc(types,pid,usid,times,com) values ('3','".$_GET['com']."','".$_SESSION['user']['id']."','".time()."','".$_GET['text']."')");
$num = mysqli_num_rows(mysqli_query($conn, "SELECT * FROM pkc WHERE types = '3' AND pid = ".$_GET['com']));
mysqli_query($conn, "UPDATE post SET ncom='".$num."' WHERE id=".$_GET['com']);
$pid = setssql($conn,'pid','post','id',$_GET['com'],'0','0','0','0','0','0');
if($pid != $_SESSION['user']['id']){
mysqli_query($conn, "INSERT into nots(revid,nots,ic,aid,atb,atxt,aid2,atb2,atxt2,times,state) values ('".$pid."',' comment on your ','fa fa-quote-left bg-blue','".$_SESSION['user']['id']."','user','','".$_GET['com']."','post',' Post \"".$_GET['text']."\"','".time()."','1')");
}
} 
if(isset($_GET['comp']) && $_GET['comp'] != '' && $_GET['comp'] != null){
mysqli_query($conn, "INSERT into pkc(types,pid,usid,times) values ('4','".$_GET['comp']."','".$_SESSION['user']['id']."','".time()."')");
}
if(isset($_GET['comk']) && $_GET['comk'] != '' && $_GET['comk'] != null){
mysqli_query($conn, "INSERT into pkc(types,pid,usid,times) values ('5','".$_GET['comk']."','".$_SESSION['user']['id']."','".time()."')");
} 
if(isset($_GET['d_post']) && $_GET['d_post'] != '' && $_GET['d_post'] != null){
mysqli_query($conn, "DELETE FROM post WHERE id = ".$_GET['d_post']);
} 
if(isset($_GET['nctext']) && $_GET['nctext'] != ''){
mysqli_query($conn, "INSERT into notice(pid,had,detl,times) values ('".$_SESSION['user']['id']."','".$_GET['nctext']."','".$_GET['dtl']."','".time()."')");
}
if(isset($_GET['sreq']) && $_GET['sreq'] != ''){
mysqli_query($conn, "INSERT into connt(sid,rid,typ,rtyp,times) values ('".$_SESSION['user']['id']."','".$_GET['sreq']."','0','".$_GET['sreqtyp']."','".time()."')");
}
if(isset($_GET['cereq']) && $_GET['cereq'] != ''){
mysqli_query($conn, "DELETE FROM connt WHERE rid = ".$_GET['cereq']." AND sid = ".$_SESSION['user']['id']);
}
if(isset($_GET['swreq']) && $_GET['swreq'] != '' && isset($_GET['swnty']) && $_GET['swnty'] != ''){
mysqli_query($conn, "UPDATE connt SET rtyp='".$_GET['swnty']."' WHERE rid = ".$_GET['swreq']." AND sid = ".$_SESSION['user']['id']);
}
if(isset($_GET['del_rel']) && $_GET['del_rel'] != ''){
$did = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM connt WHERE rid = ".$_GET['del_rel']." AND sid = ".$_SESSION['user']['id']." OR sid = ".$_GET['del_rel']." AND rid = ".$_SESSION['user']['id']));
if($did['rid'] == $_SESSION['user']['id']){$id = $did['sid'];}
else if($did['sid'] == $_SESSION['user']['id']){$id = $did['rid'];}
if($did['typ'] == '2'){$txt = 'In Family';}
else if($did['typ'] == '3'){$txt = 'Classmate';}
else{$txt = 'Friend';}
mysqli_query($conn, "DELETE FROM connt WHERE rid = ".$_GET['del_rel']." AND sid = ".$_SESSION['user']['id']." OR sid = ".$_GET['del_rel']." AND rid = ".$_SESSION['user']['id']);
mysqli_query($conn, "INSERT into nots(revid,nots,ic,aid,atb,atxt,aid2,atb2,atxt2,times,state) values ('".$id."',' Remove you from ','fa fa-unlink bg-maroon','".$_SESSION['user']['id']."','user','','".$_SESSION['user']['id']."','user','".$txt."','".time()."','1')");
}
if(isset($_GET['acreq']) && $_GET['acreq'] != ''){
$req_data = mysqli_fetch_assoc(mysqli_query($conn, "select * from connt where ".$id." = sid AND ".$_SESSION['user']['id']." = rid AND typ = '0' AND rtyp != '0'"));
mysqli_query($conn, "UPDATE connt SET typ=rtyp WHERE sid = ".$_GET['acreq']." AND rid = ".$_SESSION['user']['id']);
$ty = setssql($conn,'rtyp','connt','sid',$_GET['acreq'],'AND','rid',$_SESSION['user']['id'],'0','0','0');
if($ty == '2'){$txt = 'In Family Request';}
else if($ty == '3'){$txt = 'Classmate Request';}
else{$txt = 'Friend Request';}
mysqli_query($conn, "INSERT into nots(revid,nots,ic,aid,atb,atxt,aid2,atb2,atxt2,times,state) values ('".$_GET['acreq']."',' Accept your ','fa fa-users bg-yellow','".$_SESSION['user']['id']."','user','','".$_SESSION['user']['id']."','user','".$txt."','".time()."','1')");
}
if(isset($_GET['regreq']) && $_GET['regreq'] != ''){
$ty = setssql($conn,'rtyp','connt','sid',$_GET['acreq'],'AND','rid',$_SESSION['user']['id'],'0','0','0');
mysqli_query($conn, "DELETE FROM connt WHERE sid = ".$_GET['regreq']." AND rid = ".$_SESSION['user']['id']);
if($ty == '2'){$txt = 'In Family Request';}
else if($ty == '3'){$txt = 'Classmate Request';}
else{$txt = 'Friend Request';}
mysqli_query($conn, "INSERT into nots(revid,nots,ic,aid,atb,atxt,aid2,atb2,atxt2,times,state) values ('".$_GET['acreq']."',' Reject your ','fa fa-users bg-red','".$_SESSION['user']['id']."','user','','".$_SESSION['user']['id']."','user','".$txt."','".time()."','1')");
}
if(isset($_GET['bm_post']) && $_GET['bm_post'] != '' && $_GET['bm_post'] != null){
mysqli_query($conn, "INSERT into bmstp(types,pid,usid,times) values ('1','".$_GET['bm_post']."','".$_SESSION['user']['id']."','".time()."')");
$pid = setssql($conn,'pid','post','id',$_GET['bm_post'],'0','0','0','0','0','0');
if($pid != $_SESSION['user']['id']){
mysqli_query($conn, "INSERT into nots(revid,nots,ic,aid,atb,atxt,aid2,atb2,atxt2,times,state) values ('".$pid."',' Saved your ','fa fa-bookmark bg-purple','".$_SESSION['user']['id']."','user','','".$_GET['bm_post']."','post',' Post ','".time()."','1')");
}
}
if(isset($_GET['s_msg']) && $_GET['s_msg'] != '' && isset($_GET['to']) && $_GET['to'] != ''){
mysqli_query($conn, "INSERT into msg(sendid,revid,times,msg,state) values ('".$_SESSION['user']['id']."', '".$_GET['to']."', '".time()."', '".$_GET['s_msg']."', '1')");
}
if(isset($_GET['ty_msg']) && $_GET['ty_msg'] != ''){
$no = mysqli_num_rows(mysqli_query($conn, "SELECT * FROM typing WHERE sid = ".$_SESSION['user']['id']." AND rid = ".$_GET['ty_msg']));
if($no > 0){
mysqli_query($conn, "UPDATE typing SET times='".time()."' WHERE sid = ".$_SESSION['user']['id']." AND rid = ".$_GET['ty_msg']);
} else {
mysqli_query($conn, "INSERT into typing(sid,rid,times,ext) values ('".$_SESSION['user']['id']."', '".$_GET['ty_msg']."', '".time()."', '')");}
}
if(isset($_GET['follw']) && $_GET['follw'] != ''){
mysqli_query($conn, "INSERT into connt(sid,rid,typ,rtyp,times) values ('".$_SESSION['user']['id']."','".$_GET['follw']."','5','5','".time()."')");
mysqli_query($conn, "INSERT into nots(revid,nots,ic,aid,atb,atxt,aid2,atb2,atxt2,times,state) values ('".$_GET['follw']."',' Follow your Page','fa fa-hand-o-right bg-orange','".$_SESSION['user']['id']."','user','','','','','".time()."','1')");
}
if(isset($_GET['ufolw']) && $_GET['ufolw'] != ''){
mysqli_query($conn, "DELETE FROM connt WHERE sid = ".$_SESSION['user']['id']." AND rid = ".$_GET['ufolw']);
}
?>