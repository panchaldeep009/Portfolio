<?php 
require("../common.php");
ob_start();
session_start();
$sts = '';
$no = mysqli_num_rows(mysqli_query($conn, "SELECT * FROM typing WHERE rid = ".$_SESSION['user']['id']." AND sid = ".$_GET['id']));
if($no > 0){
$stc = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM typing WHERE rid = ".$_SESSION['user']['id']." AND sid = ".$_GET['id'])); 
$tc = time() - $stc['times'];
if($tc < 3){$sts = 't';} else {$sts = '';} 
}
$llog = setssql($conn,"llog","users","id","".$_GET['id']."",0,0,0,0,0,0);
if(time() - $llog < 5){ echo '<i class="fa fa-certificate"></i> Online';} else {echo 'Active '.timeago($llog);} 
if($sts == 't'){ echo ' - <i> typing... </i>';}?>