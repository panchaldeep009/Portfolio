<?php 
require("../common.php");
ob_start();
session_start();
$login_ok = false;
if(isset($_GET['op'])){
	$pass = urldecode(trim($_GET['op']));
	if($pass == null || $pass == ""){
		$error = "<i class='fa fa-times-circle-o'></i> Enter Current Password !";
	} else {
		$row = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM users WHERE id = ".$_SESSION['user']['id']));
		if($row)
        {
		
            $check_password = hash('sha256', $pass . $row['salt']);
            for($round = 0; $round < 65536; $round++)
            {
                $check_password = hash('sha256', $check_password . $row['salt']);
            }
            
            if($check_password === $row['pass'])
            {
                $login_ok = true;
            }
			else
            { 
				$error = "<i class='fa fa-times-circle-o'></i> Wrong current Password !";
            }
        }
	}
} else { $error = "<i class='fa fa-times-circle-o'></i> Error 1 !"; }
if(isset($_GET['np']) && isset($_GET['cp'])){
if($login_ok){
$pass = urldecode(trim($_GET['np']));
$cpass = urldecode(trim($_GET['cp']));
	if ($pass == null || $pass == ""){
		$error = "<i class='fa fa-times-circle-o'></i> Enter the new password!";}
	else if (strlen($pass) < 6){
		$error = "<i class='fa fa-times-circle-o'></i> Minimum 6 letter is Required in Password!";}
	else if ($cpass == null || $cpass == ""){
		$error = "<i class='fa fa-times-circle-o'></i> Enter the confirm password!";}
	else if ($pass != $cpass){
		$error = "<i class='fa fa-times-circle-o'></i> Re-entered password is not match!";}
	else {
		$salt = dechex(mt_rand(0, 2147483647)) . dechex(mt_rand(0, 2147483647));
		$pass = hash('sha256', $pass . $salt);
		for($round = 0; $round < 65536; $round++)
		{
			$pass = hash('sha256', $pass . $salt);
		}
		mysqli_query($conn, "UPDATE users SET pass='".$pass."',salt='".$salt."' WHERE id = ".$_SESSION['user']['id']);
		$error = '<i class="fa fa-check"></i> Password successfully changed.';
	}
}} else { $error = "<i class='fa fa-times-circle-o'></i> Error 2 !"; }
?>
<div class="modal-header"><button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button><h4 class="modal-title"><?php if(isset($error)){echo $error;} else {echo 'Unknown error';} ?></h4></div>