<?php 
require("../common.php");
ob_start();
session_start();
$data = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM users WHERE id = ".$_SESSION['user']['id']));
$mailsql = "SELECT a.id, a.sendid, a.revid, a.d, a.m, a.y, a.th, a.tm, a.ts, a.tap, a.times, a.sub, a.state 
FROM mail a 
INNER JOIN (SELECT a.sendid, MAX(a.id) id 
            FROM mail a 
            WHERE a.state = '1' AND a.revid = ".$_SESSION['user']['id']."
            GROUP BY a.sendid
           ) AS b ON a.sendid = b.sendid AND a.id = b.id
		   order by a.times desc LIMIT 10
		   ;";
$rowmail = mysqli_query($conn, $mailsql);
$num_mail = mysqli_num_rows(mysqli_query($conn, "SELECT * FROM mail WHERE revid = ".$_SESSION['user']['id']." AND state = 1"));
$sql = "UPDATE users SET nmail='".$num_mail."' WHERE id=".$_SESSION['user']['id'];
$data['nmail'] = $num_mail;?>
	<li class="header">You have <?php if($data['nmail'] != 0){ echo ($data['nmail'])." Email <div align='right'><button onclick='mailnull()' class='btn btn-primary btn-flat'>Clear</button></div>"; } else { echo "no emails";}?></li>
	<li>
		<ul class="menu">
		<?php while($mail = mysqli_fetch_array($rowmail)) {?>
		
			<li>
				<a href="#">
					<h3>
						<?php
						$num_umail = mysqli_num_rows(mysqli_query($conn, "SELECT * FROM mail WHERE revid = ".$_SESSION['user']['id']." AND state = 1 AND sendid = ".$mail['sendid'].""));
						?>
						<div class="pull-left text-danger"><?php defindsql($conn,"email","users","id","".$mail['sendid']."",0,0,0,0,0,0);?>
						<?php echo " ";if($num_umail > 1){ echo " <span class='label label-danger'>".$num_umail."</span>";}?>
						</div>
						<small class="pull-right"><i class="fa fa-clock-o"></i><?php echo " ".timeago($mail['times']);?></small>
					</h3>
					<h3><br />
						<?php echo $mail['sub'];?>
					</h3>
				</a>
			</li>
			
		<?php }?>
		</ul>
		<?php $rlnum_mail = mysqli_num_rows($rowmail);
		if($rlnum_mail > 10){
		$leftmail = $rlnum_mail - 10;?>
		<div align="center"><?php echo $leftmail." ";?> More</div><?php }?>
	</li>
	<li class="footer"><a href="#">View all Email</a></li>