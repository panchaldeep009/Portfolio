<?php

    require("common.php");
    ob_start();
session_start();
    unset($_SESSION['user']);
    header("Location: login.php");
    die("Redirecting to: login.php");
?> 