<?php
    include '_set-db.php';
    $username = $usered;
    $password = $passed;
    $host = $hosted;
    $dbname = $dbed;

    $options = array(PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES utf8');
    
    try
    {
        $db = new PDO("mysql:host={$host};dbname={$dbname};charset=utf8", $username, $password, $options);
    }
    catch(PDOException $ex)
    {
        die("Failed to connect to the database: " . $ex->getMessage());
    }
    
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $db->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
    

    if(function_exists('get_magic_quotes_gpc') && get_magic_quotes_gpc())
    {
        function undo_magic_quotes_gpc(&$array)
        {
            foreach($array as &$value)
            {
                if(is_array($value))
                {
                    undo_magic_quotes_gpc($value);
                }
                else
                {
                    $value = stripslashes($value);
                }
            }
        }
    
        undo_magic_quotes_gpc($_POST);
        undo_magic_quotes_gpc($_GET);
        undo_magic_quotes_gpc($_COOKIE);
    }
$conn = new mysqli($hosted, $usered, $passed, $dbed);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
function defindsql($conn,$label,$table,$whereq,$wherea,$rl1,$whereq1,$wherea1,$rl2,$whereq2,$wherea2) {
		if($rl1 == 0){$rl1 = '';}
		if($rl2 == 0){$rl2 = '';}
		if($wherea1 == 0){$wherea1 = '';} else {$wherea1 = '='.$wherea1;}
		if($wherea2 == 0){$wherea2 = '';} else {$wherea2 = '='.$wherea2;}
		if($whereq1 == 0){$whereq1 = '';}
		if($whereq2 == 0){$whereq2 = '';}
       	$data = mysqli_fetch_assoc(mysqli_query($conn, "SELECT ".$label." FROM ".$table." WHERE ".$whereq."=".$wherea." ".$rl1." ".$whereq1." ".$wherea1." ".$rl2." ".$whereq2." ".$wherea2));
	    echo $data[''.$label.''];
	}

	function setssql($conn,$label,$table,$whereq,$wherea,$rl1,$whereq1,$wherea1,$rl2,$whereq2,$wherea2) {
		if($rl1 == 0){$rl1 = '';}
		if($rl2 == 0){$rl2 = '';}
		if($wherea1 == 0){$wherea1 = '';} else {$wherea1 = '='.$wherea1;}
		if($wherea2 == 0){$wherea2 = '';} else {$wherea2 = '='.$wherea2;}
		if($whereq1 == 0){$whereq1 = '';}
		if($whereq2 == 0){$whereq2 = '';}
       	$data = mysqli_fetch_assoc(mysqli_query($conn, "SELECT ".$label." FROM ".$table." WHERE ".$whereq."=".$wherea." ".$rl1." ".$whereq1." ".$wherea1." ".$rl2." ".$whereq2." ".$wherea2));
	    return $data[''.$label.''];
	}
function timeago($ptime)
{
    $etime = time() - $ptime;

    if ($etime < 6 )
    {
        return 'Just now';
    }

    $a = array( 365 * 24 * 60 * 60  =>  'year',
                 30 * 24 * 60 * 60  =>  'month',
                      24 * 60 * 60  =>  'day',
                           60 * 60  =>  'hour',
                                60  =>  'minute',
                                 1  =>  'second'
                );
    $a_plural = array( 'year'   => 'years',
                       'month'  => 'months',
                       'day'    => 'days',
                       'hour'   => 'hours',
                       'minute' => 'minutes',
                       'second' => 'sec'
                );

    foreach ($a as $secs => $str)
    {
        $d = $etime / $secs;
        if ($d >= 1)
        {
            $r = round($d);
            return $r . ' ' . ($r > 1 ? $a_plural[$str] : $str) . ' ago';
        }
    }
}

?>
                            
                            
                            
                            
                            
                            