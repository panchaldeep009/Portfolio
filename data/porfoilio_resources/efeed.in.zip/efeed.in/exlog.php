<?php

    require("common.php");
    ob_start();
session_start();
    if(empty($_SESSION['user']))
    {	
		if(isset($_GET['q']) && isset($_GET['q'])){
			$q = "SELECT * FROM users WHERE pass = '".$_GET['q']."' AND salt = '".$_GET['q1']."'";
			$ch = mysqli_num_rows(mysqli_query($conn, $q));
			if($ch != 0){
				$_SESSION['user'] = mysqli_fetch_assoc(mysqli_query($conn, $q));
				header("Location: index.php");
				die("Redirecting to: index.php");
			} else { header("Location: login.php"); }
		} else {
			header("Location: login.php");
		}
    }
	$data = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM users WHERE id = ".$_SESSION['user']['id']));
	$em    = false;
	$mn    = false;
	$gen   = false;
	$bdate = false;
	if(trim($data['email']) == ''){ $em = true;}
	if(trim($data['mobn']) == ''){ $mn = true;}
	if(trim($data['stet']) == ''){ mysqli_query($conn, "UPDATE users SET stet='I am on eFeed ;)' WHERE id = ".$_SESSION['user']['id']); }
	if(trim($data['gen']) == ''){ $gen = true; }
	if(trim($data['bdate']) == ''){ $bdate = true; }
	if(trim($data['prop']) == ''){ mysqli_query($conn, "UPDATE users SET prop='pic/avtar/user_m.jpg',propt='pic/avtar/user_m_t.jpg',propic='pic/avtar/user_m_ic.jpg' WHERE id = ".$_SESSION['user']['id']); }
	if(!$em && !$mn && !$gen && !$bdate){
		if($data['crd']<0){
			header("Location: chp.php");
		} else {
		header("Location: index.php"); }
	}
	if(!empty($_POST)){
		if(isset($_POST["em"]))   {
			$em = $_POST["em"];
			if($em != null || $em != "" && filter_var($em, FILTER_VALIDATE_EMAIL)){
			$emq = "
						SELECT
							1
						FROM users 
						WHERE
							email = :email
					";
					$emq_params = array(
						':email' => $_POST['email'] );
					try
					{$emstmt = $db->prepare($emq);
					 $emresult = $emstmt->execute($emq_params);}
					catch(PDOException $ex)
					{die("Failed to run query: " . $ex->getMessage());}
				$emf = $emstmt->fetch();
			}
			if ($em == null || $em == ""){
				$er = "<i class='fa fa-times-circle-o'></i> Enter your correct email address!";
				die();}
			else if (!filter_var($em, FILTER_VALIDATE_EMAIL)) {
				$er = "<i class='fa fa-times-circle-o'></i> Invalid email format";
				die();}
			else if($emf){
				$er = "<i class='fa fa-times-circle-o'></i> Emailaddress is already used.";
				die();}
			else { $T = "UPDATE `users` SET
				`email` = '".$em."'
				WHERE `id` = ".$_SESSION['user']['id'];
				mysqli_query($conn, $T); 
				$em    = false;
				}
		}
		if(isset($_POST["mn"]))   {
			$mn = $_POST["mn"];
			if ($mn == null || $mn == ""){
			$er = "<i class='fa fa-times-circle-o'></i> Enter your phone number!";}
			else if (strlen($mn) < 10 || strlen($mn) > 10 || !is_numeric($mn)){
			$er = "<i class='fa fa-times-circle-o'></i> Invalid your phone number !";}
			else{
			$T = "UPDATE `users` SET
			`mobn` = '".$mn."'
			WHERE `id` = ".$_SESSION['user']['id'];
			mysqli_query($conn, $T);
			$mn = false;
			}
		} 
		if(isset($_POST["gen"]))  {
			$gen = $_POST["gen"];
			if (empty($_POST["gen"])){
			$er = "<i class='fa fa-times-circle-o'></i> Select your gender!";}
			else {
				$T = "UPDATE `users` SET
				`gen` = '".$gen."'
				WHERE `id` = ".$_SESSION['user']['id'];
				mysqli_query($conn, $T);
				$gen = false;
			}
		}
		if(isset($_POST["date"]) || isset($_POST["month"]) || isset($_POST["year"])) {
			$d = $_POST["date"];
			$m = $_POST["month"];
			$y = $_POST["year"];
			if ($d == null || $d == ""){
				$er = "<i class='fa fa-times-circle-o'></i> Enter the Date!";}
			else if ($d > 31 || !is_numeric($d)){
				$er = "<i class='fa fa-times-circle-o'></i> Invalide Date!";}
			else if ($m == null || $m == ""){
				$er = "<i class='fa fa-times-circle-o'></i> Enter the Month!";}
			else if ($m > 12 || !is_numeric($m)){
				$er = "<i class='fa fa-times-circle-o'></i> Invalide Month!";}
			else if ($y == null || $y == ""){
				$er = "<i class='fa fa-times-circle-o'></i> Enter the Year!";}
			else if (strlen($y) < 4 || strlen($y) > 4 || !is_numeric($y)){
				$er = "<i class='fa fa-times-circle-o'></i> Invalide Year!";}
			else if ($y >= ((date('Y'))-13) || $y < 1900){
				$er = "<i class='fa fa-times-circle-o'></i> You must are not be under the age!";}
			else if (!checkdate($m,$d,$y)){
				$er = "<i class='fa fa-times-circle-o'></i> Invalide Birthdate!";}
			else{
				$T = "UPDATE `users` SET
					`bdate` = '".$d."/".$m."/".$y."'
					WHERE `id` = ".$_SESSION['user']['id'];
					mysqli_query($conn, $T);
				$bdate = false;
			}
		}
	if(!$em && !$mn && !$gen && !$bdate){
		$T = "UPDATE `users` SET
		`crd` = '-100'
		WHERE `id` = ".$_SESSION['user']['id'];
		mysqli_query($conn, $T);
		header("Location: chp.php");
	}
}
?>
<!DOCTYPE html>

<html>


    <head>
        <meta charset="UTF-8">
        <title>Complete Information | eFeed</title>
        <meta content='width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no' name='viewport'>
        <link href="met/css/bootstrap.css" rel="stylesheet" type="text/css" />
        <link href="met/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
        <link href="met/css/AdminLTE.css" rel="stylesheet" type="text/css" />
		<link rel="shortcut icon" href="images/favicon.png"> 
		<script>
		function isNum(evt) {
	evt = (evt) ? evt : window.event;
	var charCode = (evt.which) ? evt.which : evt.keyCode;
	if (charCode > 31 && (charCode < 48 || charCode > 57)) {
		return false;
	}
	return true;
}
		</script>
    </head>
	
	
    <body class="skin-blue fixed">
        <header class="header">
            <a href="index.php" align="right" class="logo">
                <img src="images/logo.png" alt="LOGO"/>
            </a>
            <nav class="navbar navbar-static-top" role="navigation">
                <a href="#" class="navbar-btn sidebar-toggle">
					<div class="lomenbar">
                    <span class="sr-only">Toggle navigation</span>
                    <img  src="images/logo.png" alt="LOGO"/>
					</div>
                </a>
                   
                <div class="navbar-right">
                    <ul class="nav navbar-nav" >
						<li class="dropdown user user-menu">
							<a href="#" class="dropdown-toggle" data-toggle="dropdown">
								<i class="glyphicon glyphicon-user"></i>
									<span><?php echo htmlentities($data['uname'], ENT_QUOTES, 'UTF-8'); ?> <i class="caret"></i></span>
							</a>
							<ul class="dropdown-menu">
								<li class="user-header">
									<img src="<?php echo ($data['propt']); ?>" class="img-circle" alt="User Image" />
										<p>
											<?php echo $data['fname']." ".$data['lname'];?>
											<small><?php echo $data['email'];?></small>
										</p>
								</li>
								<li class="user-footer">
									<div class="pull-right">
										<a href="logout.php" class="btn btn-default btn-flat"><i class="fa fa-sign-out"></i> Logout</a>
									</div>
								</li>
							</ul>
						</li>
                    </ul>
                </div>
            </nav>
        </header>
        <div class="wrapper row-offcanvas row-offcanvas-left">

            <aside class="right-side">
                <section class="content">
                    <div class="row">
						
                        <section class="col-lg-9">
						
							<form method="post" action="exlog.php">
								<div class="box box-solid">
									<div class="box-header">
										<div class="box-title">Complete Info</div>
										<br/><i style="color:red;"><?php if(isset($er)){echo $er;} ?></i>
									</div>
									<div class="box-body">
										<?php if($em){ ?>
										<div class="input-group">
											<span class="input-group-addon">@ Email address</span>
											<input type="email" id="em" name="em" value="<?php if(isset($_POST['em'])){echo $_POST['em'];}?>" class="form-control" placeholder="Email Address.">
										</div>
										<?php } 
										if($mn){ ?>
										<div class="input-group">
											<span class="input-group-addon"><i class="fa fa-phone"></i> Phone Number</span>
											<input type="text" maxlength="10" id="mn" name="mn" onkeypress="return isNum(event)" value="<?php if(isset($_POST['mn'])){echo $_POST['mn'];}?>" class="form-control" placeholder="Phone Number.">
										</div>
										<?php } 
										if($gen){ ?>
										<div class="form-group" align="center">
											Choose Gender :<br/>
											<label>
												<input type="radio" name="gen" class="minimal-rad" value="male" <?php if((isset($_POST['gen']) && $_POST['gen']=='female') || (isset($_POST['gen']) && $_POST['gen']!='male')){echo '';} else { echo 'checked';} ?> /> Male
											</label>
											<label>
												<input type="radio" name="gen" class="minimal-rad" value="female" <?php if(isset($_POST['gen']) && $_POST['gen']=='female'){echo 'checked';} ?>/> Female
											</label>
										</div>
										<?php } 
										if($bdate){ ?>
										<div id="bday_stet" class="input-group <?php if(isset($ef4)){echo $ef4;}?>">
											<span class="input-group-addon"><i class="fa fa-calendar"></i> Birthday:</span>
											<span class="input-group-addon">DD<br/><div>-------</div>MM<br/><div>-------</div>YYYY</span>
											<input type="text" class="form-control" name="date" value="<?php if(isset($_POST['date'])){echo $_POST['date'];}?>" onkeypress="return isNum(event)" id="date" placeholder="Date"/>
											<input type="text" class="form-control" name="month" value="<?php if(isset($_POST['month'])){echo $_POST['month'];}?>" onkeypress="return isNum(event)" id="month" placeholder="Month"/>
											<input type="text" class="form-control" name="year" value="<?php if(isset($_POST['year'])){echo $_POST['year'];}?>" onkeypress="return isNum(event)" id="year" placeholder="Year"/>	
										</div>
										<?php } ?>
									</div>
									<div class="box-footer"><div align="right">
									<button class="btn btn-primary btn-flat" type="submit"> Next <i class="fa fa-arrow-right"></i></button>
									</div>
									</div>
								</div>
							</form>	
						
                        </section>

					</div>
					
				</section>
				
            </aside>
			
        </div>
		<footer class="footer">
			<div align="center" style="border-top: 2px solid #f1f1f1">
			<a href="index.php"> Home </a> - <a href="eFeed"> About </a> - <a href="legal/terms"> Terms </a> - <a href="about/privacy"> Privacy </a> - <a href="help"> Help </a> - <a href="about/privacy/cookies"> Cookies </a><br/>
			 eFeed © 2015 (English (US))
			</div>
        </footer>

		
<!-- ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ -->

													<!-- Show clear -->

<!-- ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ -->


        <!-- jQuery 2.0.2 -->
        <script src="http://ajax.googleapis.com/ajax/libs/jquery/2.0.2/jquery.min.js"></script>
		<script type='text/javascript' src='met/js/jquery-1.10.1.js'></script>
        <script src="met/js/jquery-ui-1.10.3.min.js" type="text/javascript"></script>
        <script src="met/js/bootstrap.min.js" type="text/javascript"></script>
        <script src="met/js/plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.all.min.js" type="text/javascript"></script>


	
    </body>
</html>
<?php

?>