<?php
ini_set('user_agent', 'QRA_Ball/1.0 (http://eFeed.in/qra/index.php; adunicraphix@gmail.com)');
ini_set('default_charset', 'utf-8');
new DateTimeZone("Asia/Kolkata");
date_default_timezone_set("Asia/Kolkata");
if(isset($_GET['q'])){
	$q = urldecode($_GET['q']);
	$bq = $q;
	$weather = false;
	$w1 = false;
	$w2 = false;
	$w3 = false;
	$w4 = false;
	$w5 = false;
	$w6 = false;
	
	if(strpos($q,'weather') !== false){$w1 = true; $q = str_replace('weather', '', $q);}
	else if(strpos($q,'current weather') !== false){$w1 = true; $q = str_replace('current weather', '', $q);}
	if(strpos($q,'temperature') !== false){$w1 = true; $q = str_replace('temperature', '', $q);}
	else if(strpos($q,'current temperature') !== false){$w1 = true; $q = str_replace('current temperature', '', $q);}
	if(strpos($q,'pressure') !== false){$w1 = true; $q = str_replace('pressure', '', $q);}
	else if(strpos($q,'current pressure') !== false){$w1 = true; $q = str_replace('current pressure', '', $q);}
	if(strpos($q,'humidity') !== false){$w1 = true; $q = str_replace('humidity', '', $q);}
	else if(strpos($q,'current humidity') !== false){$w1 = true; $q = str_replace('current humidity', '', $q);}
	if(strpos($q,'sun set') !== false && strpos($q,'today') !== false){$w1 = true; $q = str_replace('sun set', '', $q);}
	else if(strpos($q,'sunset') !== false && strpos($q,'today') !== false){$w1 = true; $q = str_replace('sun set', '', $q);}
	if(strpos($q,'sun rise') !== false && strpos($q,'today') !== false){$w1 = true; $q = str_replace('sun rise', '', $q);}
	else if(strpos($q,'sunrise') !== false && strpos($q,'today') !== false){$w1 = true; $q = str_replace('sun rise', '', $q);}
	
	if(strpos($q,' of ') !== false){$w3 = true; $q = str_replace(' of ', '', $q);}
	if(strpos($q,' my ') !== false){$w3 = true; $q = str_replace(' my ', '', $q);}
	if(strpos($q,' in ') !== false){$w3 = true; $q = str_replace(' in ', '', $q);}
	if(strpos($q,' at ') !== false){$w3 = true; $q = str_replace(' at ', '', $q);}
	if(strpos($q,'location') !== false){$w4 = true; $q = str_replace('location', '', $q);}
	if(strpos($q,'what is ') !== false){$w5 = true; $q = str_replace('what is ', '', $q);}
	if(strpos($q,'what will ') !== false){$w5 = true; $q = str_replace('what will ', '', $q);}
	if(strpos($q,'what was ') !== false){$w5 = true; $q = str_replace('what was ', '', $q);}
	if(strpos($q,'what are ') !== false){$w5 = true; $q = str_replace('what are ', '', $q);}
	if(strpos($q,'what') !== false){$w5 = true; $q = str_replace('what', '', $q);}
	if(strpos($q,'when') !== false){$w6 = true; $q = str_replace('when', '', $q);}
	
	if($w1){
		if($w2 or $w3 or $w4 or $w5 or $w6){
			if(strlen($q) > 2){
				$weather = true;
			} else {
				$weather = false;
				$q = $bq;
			}
		} else {
			$weather = false;
			$q = $bq;
		}
	} else {
		$weather = false;
		$q = $bq;
	}
	
	if($weather){
		$info = "http://maps.google.com/maps/api/geocode/json?address=".$q."&sensor=false";
		$a = json_decode(file_get_contents($info),true);
		if($a["status"] != "ZERO_RESULTS"){
			$done = true;
			$i = 0;
			while($done){
				if(isset($a["results"][0]["address_components"][$i])){
					if($a["results"][0]["address_components"][$i]["types"][0] == "locality"){
						$loc = $a["results"][0]["address_components"][$i]["long_name"];
					}
					if($a["results"][0]["address_components"][$i]["types"][0] == "country"){
						$con = $a["results"][0]["address_components"][$i]["short_name"];
					}
					if($a["results"][0]["address_components"][$i]["types"][0] == "postal_code"){
						$zip = $a["results"][0]["address_components"][$i]["long_name"];
						$done = false;
					}
					$i++;
				} else {
					$done = false;
				}
			}
			$addr = $a["results"][0]["formatted_address"];
			$lat = $a["results"][0]["geometry"]["location"]["lat"];
			$lon = $a["results"][0]["geometry"]["location"]["lng"];
			if(!isset($loc)){$loc = '';}
			$info = "http://api.openweathermap.org/data/2.5/weather?q=".$loc.",".$con;
			$a = json_decode(file_get_contents($info),true);
			if($a["cod"] != "200"){
				if(isset($zip)){
					$info = "http://api.openweathermap.org/data/2.5/weather?zip=".$zip.",".$con;
					$a = json_decode(file_get_contents($info),true);
					if($a["cod"] != "200"){
						if(isset($lat) && isset($lat)){
							$info = "http://api.openweathermap.org/data/2.5/weather?lat=".$lat."&lon=".$lon;
							$a = json_decode(file_get_contents($info),true);
							if($a["cod"] != "200"){
								echo 'Looking wrong location for weather.';
								$wdone = false;
							}
						}
					}
				} else if(isset($lat) && isset($lat)){
					$info = "http://api.openweathermap.org/data/2.5/weather?lat=".$lat."&lon=".$lon;
					$a = json_decode(file_get_contents($info),true);
					if($a["cod"] != "200"){
						echo 'Looking wrong location for weather.';
						$wdone = false;
					}
				} else {
					$wdone = true;
				}
			} else {
				$wdone = true;
			}
			if($wdone){
				echo "At ".$addr." - ".$a['weather'][0]['description'].", Where Temperature is ".(($a['main']['temp'])/10)." degree with pressure ".$a['main']['pressure']." mb and humidity ".$a['main']['humidity']."%. where sun rise at ".date('h:i A',$a['sys']['sunrise'])." and sun set at ".date('h:i A',$a['sys']['sunset']).".";
			}
			
		} else {
			echo 'Location is looking wrong.';
		}
	} else {

$q = urldecode($_GET['q']);
$file = file_get_contents("http://ajax.googleapis.com/ajax/services/search/web?v=1.0&q=".urlencode($q.' wiki'));
if(isset($file)){
	$array = json_decode($file,true);
	$url = $array["responseData"]["results"][0]["url"];
	$a = $array["responseData"]["results"][0]["content"];
		if($url != ''){
			if(substr(substr(substr($url,0,strrpos($url,"/")),strrpos(substr($url,0,strrpos($url,"/")),"/")),1) == 'wiki'){
				$a = htmlspecialchars_decode(strip_tags($a));
				$i = 0;
				$d[$i] = $a;
				$i = 1;
				while(strrpos($a,"...")){
					$d[$i] = substr($a,0,strrpos($a,"..."));
					$a = $d[$i];
					if(strrpos($d[$i],"...")){
						$d[$i] = substr($d[$i],(strrpos($d[$i],"...")+3));
					}
					$i = $i+1;
				}
				$i = $i-1;
				if($i != 0){
					$f = 0;
					$t = $i;
					$info = "http://en.wikipedia.org/w/api.php?action=query&prop=extracts&exintro&format=json&explaintext&titles=".substr(substr($url,strrpos($url,"/")),1);
					$info = htmlspecialchars_decode(strip_tags(reset(json_decode(file_get_contents($info),true)["query"]["pages"])["extract"]));
					while($i != 0){
						if(strpos($info,substr($d[$i],2,2)) !== false){
							$f++;
						}
						$i = $i-1;
					}
					if($f == $t){
						$i = $t;
						$lf = $d[$i].substr(substr($info,strpos($info,$d[$i])+strlen($d[$i])-2),0,strpos(substr($info,strpos($info,$d[$i])+strlen($d[$i])-2),'. ')).'.';
						$fn = $lf;
						$i = $i-1;
						while($i != 0){
							$a1 = substr($d[$i],0,-2);
							$s1 = strpos($info,$fn)+strlen($fn);
							$s2 = strpos($info,$a1);
							if(($s2-$s1) > 0){
							$a1 = $fn.substr(substr($info,$s1),0,$s2-$s1).$a1;
							$lf = $a1.substr(substr($info,strpos($info,$a1)+strlen($a1)-2),0,strpos(substr($info,strpos($info,$a1)+strlen($a1)-2),'. ')).'. ';
							$fn = $lf;
							} else if(($s2-$s1) < 0){
							$a1 = substr($fn,0,$s2-$s1).$a1;
							$lf = $a1.substr(substr($info,strpos($info,$a1)+strlen($a1)-2),0,strpos(substr($info,strpos($info,$a1)+strlen($a1)-2),'. ')).'. ';
							$fn = $lf;
							} else {
							$a1 = $fn.$a1;
							$lf = $a1.substr(substr($info,strpos($info,$a1)+strlen($a1)-2),0,strpos(substr($info,strpos($info,$a1)+strlen($a1)-2),'. ')).'. ';
							$fn = $lf;
							}
							$i = $i-1;
						}
						echo $fn;
					} else {
						$f = 0;
						$i = $t;
						$info = "http://en.wikipedia.org/w/api.php?action=query&prop=extracts&explaintext&format=json&titles=".substr(substr($url,strrpos($url,"/")),1);
						$info = htmlspecialchars_decode(strip_tags(reset(json_decode(file_get_contents($info),true)["query"]["pages"])["extract"]));
						while($i != 0){
							if(strpos($info,substr($d[$i],2,2)) !== false){
								$f++;
							}
							$i = $i-1;
						}
						if($f == $t){
							$i = $t;
							$lf = $d[$i].substr(substr($info,strpos($info,$d[$i])+strlen($d[$i])-2),0,strpos(substr($info,strpos($info,$d[$i])+strlen($d[$i])-2),'. ')).'.';
							$fn = $lf;
							$i = $i-1;
							while($i != 0){
								$a1 = substr($d[$i],0,-2);
								$s1 = strpos($info,$fn)+strlen($fn);
								$s2 = strpos($info,$a1);
								if(($s2-$s1) > 0){
								$a1 = $fn.substr(substr($info,$s1),0,$s2-$s1).$a1;
								$lf = $a1.substr(substr($info,strpos($info,$a1)+strlen($a1)-2),0,strpos(substr($info,strpos($info,$a1)+strlen($a1)-2),'. ')).'. ';
								$fn = $lf;
								} else if(($s2-$s1) < 0){
								$a1 = substr($fn,0,$s2-$s1).$a1;
								$lf = $a1.substr(substr($info,strpos($info,$a1)+strlen($a1)-2),0,strpos(substr($info,strpos($info,$a1)+strlen($a1)-2),'. ')).'. ';
								$fn = $lf;
								} else {
								$a1 = $fn.$a1;
								$lf = $a1.substr(substr($info,strpos($info,$a1)+strlen($a1)-2),0,strpos(substr($info,strpos($info,$a1)+strlen($a1)-2),'. ')).'. ';
								$fn = $lf;
								}
								$i = $i-1;
							}
							echo $fn;
						} else {
							echo htmlspecialchars_decode(strip_tags(str_replace("..."," and more.",$a)));
						}
					}
				} else {
					echo $d[$i].'.';
				}
			} else {
				echo htmlspecialchars_decode(strip_tags(str_replace("..."," and more.",$a)));
			}
		} else {
			echo 'Unable to get Program.';
		}
} else {
	echo 'Unable to get Program.';
}
	}
} else {
	echo 'I\'m not hearing you.';
}
unlink(error_log);
?>
