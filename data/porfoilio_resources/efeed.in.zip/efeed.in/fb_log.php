<?php
ob_start();
$app_id1 = '285236605006172';
$post_login_url1 = 'http://127.0.0.1/efeed/fb_log.php';
$token_url = 'https://graph.facebook.com/panchaldeep009';
echo curl_get_file_contents($token_url);
function curl_get_file_contents($URL)
    {
        $c = curl_init();
        curl_setopt($c, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($c, CURLOPT_URL, $URL);
        $contents = curl_exec($c);
        curl_close($c);

        if ($contents) return $contents;
            else return FALSE;
    }
function login($app_id, $post_login_url){

    $dialog_url= "http://www.facebook.com/dialog/oauth?"
        . "client_id=" . $app_id
        . "&redirect_uri=" . urlencode($post_login_url)
        . "&scope=public_profile,user_about_me,user_birthday,user_hometown,user_location,email";
    echo("<script>top.location.href='" . $dialog_url .
        "'</script>");
}
function getAccessToken($app_id, $post_login_url, $app_secret, $code){

    $token_url= "https://graph.facebook.com/oauth/"
        . "access_token?"
        . "client_id=" .  $app_id
        . "&redirect_uri=" . urlencode( $post_login_url)
        . "&client_secret=" . $app_secret
        . "&code=" . $code;
    $response = file_get_contents($token_url);
    $params = null;
    parse_str($response, $params);
    return($params['access_token']);

}
if(isset($_GET['code'])){
echo $at = getAccessToken($app_id1, $post_login_url1, '462a61d7c286f774c8268eb33eac62ab', $_GET['code']);
if(isset($at)){
$token_url = "https://graph.facebook.com/me?fields=id,first_name,last_name,email,gender,birthday,bio,hometown,location,education,quotes,cover,work,devices&access_token=".$at;
$response = file_get_contents($token_url);
    $array = null;
    parse_str($response, $array);
$resp = file_get_contents($url);
$array = null;
parse_str($resp, $array);
$array = $response;
$hscl = 'Unfined';
$clg = 'Unfined';
for($i = 0;$i < 5 && $hscl == 'Unfined';$i++){
	if ($array['education'][$i]['type'] == 'High School') {$hscl = $array['education'][$i]['school']['name'];}
}
for($i = 0;i < 5 && $clg == 'Unfined';$i++){
	if ($array['education'][$i]['type'] == 'College') {$clg = $array['education'][$i]['school']['name'];}
}
$detail = 'ID = '.$array['id'].'<br />'.
'First Name = '.$array['first_name'].'<br />'.
'Last Name = '.$array['last_name'].'<br />'.
'Email Address = '.$array['email'].'<br />'.
'Birthday = '.$array['birthday'].'<br />'.
'BIO = '.$array['bio'].'<br />'.
'Birth Place = '.$array['hometown']['name'].'<br />'.
'Living Place = '.$array['location']['name'].'<br />'.
'High School = '.$hscl.'<br />'.
'Collage = '.$clg.'<br />'.
'Quotes = '.$array['quotes'].'<br />' +
'Work = '.$array['work'][0]['position']['name'].' of '.$array['work'][0]['employer']['name'].'<br />'.
'Profile Picture (Main) <br /><img src="https://graph.facebook.com/'.$array['id'].'/picture?height=500&width=500" /><br /><br />'.
'Profile Picture (Thambline) <br /><img src="https://graph.facebook.com/'.$array['id'].'/picture?height=250&width=250" /><br /><br />'.
'Profile Picture (Icon) <br /><img src="https://graph.facebook.com/'.$array['id'].'/picture?height=64&width=64" /><br /><br />'.
'Cover Picture <br /><img src="'.$array['cover']['source'].'" /><br /><br />';
echo $detail;}
}else{login($app_id1, $post_login_url1);}
?>