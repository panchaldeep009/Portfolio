<?php
ob_start();
$hosted = "localhost";
$usered = "root";
$passed = "";
$dbed = "efeedin_area";
?>
                            
                            
                            
                            