<?php
require("common.php");
ob_start();
session_start();
	if(isset($_GET['logout'])){
		unset($_SESSION['user']);
		unset($_SESSION);
		session_destroy();
	}
    if(empty($_SESSION['user']))
    {
        header("Location: login.php");
        die("Redirecting to login.php");
    }

$data = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM users WHERE id = ".$_SESSION['user']['id']));
$page = false;
if($data['gen'] == 'page') { $page = true;}

   if($data['crd'] != '-200%'){
	   if($data['crd']<0){
			if(isset($_GET['page'])){
				header("Location: chp.php?page");
			}
			else{
				header("Location: chp.php");
			}
		}
	} else {
		header("Location: exlog.php");
	}
	require("loc.php");
$num_msg = mysqli_num_rows(mysqli_query($conn, "SELECT * FROM msg WHERE revid = ".$_SESSION['user']['id']." AND state = 1"));
$num_not = mysqli_num_rows(mysqli_query($conn, "SELECT * FROM nots WHERE revid = ".$_SESSION['user']['id']." OR revid = 0 AND state = 1"));
$num_mail = mysqli_num_rows(mysqli_query($conn, "SELECT * FROM mail WHERE revid = ".$_SESSION['user']['id']." AND state = 1"));
$data['nmsg'] = $num_msg;
$data['nnot'] = $num_not;
$data['nmail'] = $num_mail;
?>
<!DOCTYPE html>

<html>


    <head>
        <meta charset="UTF-8">
        <title>
		<?php 
		    if(isset($_GET['user'])){
		    	if($_GET['user'] == ''){$id = $_SESSION['user']['id'];}
		    	else{$id = $_GET['user'];}
		    	echo defindsql($conn,"fname","users","id",$id,0,0,0,0,0,0);
		    	echo"  ";
		    	$tz = setssql($conn,"gen","users","id",$id,0,0,0,0,0,0);
				if($tz != 'page'){
		    	echo defindsql($conn,"lname","users","id",$id,0,0,0,0,0,0);}
		    }else if(isset($_GET['about'])){
		    	if($_GET['about'] == ''){$id = $_SESSION['user']['id'];}
		    	else{$id = $_GET['about'];}
				echo 'About ';
		    	echo defindsql($conn,"fname","users","id",$id,0,0,0,0,0,0);
		    	echo"  ";
		    	echo defindsql($conn,"lname","users","id",$id,0,0,0,0,0,0);
		    }else if(isset($_GET['notifications'])){
				echo 'Notifications';
		    }else if(isset($_GET['users'])){
				echo 'Users';
		    }else if(isset($_GET['post'])){
		    	if($_GET['post'] == ''){echo 'No Post Found';}
		    	else{
				$pnum = mysqli_num_rows(mysqli_query($conn, "select * from post where id = ".$_GET['post']));
				if($pnum != 0){
					$pid = setssql($conn,'pid','post','id',$_GET['post'],'0','0','0','0','0','0');
					$name = setssql($conn,'fname','users','id',$pid,'0','0','0','0','0','0')." ".setssql($conn,'lname','users','id',$pid,'0','0','0','0','0','0');
					echo $name."'s Post";
				} else {echo 'No Post Found';}
				}
		    }
		    else if(isset($_GET['me'])){
		    	$id = $_SESSION['user']['id'];
		    	echo defindsql($conn,"fname","users","id",$id,0,0,0,0,0,0);
		    	echo"  ";
		    	$tz = setssql($conn,"gen","users","id",$id,0,0,0,0,0,0);
				if($tz != 'page'){
		    	echo defindsql($conn,"lname","users","id",$id,0,0,0,0,0,0);}
		    }
		    else if(isset($_GET['feed'])){echo 'Feeds';}
		    else if(isset($_GET['bookmarks'])){echo 'Saved Post';}
		    else if(isset($_GET['event'])){echo 'Events';}
		    else if(isset($_GET['setting'])){echo 'Account Settings';}
		    else{echo 'Feeds';}
		?> | eFeed</title><meta name="title" content="Welcome to eFeed">
		<meta name="description" content="eFeed is online social networking web application made up for collogues or classmates and social friends which can share easily their works, events, activity, studies, etc to each other and their administrators and also can communicate with each other.">
		<meta name="author" content="eFeed">
		<meta name="keywords" content="efeed,efeed.in,eFeed,efeeds,eFeeds,eFeed.in,social,site,login,signup,signin,create,new,account,panchal,deep,akash,panchaldeep009,panchaldeep009@gmail.com,feed,of,eduction,connection,for,you">
		<meta property="og:url" content="http://www.efeed.in/">
		<meta property="og:site_name" content="eFeed">
		<meta property="og:image" content="http://www.efeed.in/images/logo-large.png">
        <meta content='width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no' name='viewport'>
<meta name="fl-verify" content="5638e75e813f0a23a0708d176f0dd473">
        <link href="met/css/bootstrap3.css" rel="stylesheet" type="text/css" />
        <link href="met/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
        <link href="met/css/ionicons.min.css" rel="stylesheet" type="text/css" />
        <link href="met/css/morris/morris.css" rel="stylesheet" type="text/css" />
        <link href="met/css/jvectormap/jquery-jvectormap-1.2.2.css" rel="stylesheet" type="text/css" />
        <link href="met/css/datepicker/datepicker3.css" rel="stylesheet" type="text/css" />
        <link href="met/css/daterangepicker/daterangepicker-bs3.css" rel="stylesheet" type="text/css" />
        <link href="met/css/bootstrap-wysihtml5/bootstrap3-wysihtml5.min.css" rel="stylesheet" type="text/css" />
        <link href="met/css/page_style6.css" rel="stylesheet" type="text/css" />
		<link rel="stylesheet" type="text/css" href="css/ns.css" />
		<link rel="shortcut icon" href="images/favicon.png"> 
		<script src="js/action.js" type="text/javascript"></script>
		<script type='text/javascript' src='js/jquery-1.9.1.js'></script>
		<script type="text/javascript" src="js/jquery.min.ajax.1.8.js"></script>
		<script type="text/javascript" src="js/gen.js"></script>

        <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
        <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
        <!--[if lt IE 9]>
          <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
          <script src="https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script>
        <![endif]-->
    </head>
    <body id="body" class="skin-blue fixed" >
        <header class="header">
            <a href="?feed" align="right" class="logo">
                <img src="images/logo.png" alt="LOGO"/>
            </a>
            <nav class="navbar navbar-static-top" role="navigation">
                <a href="#" class="navbar-btn sidebar-toggle" data-toggle="offcanvas" role="button">
					<div class="menbar">
					<span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
					</div>
					<div class="lomenbar">
                    <span class="sr-only">Toggle navigation</span>
                    <img  src="images/logo2.png" alt="LOGO"/>
					</div>
                </a>
                   
                <div class="navbar-right">
                    <ul class="nav navbar-nav" >
						<li class="dropdown messages-menu" onclick="msg_c();">
							<a href="#" class="dropdown-toggle" data-toggle="dropdown" id="msgn">
								<i class="fa fa-comments-o"></i>
							</a>
							<ul class="dropdown-menu" id='msgc'>
							    <li class="header"><i class="fa fa-clock-o"></i> Loading..</li>
							</ul>
						</li>

						<li class="dropdown notifications-menu" onclick="not_c();">
							<a href="#" class="dropdown-toggle" data-toggle="dropdown" id="notn">
								<i class="fa fa-globe"></i>
							</a>
							<ul class="dropdown-menu" id='notc'>
							    <li class="header"><i class="fa fa-clock-o"></i> Loading..</li>
							</ul>
						</li>
						<li class="dropdown tasks-menu" onclick="mail_c();">
							<a href="#" class="dropdown-toggle" data-toggle="dropdown" id="mailn">
								<i class="fa fa-link"></i>
							</a>
							<ul class="dropdown-menu" id='mailc'>
							    <li class="header"><i class="fa fa-clock-o"></i> Loading..</li>
							</ul>
						</li>
						<li class="dropdown user user-menu">
							<a href="#" class="dropdown-toggle" data-toggle="dropdown">
								<i class="glyphicon glyphicon-user"></i>
							</a>
							<ul class="dropdown-menu">
								
								<li class="user-header">
									<img src="<?php echo ($data['propt']); ?>" class="img-circle" alt="User Image" />
										<p>
											<?php echo $data['fname'];
												if(!$page){ echo" ".$data['lname'];}?>
											<small><?php echo $data['uname'];?></small>
										</p>
								</li>
								<li class="user-footer">
									<div class="pull-left">
										<a href="?me" class="btn btn-default btn-flat">Profile</a>
									</div>
									<div class="pull-right" onclick="log_out();">
										<a class="btn btn-default btn-flat"><i class="fa fa-sign-out"></i> Logout</a>
									</div>
								</li>
							</ul>
						</li>
                    </ul>
                </div>
            </nav>
        </header>
        <div class="wrapper row-offcanvas row-offcanvas-left">
            <!-- Left side column. contains the logo and sidebar -->
            <aside class="left-side sidebar-offcanvas">
                <!-- sidebar: style can be found in sidebar.less -->
                <section class="sidebar">
                    <!-- Sidebar user panel -->
					
                    <div class="user-panel">
                        <div class="pull-left image">
                            <a href="?me"><img src="<?php echo ($data['propic']); ?>" width="45px" class="img-circle" alt="User Image" /></a>
                        </div>
                        <div class="pull-left info">
                            <b><h5><a href="?me"><?php echo $data['fname'];
												if(!$page){ echo " ".$data['lname']; } ?></a></h5></b>
                        </div>
                    </div>
					
                    <!-- search form -->
                    <!-- /.search form -->
                    <!-- sidebar menu: : style can be found in sidebar.less -->
                    <ul class="sidebar-menu">
                        <li <?php if(isset($_GET['feed'])){ echo 'class="active"';}?> onclick="location.href = '?feed'">
                            <a href="?feed">
                                <i class="fa fa-dashboard"></i> <span>Feeds</span>
                            </a>
                        </li>
						<li onclick="lod_msgm()" data-toggle="modal" data-target="#blank_m">
                            <a >
                                <i class="fa fa-comments-o"></i> <span>Messages</span>
                            </a>
                        </li>
						<li <?php if(isset($_GET['notifications'])){ echo 'class="active"';}?> onclick="location.href = '?notifications'">
                            <a href="?notifications">
                                <i class="fa fa-globe"></i> <span>Notifications</span>
                            </a>
                        </li>
						<li class="treeview">
                            <a >
                                <i class="fa fa-book"></i> <span>Eduction Library</span>
                                <i class="fa fa-angle-left pull-right"></i>
                            </a>
                            <ul class="treeview-menu">
                                <li><a ><i class="fa fa-angle-double-right"></i> Under Construction </a></li>
                            </ul>
                        </li>
						<li class="treeview">
                            <a >
                                <i class="fa fa-calendar"></i> <span>Event</span>
                            </a>
							<ul class="treeview-menu">
                                <li><a ><i class="fa fa-angle-double-right"></i> Under Construction </a></li>
                            </ul>
                        </li>
						<li <?php if(isset($_GET['bookmarks'])){ echo 'class="active"';}?> onclick="location.href = '?bookmarks'">
                            <a href="?bookmarks">
                                <i class="fa fa-bookmark"></i> <span>Saved</span>
                            </a>
                        </li>
						<li <?php if(isset($_GET['setting'])){ echo 'class="active"';}?> onclick="location.href = '?setting'">
                            <a href="">
                                <i class="fa fa-cog"></i> <span>Account Settings</span>
                            </a>
                        </li>
						<li <?php if(isset($_GET['logout'])){ echo 'class="active"';}?> onclick="log_out();">
                            <a>
                                <i class="fa fa-sign-out"></i> <span>Logout</span>
                            </a>
                        </li>
                    </ul>
                </section>
                <!-- /.sidebar -->
            </aside>

			
			
			
            <!-- Right side column. Contains the navbar and content of the page -->
			
			
			
			
			
            <aside class="right-side">
                <!-- Content Header (Page header) -->
				
                <section class="content-header">
                    <h1 class="text-primary">
					<?php 
					    if(isset($_GET['user'])){
					    	if($_GET['user'] == ''){$id = $_SESSION['user']['id'];}
					    	else{$id = $_GET['user'];}
					    	echo defindsql($conn,"fname","users","id",$id,0,0,0,0,0,0);
					    	echo"  ";
					    	$tz = setssql($conn,"gen","users","id",$id,0,0,0,0,0,0);
							if($tz != 'page'){
							echo defindsql($conn,"lname","users","id",$id,0,0,0,0,0,0);}
					    	echo" <small>";
					    	echo defindsql($conn,"uname","users","id",$id,0,0,0,0,0,0);
					    	echo"</small>";
					    }else if(isset($_GET['about'])){
					    	if($_GET['about'] == ''){$id = $_SESSION['user']['id'];}
					    	else{$id = $_GET['about'];}
					    	echo defindsql($conn,"fname","users","id",$id,0,0,0,0,0,0);
					    	echo"  ";
					    	echo defindsql($conn,"lname","users","id",$id,0,0,0,0,0,0);
					    	echo" <small>";
					    	echo defindsql($conn,"uname","users","id",$id,0,0,0,0,0,0);
					    	echo"</small>";
					    }
						else if(isset($_GET['notifications'])){
							echo 'Notifications';
						}
						else if(isset($_GET['users'])){
							echo 'eFeed\'s Users';
						}
					    else if(isset($_GET['me'])){
					    	$id = $_SESSION['user']['id'];
					    	echo defindsql($conn,"fname","users","id",$id,0,0,0,0,0,0);
					    	echo"  ";
					    	$tz = setssql($conn,"gen","users","id",$id,0,0,0,0,0,0);
							if($tz != 'page'){
							echo defindsql($conn,"lname","users","id",$id,0,0,0,0,0,0);}
					    	echo" <small>";
					    	echo defindsql($conn,"uname","users","id",$id,0,0,0,0,0,0);
					    	echo"</small>";
					    }
						else if(isset($_GET['post'])){
							if($_GET['post'] == ''){echo 'Unknown Post';}
							else{
							$pnum = mysqli_num_rows(mysqli_query($conn, "select * from post where id = ".$_GET['post']));
							if($pnum != 0){
								$pid = setssql($conn,'pid','post','id',$_GET['post'],'0','0','0','0','0','0');
								$name = setssql($conn,'fname','users','id',$pid,'0','0','0','0','0','0');
								echo $name."'s Post";
							} else {echo 'Unknown Post';}
							}
						}
					    else if(isset($_GET['feed'])){echo 'Feeds <small>Today</small>';}
					    else if(isset($_GET['bookmarks'])){echo 'Saved <small> Feeds </small>';}
					    else if(isset($_GET['event'])){echo 'Events';}
					    else if(isset($_GET['setting'])){echo 'Account Settings';}
					    else{echo 'Feeds <small>Today</small>';}
					?>
                    </h1>
                </section>

                <!-- Main content -->
		
                <section class="content">
                    <div class="row">

			<?php 
		if(isset($_GET['user'])){include('src/pro.php');}
		else if(isset($_GET['about'])){include('src/about.php');}
		else if(isset($_GET['me'])){include('src/pro.php');}
		else if(isset($_GET['feed'])){include('src/feed.php');}
		else if(isset($_GET['bookmarks'])){include('src/sfeed.php');}
		else if(isset($_GET['post'])){include('src/post.php');}
		else if(isset($_GET['notifications'])){include('src/not.php');}
		else if(isset($_GET['users'])){include('src/user.php');}
		else if(isset($_GET['event'])){include('src/event.php');}
		else if(isset($_GET['setting'])){include('src/setting.php');}
		else{include('src/feed.php');}
		?>
						
						<section class="col-lg-3"> 
							<div class="pull-right">
								<div class="nmslider">
									<div class="right-cont box box-solid">
										<div class="box-footer">
											<div class="box box-primary" id="onmlc">
												<div class="box-header">
													<h3 class="box-title"><i class="fa fa-clock-o"></i> Loading..</h3>
												</div>
											</div>
										</div>
									</div>	
								</div>
							</div>
						</section>
			
					</div>
				</section>
				
            </aside><!-- /.right-side -->
        </div><!-- ./wrapper -->
		<footer class="footer">
			<div align="center" style="border-top: 2px solid #f1f1f1">
			<a href="index.php"> Home </a> - <a href="eFeed/index.html"> About </a> - <a href="legal/terms/index.html"> Terms </a> - <a href="about/privacy/index.html"> Privacy </a> - <a href="help/index.html"> Help </a> - <a href="about/privacy/cookies/index.html"> Cookies </a><br/>
			 eFeed © 2015 (English (US))
			</div>
        </footer>

		
<!-- ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ -->

													<!-- Show clear -->

<!-- ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ -->

<!-- jQuery 2.0.2 -->
        <script src="js/jquery.min.2.0.2.js"></script>
	<script type='text/javascript' src='met/js/jquery-1.10.1.js'></script>
        <!-- jQuery UI 1.10.3 -->
        <script src="met/js/jquery-ui-1.10.3.min.js" type="text/javascript"></script>
        <!-- Bootstrap -->
        <script src="met/js/bootstrap.min.js" type="text/javascript"></script>
        <!-- Morris.js charts -->
        <script src="js/raphael-min.js"></script>
        <script src="met/js/plugins/morris/morris.min.js" type="text/javascript"></script><!-- AdminLTE App -->
        <script src="met/js/AdminLTE/app.js" type="text/javascript"></script>

        <!-- AdminLTE dashboard demo (This is only for demo purposes) -->
        <script src="met/js/AdminLTE/dashboard.js" type="text/javascript"></script>

        <!-- AdminLTE for demo purposes -->
        <script src="met/js/AdminLTE/demo.js" type="text/javascript"></script>
        <script src="met/js/ext.js" type="text/javascript"></script>
        <!-- Sparkline -->
        <script src="met/js/plugins/sparkline/jquery.sparkline.min.js" type="text/javascript"></script>
        <!-- daterangepicker -->
        <script src="met/js/plugins/daterangepicker/daterangepicker.js" type="text/javascript"></script>
        <!-- datepicker -->
        <script src="met/js/plugins/datepicker/bootstrap-datepicker.js" type="text/javascript"></script>
        <!-- Bootstrap WYSIHTML5 -->
        <script src="met/js/plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.all.min.js" type="text/javascript"></script>

        
	<script src="js/notificationFx.js"></script>
        
    </body>
</html>
<?php

?>