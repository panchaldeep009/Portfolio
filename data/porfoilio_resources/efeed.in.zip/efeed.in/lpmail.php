<?php
if(isset($_GET['str']) && isset($_GET['str2'])){

$key = '8562';
$iv = '85628562';
$cipher = mcrypt_module_open(MCRYPT_BLOWFISH,'','cbc','');
mcrypt_generic_init($cipher, $key, $iv);
$pass = mdecrypt_generic($cipher,base64_decode($_GET['str']));
mcrypt_generic_deinit($cipher);

$cipher = mcrypt_module_open(MCRYPT_BLOWFISH,'','cbc','');
mcrypt_generic_init($cipher, $key, $iv);
$email = mdecrypt_generic($cipher,base64_decode($_GET['str2']));
mcrypt_generic_deinit($cipher);


$semail = 'eFeed_Info@efeed.in';

echo $pass.'<br/>';
echo $semail.'<br/>';
echo $email;

$to = $email;
$subject = "Account Recovered on eFeed";

$message = '
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <style type="text/css">
      body {margin: 10px 0; padding: 0 10px; background: #fc3230; font-size: 13px;}
      table {border-collapse: collapse;}
      td {font-family: arial, sans-serif; color: #333333;}
	.srch{
		background-image: url(\'http://www.efeed.in/images/SKRECH.jpg\');background-repeat: no-repeat;background-position: center;
	}
.btn {
padding: 6px 12px;
margin-bottom: 0;
font-size: 14px;
font-weight: 500;
-webkit-border-radius: 3px;
-moz-border-radius: 3px;
border-radius: 3px;
border: 1px solid transparent;
-webkit-box-shadow: inset 0px -2px 0px 0px rgba(0, 0, 0, 0.09);
-moz-box-shadow: inset 0px -2px 0px 0px rgba(0, 0, 0, 0.09);
box-shadow: inset 0px -1px 0px 0px rgba(0, 0, 0, 0.09);
}
.btn-primary {
color: #ffffff;
background-color: #d93333;
border-color: #c42a2a;
}
      @media only screen and (max-width: 641px) {
        body,table,td,p,a,li,blockquote {
          -webkit-text-size-adjust:none !important;
        }
        table {width: 100% !important;}

        .responsive-image img {
          height: auto !important;
          max-width: 100% !important;
          width: 100% !important;
        }
      }
    </style>
  </head>
  <body>
    <table border="0" cellpadding="0" cellspacing="0" width="100%">
      <tr>
        <td>
          <table border="0" cellpadding="0" cellspacing="0" align="center" width="640" bgcolor="#FFFFFF">
            <tr>
              <td bgcolor="#ddd" style="font-size: 0; line-height: 0; padding: 0 10px;" height="100" align="right">
                <img src="http://www.efeed.in/images/logo.png" width="80" alt="" />
              </td>
            </tr>
            <tr><td style="font-size: 0; line-height: 0;" height="30">&nbsp;</td></tr>
            <tr>
              <td style="padding: 10px 10px 20px 10px;">
                <div style="font-size: 20px;">eFeed</div>
                <br />
                <div>
                  Your eFeed account \''.$email.'\' has been recovered and your password is changed.
				  <br/>
                </div>
              </td>
            </tr>
			<tr><td align="center"><b>Your new Password</b></td></tr>
			<tr><td width="250px" height="80px" class="srch" align="center" valign="middel"><strong>'.$pass.'</strong></td></tr>
                        <tr><td align="center"><br/><b style="color: red;">Change this password after the login. So no one can use this temporary password again.</b></td></tr>

			<tr><td style="font-size: 0; line-height: 0;" height="1" bgcolor="#F9F9F9">&nbsp;</td></tr>
            <tr><td style="font-size: 0; line-height: 0;" height="30">&nbsp;</td></tr>
            <tr>
              <td align="center">
               <a href="http://www.efeed.in/login.php"><button type="submit" class="btn btn-primary"> Login Now </button></a>
              </td>
            </tr>
            <tr><td style="font-size: 0; line-height: 0;" height="20">&nbsp;</td></tr>
            <tr>
              <td bgcolor="#fc3230">
                <table border="0" cellpadding="0" cellspacing="0" width="100%">
                  <tr><td style="font-size: 0; line-height: 0;" height="15">&nbsp;</td></tr>
                  <tr>
                    <td style="padding: 0 10px; color: #FFFFFF;">
                      <b>Copyright by eFeed</b>
                    </td>
                  </tr>
                  <tr><td style="font-size: 0; line-height: 0;" height="15">&nbsp;</td></tr>
                </table>
              </td>
            </tr>
          </table>
        </td>
      </tr>
    </table>
  </body>
</html>
';

// Always set content-type when sending HTML email
$headers = "MIME-Version: 1.0" . "\r\n";
$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";

// More headers
$headers .= 'From: <'.$semail.'>' . "\r\n";
$headers .= 'Cc: '.$semail.'' . "\r\n";

mail($to,$subject,$message,$headers);}
?>	