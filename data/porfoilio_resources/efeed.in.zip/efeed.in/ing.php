<?php
if($_POST)
{
$hosted = "localhost";
$usered = "efeedin_deep";
$passed = "deep#8562";
$dbed = "efeedin_area";
$conn = new mysqli($hosted, $usered, $passed, $dbed);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
$q=$_POST['searchword'];
$sql = mysqli_query($conn, "SELECT * FROM `users` WHERE (`fname` LIKE '%".$q."%' OR `lname` LIKE '%".$q."%') OR (CONCAT(fname,' ',lname) like '%".$q."%') OR (CONCAT(lname,' ',fname) like '%".$q."%') OR `uname` LIKE '%".$q."%' OR `email` LIKE '%".$q."%' order by id LIMIT 5");
while($row=mysqli_fetch_array($sql))
{
$final_fname=$row['fname'];
$final_lname=$row['lname'];
$img=$row['prop'];
$country=$row['uname'];
?>
<div class="display_box">
<img src="<?php echo $img; ?>"/>
<?php echo $final_fname; ?>&nbsp;
<?php echo $final_lname; ?><br/>
<?php echo $country; ?>
</div>
<?php
}
die();
}
?>
<script type="text/javascript" src="http://code.jquery.com/jquery-1.11.2.min.js"></script>
<script>
$(document).ready(function(){
$(".search").keyup(function()
{
var searchbox = $(this).val();
var dataString = 'searchword='+ searchbox;
if(searchbox=='')
{}
else
{
$.ajax({
type: "POST",
url: "search.php",
data: dataString,
cache: false,
success: function(html)
{
$("#display").html(html).show();
}
});
}return false; 
});
});
</script>
</div>
<style>
*{margin:0px}
#searchbox
{
width:250px;
border:solid 1px #000;
padding:3px;
}
#display
{
width:250px;
display:none;
border-left:solid 1px #dedede;
border-right:solid 1px #dedede;
border-bottom:solid 1px #dedede;
overflow:hidden;
}
.display_box
{
padding:4px;
border-top:solid 1px #dedede;
font-size:12px;
height:35px;
}
.display_box:hover
{
background:#ee6c6a;
color:#FFFFFF;
}
</style>
<input type="text" class="search" id="searchbox" />
<div id="display"></div>