<?php

    require("common.php");
    ob_start();
session_start();
    if(empty($_SESSION['user']))
    {
        header("Location: login.php");
        die("Redirecting to login.php");
    }
	if(!empty($_SESSION['auser']))
    {
        header("Location: login.php");
        die("Redirecting to login.php");
    }

$data = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM users WHERE id = ".$_SESSION['user']['id']));
   
   if($data['crd']<0){
		header("Location: chp.php");
	}
	require("loc.php");
$num_msg = mysqli_num_rows(mysqli_query($conn, "SELECT * FROM msg WHERE revid = ".$_SESSION['user']['id']." AND state = 1"));
$num_not = mysqli_num_rows(mysqli_query($conn, "SELECT * FROM nots WHERE revid = ".$_SESSION['user']['id']." OR revid = 0 AND state = 1"));
$num_mail = mysqli_num_rows(mysqli_query($conn, "SELECT * FROM mail WHERE revid = ".$_SESSION['user']['id']." AND state = 1"));
$data['nmsg'] = $num_msg;
$data['nnot'] = $num_not;
$data['nmail'] = $num_mail;
?>
<!DOCTYPE html>

<html>


    <head>
        <meta charset="UTF-8">
        <title>Feeds | eFeed</title>
        <meta content='width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no' name='viewport'>
        <link href="met/css/bootstrap.css" rel="stylesheet" type="text/css" />
        <link href="met/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
        <link href="met/css/ionicons.min.css" rel="stylesheet" type="text/css" />
        <link href="met/css/morris/morris.css" rel="stylesheet" type="text/css" />
        <link href="met/css/jvectormap/jquery-jvectormap-1.2.2.css" rel="stylesheet" type="text/css" />
        <link href="met/css/datepicker/datepicker3.css" rel="stylesheet" type="text/css" />
        <link href="met/css/daterangepicker/daterangepicker-bs3.css" rel="stylesheet" type="text/css" />
        <link href="met/css/bootstrap-wysihtml5/bootstrap3-wysihtml5.min.css" rel="stylesheet" type="text/css" />
        <link href="met/css/AdminLTE.css" rel="stylesheet" type="text/css" />
		<link rel="shortcut icon" href="images/favicon.png"> 
		<script src="js_page/php.js" type="text/javascript"></script>
		<script type='text/javascript' src='//code.jquery.com/jquery-1.9.1.js'></script>

        <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
        <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
        <!--[if lt IE 9]>
          <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
          <script src="https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script>
        <![endif]-->
    </head>
	
	
    <body class="skin-blue fixed">
        <header class="header">
            <a href="index.php" align="right" class="logo">
                <img src="images/logo.png" alt="LOGO"/>
            </a>
            <nav class="navbar navbar-static-top" role="navigation">
                <a href="#" class="navbar-btn sidebar-toggle" data-toggle="offcanvas" role="button">
					<div class="menbar">
					<span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
					</div>
					<div class="lomenbar">
                    <span class="sr-only">Toggle navigation</span>
                    <img  src="images/logo2.png" alt="LOGO"/>
					</div>
                </a>
                   
                <div class="navbar-right">
                    <ul class="nav navbar-nav" >
						<li class="dropdown messages-menu">
							<a href="#" class="dropdown-toggle" data-toggle="dropdown" id="msgn">
								<i class="fa fa-comments-o"></i>
								<?php if($data['nmsg'] !=	0){
									echo "<span class='label label-success'>";echo ($data['nmsg']);echo "</span>";
								}?>
							</a>
							<ul class="dropdown-menu" id='msgc'>
							    <li class="header"><i class="fa fa-clock-o"></i> Loading..</li>
							</ul>
						</li>

						<li class="dropdown notifications-menu">
							<a href="#" class="dropdown-toggle" data-toggle="dropdown" id="notn">
								<i class="fa fa-globe"></i>
									<?php
									if($data['nnot'] !=	0){echo "<span class='label label-warning'>";echo ($data['nnot']);echo "</span>";}?>
							</a>
							<ul class="dropdown-menu" id='notc'>
							    <li class="header"><i class="fa fa-clock-o"></i> Loading..</li>
							</ul>
						</li>
						<li class="dropdown tasks-menu">
							<a href="#" class="dropdown-toggle" data-toggle="dropdown" id="mailn">
								<i class="fa  fa-envelope-o"></i>
								<?php if($data['nmail'] !=	0){
									echo "<span class='label label-danger'>";echo ($data['nmail']);echo "</span>";
								} ?>
							</a>
							<ul class="dropdown-menu" id='mailc'>
							    <li class="header"><i class="fa fa-clock-o"></i> Loading..</li>
							</ul>
						</li>
						<li class="dropdown user user-menu">
							<a href="#" class="dropdown-toggle" data-toggle="dropdown">
								<i class="glyphicon glyphicon-user"></i>
									<span><?php echo htmlentities($data['uname'], ENT_QUOTES, 'UTF-8'); ?> <i class="caret"></i></span>
							</a>
							<ul class="dropdown-menu">
								<li class="user-header">
									<img src="<?php echo ($data['propt']); ?>" class="img-circle" alt="User Image" />
										<p>
											<?php echo $data['fname']." ".$data['lname'];?> - <?php echo $data['enroll'];?>
											<small><?php echo $data['email'];?></small>
										</p>
								</li>
								<li class="user-footer">
									<div class="pull-left">
										<a href="#" class="btn btn-default btn-flat">Profile</a>
									</div>
									<div class="pull-right">
										<a href="logout.php" class="btn btn-default btn-flat"><i class="fa fa-sign-out"></i> Logout</a>
									</div>
								</li>
							</ul>
						</li>
                    </ul>
                </div>
            </nav>
        </header>
        <div class="wrapper row-offcanvas row-offcanvas-left">
            <!-- Left side column. contains the logo and sidebar -->
            <aside class="left-side sidebar-offcanvas">
                <!-- sidebar: style can be found in sidebar.less -->
                <section class="sidebar">
                    <!-- Sidebar user panel -->
                    <div class="user-panel">
                        <div class="pull-left image">
                            <img src="<?php echo ($data['propic']); ?>" class="img-circle" alt="User Image" />
                        </div>
                        <div class="pull-left info">
                            <p><?php echo $data['fname']." ".$data['lname'];?></p>
                            <a href="#"><i class="fa fa-circle text-success"></i> <?php echo $data['enroll'];?></a>
                        </div>
                    </div>
                    <!-- search form -->
                    <form action="#" method="get" class="sidebar-form">
                        <div class="input-group">
                            <input type="text" name="q" class="form-control" placeholder="Search..."/>
                            <span class="input-group-btn">
                                <button type='submit' name='seach' id='search-btn' class="btn btn-flat"><i class="fa fa-search"></i></button>
                            </span>
                        </div>
                    </form>
                    <!-- /.search form -->
                    <!-- sidebar menu: : style can be found in sidebar.less -->
                    <ul class="sidebar-menu">
                        <li class="active">
                            <a href="index.php">
                                <i class="fa fa-dashboard"></i> <span>Feeds</span>
                            </a>
                        </li>
						<li>
                            <a href="msg.html">
                                <i class="fa fa-comments-o"></i> <span>Messages</span>
                            </a>
                        </li>
						<li>
                            <a href="noti.html">
                                <i class="fa fa-globe"></i> <span>Notifications</span>
                            </a>
                        </li>
						<li>
                            <a href="mailbox.html">
                                <i class="fa fa-envelope"></i> <span>Mailbox</span>
                            </a>
                        </li>
						<li class="treeview">
                            <a >
                                <i class="fa fa-book"></i> <span>Library</span>
                                <i class="fa fa-angle-left pull-right"></i>
                            </a>
                            <ul class="treeview-menu">
                                <li><a href="lib/ass.html"><i class="fa fa-angle-double-right"></i> Assignment </a></li>
                                <li><a href="lib/qb.html"><i class="fa fa-angle-double-right"></i> Question Bank </a></li>
                                <li><a href="lib/r.html"><i class="fa fa-angle-double-right"></i> Results </a></li>
                            </ul>
                        </li>
						<li>
                            <a href="event.html">
                                <i class="fa fa-calendar"></i> <span>Event</span>
                            </a>
                        </li>
						<li>
                            <a href="user.html">
                                <i class="fa fa-users"></i> <span>Users</span>
                            </a>
                        </li>
						<li>
                            <a href="set.html">
                                <i class="fa fa-cog"></i> <span>Account Settings</span>
                            </a>
                        </li>
						<li>
                            <a href="bookm.html">
                                <i class="fa fa-bookmark"></i> <span>Bookmarks</span>
                            </a>
                        </li>
						<li>
                            <a href="logout.html">
                                <i class="fa fa-sign-out"></i> <span>Logout</span>
                            </a>
                        </li>
                    </ul>
                </section>
                <!-- /.sidebar -->
            </aside>

			
			
			
            <!-- Right side column. Contains the navbar and content of the page -->
			
			
			
			
			
            <aside class="right-side">
                <!-- Content Header (Page header) -->
				
                <section class="content-header">
                    <h1>
                        Feeds
                        <small>New Today</small>
                    </h1>
                </section>

                <!-- Main content -->
				
                <section class="content">
                    <div class="row">

						
						<!-- Left -->
						<!-- side -->
						
							<div class="alt">
								<div class="box box-solid box-body">
							
									<!-- alert area -->
											
									<div class="alert alert-danger alert-dismissable">
										<i class="fa fa-ban"></i>
										<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
										<b>Alert!</b> Danger alert preview. This alert is dismissable. A wonderful serenity has taken possession of my entire soul, like these sweet mornings of spring which I enjoy with my whole heart.
									</div>
									<div class="alert alert-info alert-dismissable">
										<i class="fa fa-info"></i>
										<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
										<b>Alert!</b> Info alert preview. This alert is dismissable.
									</div>
									<div class="alert alert-warning alert-dismissable">
										<i class="fa fa-warning"></i>
										<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
										<b>Alert!</b> Warning alert preview. This alert is dismissable.
									</div>
									<div class="alert alert-success alert-dismissable">
										<i class="fa fa-check"></i>
										<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
										<b>Alert!</b> Success alert preview. This alert is dismissable.
									</div>			
								</div>
							</div>
						
                        <section class="col-lg-9">
						
							<!-- Notice area -->
							
						
							<div class="box box-solid">
                                <div class="box-header">
                                    <h3 class="box-title">Notice of the Day</h3>
                                </div>
                                <div class="box-body">
                                    <div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
                                        <div class="carousel-inner">
										
											<!-- Row of Notice -->
										
                                            <div class="item active">
                                                <img src="met/css/not.jpg" alt="Second slide">
                                                <div class="carousel-caption">
													<div class="cap-had">40</div>
													<div class="cap-dec">70</div>
                                                </div>
                                            </div>
											
											<div class="item">
                                                <img src="met/css/not.jpg" alt="Second slide">
                                                <div class="carousel-caption">
													<div class="cap-had">40</div>
													<div class="cap-dec">70</div>
                                                </div>
                                            </div>
											
										
                                        </div>
                                        <a class="left carousel-control" href="#carousel-example-generic" data-slide="prev">
                                            <span class="glyphicon glyphicon-chevron-left"></span>
                                        </a>
                                        <a class="right carousel-control" href="#carousel-example-generic" data-slide="next">
                                            <span class="glyphicon glyphicon-chevron-right"></span>
                                        </a>
                                    </div>
                                </div>
                            </div>
							
							
							<!-- Post area -->
							
							
							<div class="nav-tabs-custom">
                                <ul class="nav nav-tabs pull-right">
                                    <li class="active"><a href="#tab_1-1" data-toggle="tab">Status</a></li>
                                    <li><a href="#tab_2-2" data-toggle="tab">Picture</a></li>
                                    <li class="pull-left header"><i class="fa fa-edit"></i> Post</li>
                                </ul>
                                <div class="tab-content">
									
                                    <div class="tab-pane <?php if(isset($_GET['pper'])){ echo '';}else{ echo 'active';}?>" id="tab_1-1">
									<form enctype='multipart/form-data' name='frmupload' action='posts.php' method='POST'>
										<div class="box box-solid">
											<div class="box-body">
												<div class="form-group">
													<label>Write Post</label><br />
													<strong class="text-red"><?php if(isset($_GET['pser'])){ echo $_GET['pser'];}?></strong>
													<textarea class="form-control" rows="3" name="text1" placeholder="Enter your text here.."></textarea>
												</div>
											</div>
											<div class="box-footer">
												<td><button class="btn btn-primary" type="submit">Post</button></td>
											</div>
										</div>
										</form>
                                    </div><!-- /.tab-pane -->
									<div class="tab-pane <?php if(isset($_GET['pper'])){ echo 'active';}else{ echo '';}?>" id="tab_2-2">
									<form enctype='multipart/form-data' name='frmupload' action='postp.php' method='POST'>
										<div class="box box-solid">
											<div class="box-body">
												<div class="form-group">
													<label>Post Picture</label><br />
													<strong class="text-red"><?php if(isset($_GET['pper'])){ echo $_GET['pper'];}?></strong>
													<textarea class="form-control" name="text2" rows="3" placeholder="Enter your text here.."></textarea>
													<div class="row">
														<div class="col-lg-3 col-xs-8 col-md-3">
															<div class="ppupload btn btn-flat" align="center"> 
															<span>
															<div>
															<img id="pp1" style="border: 3px solid #ef4135;border-radius: 5%;" align="center" src="" width="auto" height="100px" alt="Choose Picture" />
															</div>
															<div class="overlay">
															<div style="position: absolute; top: 45%;right: 40%;left: 40%;">
															<div  id="ic1" style="">
															<i class="fa fa-plus"></i></div>
															</div>
															</div>
															</span> 
															<input id="uploadpp1" type="file" name="img1" class="upload" accept="image/*"/> 
															</div>
														</div>
														<div class="col-lg-3 col-xs-8 col-md-3">
															<div class="ppupload btn btn-flat" align="center"> 
															<span>
															<div>
															<img id="pp2" style="border: 3px solid #ef4135;border-radius: 5%;" align="center" src="" width="auto" height="100px" alt="Choose Picture" />
															</div>
															<div class="overlay">
															<div style="position: absolute; top: 45%;right: 40%;left: 40%;">
															<div  id="ic2" style="">
															<i class="fa fa-plus"></i></div>
															</div>
															</div>
															</span> 
															<input id="uploadpp2" type="file" name="img2" class="upload" accept="image/*"/> 
															</div>
														</div>
														<div class="col-lg-3 col-xs-8 col-md-3">
															<div class="ppupload btn btn-flat" align="center"> 
															<span>
															<div>
															<img id="pp3" style="border: 3px solid #ef4135;border-radius: 5%;" align="center" src="" width="auto" height="100px" alt="Choose Picture" />
															</div>
															<div class="overlay">
															<div style="position: absolute; top: 45%;right: 40%;left: 40%;">
															<div  id="ic3" style="">
															<i class="fa fa-plus"></i></div>
															</div>
															</div>
															</span> 
															<input id="uploadpp3" type="file" name="img3" class="upload" accept="image/*"/> 
															</div>
														</div>
														<div class="col-lg-3 col-xs-8 col-md-3">
															<div class="ppupload btn btn-flat" align="center"> 
															<span>
															<div>
															<img id="pp4" style="border: 3px solid #ef4135;border-radius: 5%;" align="center" src="" width="auto" height="100px" alt="Choose Picture" />
															</div>
															<div class="overlay">
															<div style="position: absolute; top: 45%;right: 40%;left: 40%;">
															<div  id="ic4" style="">
															<i class="fa fa-plus"></i></div>
															</div>
															</div>
															</span> 
															<input id="uploadpp4" type="file" name="img4" class="upload" accept="image/*"/> 
															</div>
														</div>
													</div>
												</div>
												
											</div>
											<div class="box-footer">
												<td><button class="btn btn-primary" type="submit">Post</button></td>
											</div>
										</div>
										</form>
                                    </div>
									
									
                                </div>
                            </div>
							
							
							
							<!-- row of feeds -->
						<?php $postsql = "SELECT * FROM post order by times desc LIMIT 10;";
						$rowpost = mysqli_query($conn, $postsql);
						while($post = mysqli_fetch_array($rowpost)) {?>
												
							<div class="box ">
							
                                <div class="box-header">
								
									<!--feeds User -->
								
                                    <h3 class="box-title">
									<a href="#"><img src="<?php defindsql($conn,"propic","users","id","".$post['pid']."",0,0,0,0,0,0);?>" class="img-circle"  alt="user image" style="width:40px;"/><?php echo ' '.defindsql($conn,"fname","users","id","".$post['pid']."",0,0,0,0,0,0).' '.defindsql($conn,"lname","users","id","".$post['pid']."",0,0,0,0,0,0);?></a>
									</h3>
                                    <div class="box-tools pull-right">
										<span class="time"><i class="fa fa-clock-o"></i> <?php echo timeago($post['times']);?></span>
										<button type="button" class="btn btn-default dropdown-toggle" data-toggle="dropdown" ><span class="fa fa-ellipsis-v" data-toggle="tooltip" title="Option"></span></button>
                                        <ul class="dropdown-menu">
                                            <li><a data-widget="collapse"><i class="fa fa-minus"></i> Collapse</a></li>
                                            <li><a ><i class="fa fa-tag"></i> Tag</a></li>
                                            <li><a ><i class="fa fa-share"></i> Share</a></li>
                                            <li class="divider"></li>
                                            <li><a data-widget="remove" data-toggle="tooltip" title="Hide Temporary"><i class="fa fa-times"></i> Remove</a></li>
                                        </ul>
                                    </div>
                                </div>
								
                                <div class="box-body">
								
									<!--feeds text -->
                                    <?php echo $post['text'];?>
									
									<br /><br />
									<div class="row" align="center">
									
										<?php 
										$e=0;
										if($post['typ1'] != ''){$e = $e+1;}
										if($post['typ2'] != ''){$e = $e+1;}
										if($post['typ3'] != ''){$e = $e+1;}
										if($post['typ4'] != ''){$e = $e+1;}
										$use = 'not';
										if($post['typ1'] != ''){
											if($use == 'not'){if($e == 1 || $e == 3){$col = '12';$use = 'yes';}else{$col = '6';$use = 'yes';}}else{$col = '6';}
											echo '<div class="col-lg-'.$col.' col-xs-12 col-md-'.$col.'"><img src="data:'.$post['typ1'].';base64,'.$post['pic1'].'"></div>';}
										if($post['typ2'] != ''){ 
											if($use == 'not'){if($e == 1 || $e == 3){$col = '12';$use = 'yes';}else{$col = '6';$use = 'yes';}}else{$col = '6';}
											echo '<div class="col-lg-'.$col.' col-xs-12 col-md-'.$col.'"><img src="data:'.$post['typ2'].';base64,'.$post['pic2'].'"></div>';}
										if($post['typ3'] != ''){ 
											if($use == 'not'){if($e == 1 || $e == 3){$col = '12';$use = 'yes';}else{$col = '6';$use = 'yes';}}else{$col = '6';}
											echo '<div class="col-lg-'.$col.' col-xs-12 col-md-'.$col.'"><img src="data:'.$post['typ3'].';base64,'.$post['pic3'].'"></div>';}
										if($post['typ4'] != ''){ 
											if($use == 'not'){if($e == 1 || $e == 3){$col = '12';$use = 'yes';}else{$col = '6';$use = 'yes';}}else{$col = '6';}
											echo '<div class="col-lg-'.$col.' col-xs-12 col-md-'.$col.'"><img src="data:'.$post['typ4'].';base64,'.$post['pic4'].'"></div>';}?>
									</div>
                                </div>
								
                                <div class="box-footer">
								
									<!--feeds TOOLS -->
								
                                    <div class="box box-solid collapsed-box">
									
										<div class="box-header">
											<h3 class="box-title">
												<button class="btn btn-success"><i class="fa fa-thumbs-o-up"></i> Pick</button> · 
												<button class="btn btn-primary"><i class="fa fa-thumbs-o-down"></i> Kick</button> · 
												<button class="btn btn-default" data-widget="collapse"><i class="fa fa-quote-left"></i> Comment <i class="fa fa-angle-double-down"></i></button>
												<!-- <button class="btn btn-success disabled">Success</button> -->
											</h3>
										</div>
										
										<div class="box-body" style="display: none;">
											
												<!-- ROW OF Comment -->
												
											<div class="box box-solid">
												<div class="box-header">
													<h3 class="box-title">
														<a href="#"><img src="met/img/avatar.png" class="img-circle"  alt="user image" style="width:40px;"/>
															Mina Lee
														</a>
													</h3>
												</div>
												
												<div class="box-body">
														<p>
														sour/acidic sour/acidic chocolate malt ipa ipa hydrometer.
														</p>
												</div>
											</div>
											
										</div>
										
										<div class="box-footer" style="display: none;">
											<div class="input-group margin">
												<input type="text" class="form-control">
												<span class="input-group-btn">
													<button class="btn btn-primary btn-flat" type="button"><i class="fa fa-chevron-right"></i><i class="fa fa-chevron-right"></i><i class="fa fa-chevron-right"></i></button>
												</span>
											</div>
										</div>
										
									</div>
									
                                </div>
								
							</div>
						<?php }?>
						
							<!-- End row of feeds -->
                        </section>
						
						
						
						<!-- Right -->
						<!-- side -->
						
						
						<section class="col-lg-3"> 
							<div class="pull-left">
								<div class="nmslider">
									<div class="box box-solid">
										<div class="box-body">
										
										<!-- alert area -->
										
										
											<div class="alert alert-danger alert-dismissable">
												<i class="fa fa-ban"></i>
												<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
												<b>Alert!</b> Danger alert preview. This alert is dismissable. A wonderful serenity has taken possession of my entire soul, like these sweet mornings of spring which I enjoy with my whole heart.
											</div>
											<div class="alert alert-info alert-dismissable">
												<i class="fa fa-info"></i>
												<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
												<b>Alert!</b> Info alert preview. This alert is dismissable.
											</div>
											<div class="alert alert-warning alert-dismissable">
												<i class="fa fa-warning"></i>
												<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
												<b>Alert!</b> Warning alert preview. This alert is dismissable.
											</div>
											<div class="alert alert-success alert-dismissable">
												<i class="fa fa-check"></i>
												<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
												<b>Alert!</b> Success alert preview. This alert is dismissable.
											</div>
											
											
										</div>
										<div class="box-footer">
											<div class="box box-primary" id="onmlc">
												<div class="box-header">
													<h3 class="box-title"><i class="fa fa-clock-o"></i> Loading..</h3>
												</div>
											</div>
										</div>
									</div>	
								</div>
							</div>
						</section>
			
					</div>
					
				</section>
				
            </aside><!-- /.right-side -->
			
        </div><!-- ./wrapper -->

		
<!-- ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ -->

													<!-- Show clear -->

<!-- ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ -->


        <!-- jQuery 2.0.2 -->
        <script src="http://ajax.googleapis.com/ajax/libs/jquery/2.0.2/jquery.min.js"></script>
		
		<script type='text/javascript' src='met/js/jquery-1.10.1.js'></script>
        <!-- jQuery UI 1.10.3 -->
        <script src="met/js/jquery-ui-1.10.3.min.js" type="text/javascript"></script>
        <!-- Bootstrap -->
        <script src="met/js/bootstrap.min.js" type="text/javascript"></script>
        <!-- Morris.js charts -->
        <script src="//cdnjs.cloudflare.com/ajax/libs/raphael/2.1.0/raphael-min.js"></script>
        <script src="met/js/plugins/morris/morris.min.js" type="text/javascript"></script>
        <!-- Sparkline -->
        <script src="met/js/plugins/sparkline/jquery.sparkline.min.js" type="text/javascript"></script>
        <!-- jvectormap -->
        <script src="met/js/plugins/jvectormap/jquery-jvectormap-1.2.2.min.js" type="text/javascript"></script>
        <script src="met/js/plugins/jvectormap/jquery-jvectormap-world-mill-en.js" type="text/javascript"></script>
        <!-- jQuery Knob Chart -->
        <script src="met/js/plugins/jqueryKnob/jquery.knob.js" type="text/javascript"></script>
        <!-- daterangepicker -->
        <script src="met/js/plugins/daterangepicker/daterangepicker.js" type="text/javascript"></script>
        <!-- datepicker -->
        <script src="met/js/plugins/datepicker/bootstrap-datepicker.js" type="text/javascript"></script>
        <!-- Bootstrap WYSIHTML5 -->
        <script src="met/js/plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.all.min.js" type="text/javascript"></script>
        <!-- iCheck -->
        <script src="met/js/plugins/iCheck/icheck.min.js" type="text/javascript"></script>

        <!-- AdminLTE App -->
        <script src="met/js/AdminLTE/app.js" type="text/javascript"></script>

        <!-- AdminLTE dashboard demo (This is only for demo purposes) -->
        <script src="met/js/AdminLTE/dashboard.js" type="text/javascript"></script>

        <!-- AdminLTE for demo purposes -->
        <script src="met/js/AdminLTE/demo.js" type="text/javascript"></script>
        <script src="met/js/ext.js" type="text/javascript"></script>
	
    </body>
</html>
<?php

?>