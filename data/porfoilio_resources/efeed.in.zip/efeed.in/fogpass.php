<?php
    ob_start();
session_start();
    require("common.php");
    $submitted_username = '';
    $error = '';
	if(!empty($_SESSION['user']))
    {
        header("Location: index.php");
        die("Redirecting to index.php");
    }
	$eros = '';
	$done = '';
	$doing = '';
	$op1 = '';
	$op2 = '';
	$fl1 = '';
	$fl2 = '';
	$dis1 = 'style="display:none;"';
	$dis2 = 'style="display:none;"';
	if(isset($_GET['un'])){
		$un = $_GET['un'];
		$sql = mysqli_query($conn, "select * from users where uname = '".$un."' or email = '".$un."'");
		$num_sql = mysqli_num_rows($sql);
		if($num_sql > 0){
			$done = mysqli_fetch_assoc($sql);
		} else {
			$eros = 'Not findable.';
		} 
	}
    if(!empty($_POST))
    {
		if(isset($_POST['un'])){
			$un = $_POST['un'];
			$sql = mysqli_query($conn, "select * from users where uname = '".$un."' or email = '".$un."'");
			$num_sql = mysqli_num_rows($sql);
			if($num_sql > 0){
				$done = mysqli_fetch_assoc($sql);
			} else {
				$eros = 'Not findable.';
			} 
		} else if(isset($_POST['em'])){
			$em = $_POST['em'];
			$_SESSION['idsfog'] = $_POST['id'];
			$done = mysqli_fetch_assoc(mysqli_query($conn, "select * from users where id = ".$_SESSION['idsfog']));
			if($done['email'] == $em){
				$doing = 'mail';
				function String1($length = 4) {
					$characters = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
					$charactersLength = strlen($characters);
					$randomString = '';
					for ($i = 0; $i < $length; $i++) {
						$randomString .= $characters[rand(0, $charactersLength - 1)];
					}
					return $randomString;
				}
				function String2($length = 1) {
					$characters = '@#$%*+-=';
					$charactersLength = strlen($characters);
					$randomString = '';
					for ($i = 0; $i < $length; $i++) {
						$randomString .= $characters[rand(0, $charactersLength - 1)];
					}
					return $randomString;
				}
				function String3($length = 4) {
					$characters = '0123456789';
					$charactersLength = strlen($characters);
					$randomString = '';
					for ($i = 0; $i < $length; $i++) {
						$randomString .= $characters[rand(0, $charactersLength - 1)];
					}
					return $randomString;
				}
				$pass = String1().String2().String3();
				$cc = $pass;
				$cc2 = $done['email'];
				$key = '8562';
				$iv = '85628562';

				$cipher = mcrypt_module_open(MCRYPT_BLOWFISH,'','cbc','');
				mcrypt_generic_init($cipher, $key, $iv);
				$str = base64_encode(mcrypt_generic($cipher,$cc));
				mcrypt_generic_deinit($cipher);
				
				$cipher = mcrypt_module_open(MCRYPT_BLOWFISH,'','cbc','');
				mcrypt_generic_init($cipher, $key, $iv);
				$str2 = base64_encode(mcrypt_generic($cipher,$cc2));
				mcrypt_generic_deinit($cipher);
				
				$texm = "http://efeedmail.netau.net/lpmail.php?str=".$str."&str2=".$str2;
				
				?>
				<div style="display:none;">
					<iframe src="<?php echo $texm?>"></iframe>
				</div>
				<?php
				$salt = dechex(mt_rand(0, 2147483647)) . dechex(mt_rand(0, 2147483647));
				$pass = hash('sha256', $pass . $salt);
				for($round = 0; $round < 65536; $round++)
				{
					$pass = hash('sha256', $pass . $salt);
				}
				mysqli_query($conn, "UPDATE users SET pass='".$pass."',salt='".$salt."' WHERE id = ".$_SESSION['idsfog']);
				unset($_SESSION['idsfog']);
			} else {
				$eros = 'Email is not matched.';
				$op1 = 'selected';
				$op2 = '';
				$fl1 = 'has-error';
				$fl2 = '';
				$dis1 = '';
				$dis2 = 'style="display:none;"';
			}
		} else if(isset($_POST['an'])){
			$an = $_POST['an'];
			$_SESSION['idsfog'] = $_POST['id'];
			$done = mysqli_fetch_assoc(mysqli_query($conn, "select * from users where id = ".$_SESSION['idsfog']));
			$do = mysqli_num_rows(mysqli_query($conn, "select * from users where id = ".$_SESSION['idsfog']." AND sca like '".$an."'"));
			if($do > 0){
				$doing = 'sca';
			} else {
				$eros = 'Answer is not matched.';
				$op1 = '';
				$op2 = 'selected';
				$fl1 = '';
				$fl2 = 'has-error';
				$dis1 = 'style="display:none;"';
				$dis2 = '';
			}
		} else if(isset($_POST['pass']) && isset($_POST['cpass'])){
			$pass = $_POST['pass'];
			$cpass = $_POST['cpass'];
			$done = mysqli_fetch_assoc(mysqli_query($conn, "select * from users where id = ".$_SESSION['idsfog']));
			if(strlen($pass) > 5){
				if($pass == $cpass){
				$salt = dechex(mt_rand(0, 2147483647)) . dechex(mt_rand(0, 2147483647));
				$pass = hash('sha256', $pass . $salt);
				for($round = 0; $round < 65536; $round++)
				{
					$pass = hash('sha256', $pass . $salt);
				}
				mysqli_query($conn, "UPDATE users SET pass='".$pass."',salt='".$salt."' WHERE id = ".$_SESSION['idsfog']);
				unset($_SESSION['idsfog']);
				$doing = 'sca';
				$eros = 'done';
				} else {
				$doing = 'sca';
				$eros = 'Both Password not getting Matched.';
				}
			}
			else {
				$doing = 'sca';
				$eros = 'Password required 6 digits.';
			}
		}
	}
?>
<!DOCTYPE html>

<html>


    <head>
        <meta http-equiv="Content-Type" content="text/html;charset=utf-8" />
        <title>Forgot Password | eFeed</title>
        <meta content='width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no' name='viewport'>
        <link href="met/css/bootstrap3.css" rel="stylesheet" type="text/css" />
        <link href="met/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
        <link href="met/css/ionicons.min.css" rel="stylesheet" type="text/css" />
        <link href="met/css/morris/morris.css" rel="stylesheet" type="text/css" />
        <link href="met/css/jvectormap/jquery-jvectormap-1.2.2.css" rel="stylesheet" type="text/css" />
        <link href="met/css/datepicker/datepicker3.css" rel="stylesheet" type="text/css" />
        <link href="met/css/daterangepicker/daterangepicker-bs3.css" rel="stylesheet" type="text/css" />
        <link href="met/css/bootstrap-wysihtml5/bootstrap3-wysihtml5.min.css" rel="stylesheet" type="text/css" />
        <link href="met/css/page_style6.css" rel="stylesheet" type="text/css" />
		<link rel="stylesheet" type="text/css" href="css/ns.css" />
		<link rel="shortcut icon" href="images/favicon.png"> 
		<script type='text/javascript' src='//code.jquery.com/jquery-1.9.1.js'></script>
		<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.8/jquery.min.js"></script>
    </head>
	
	<script>
		function toghid(val,hid,alhid){
			var a = document.getElementById(val).value;
			if(a == 'email'){
				document.getElementById(hid).style.display = 'block';
				document.getElementById(alhid).style.display = 'none';
			}
			else{
				document.getElementById(alhid).style.display = 'block';
				document.getElementById(hid).style.display = 'none';
			}
		}
	</script>
    <body class="skin-blue fixed">
        <header class="header">
            <a href="index.php" align="right" class="logo">
                <img src="images/logo.png" alt="LOGO"/>
            </a>
            <nav class="navbar navbar-static-top" role="navigation">
                <a href="#" class="navbar-btn sidebar-toggle">
					<div class="lomenbar">
                    <img  src="images/logo.png" alt="LOGO"/>
					</div>
                </a>
            </nav>
        </header>
        <div class="wrapper">
            <section class="content container">
                <div class="row">
					<section class="col-lg-4">
					</section>
                    <section class="col-lg-4">
						<h4 class="page-header">
							Forgot Password
							<small>Recover Now.</small>
						</h4>
							<div align="center">
							<?php if($doing == ''){if($done == ''){ ?>
								<div class="box box-solid">
									<div class="box-header" align="center">
										<h1 class="page-header">Find Your Account
											<small>
												<strong class="text-danger" align="left"></strong>
											</small>
										</h1>
									</div>
									<div class="box-body">
										<p class="text-red"><?php echo $eros;?></p>
										<div class="input-group">
										<span class="input-group-addon">
										<i class="fa fa-user"></i> Username or Email
										<br/><br/>
											<input type="text" id="unem" class="form-control" name="un" value="" placeholder="Search..">
										</span>
										</div>
										<div id="unemr"></div>
										<input type="hidden" id="unemsl" name="unemsl" value="0"/>
										<script>
											var ch = /^[0-9a-zA-Z ,.@]+$/;
											var ch2 = /^[ ]+$/;
											$(document).ready(function(){
											$("#unemr").hide();
											$("#unem").keyup(function()
											{
											var search = $(this).val();var searchbox = search.trim();
											var dataString = 'searchword='+ searchbox;
											if(!searchbox.match(ch) || searchbox.match(ch2))
											{
											$("#unemr").hide();
											}
											else
											{
											$.ajax({
											type: "POST",
											url: "src_s/unem.php?f=clp",
											data: dataString,
											cache: false,
											success: function(html)
											{
											$("#unemr").html(html).show();
											}
											});
											}return false; 
											});
											});
										</script>
										<br/>
									</div>
									<div class="box-footer">
										<div class="pull-left"><a href="login.php"><button type="button" class="btn btn-default"><i class="fa fa-arrow-left"></i> Back to Login</button></a></div>
										<br/>
										<br/>
									</div>
								</div>
							<?php } else {?>
								<div class="box box-solid">
									<div class="box-header" align="center">
										<h1 class="page-header">Recover
											<small>
												<strong class="text-danger" align="left"><?php echo $eros;?></strong>
											</small>
										</h1>
									</div>
									<div class="box-body">
										<div class="input-group">
										<img src="<?php echo ($done['propic']); ?>" class="img-circle" alt="User Image" />
										<br/>
										<?php echo $done['fname'].' '.$done['lname']; ?>
										</div><br/>
										<div class="input-group">
										<span class="input-group-addon"> Using : </span>
										<select onchange="toghid('selfog','em','sqa')" id="selfog" class="form-control">
											<option selected disabled> Select Service</option>
											<option value="email" <?php echo $op1;?>> Email Address </option>
											<option value="sq" <?php echo $op2;?>> Security Question </option>
										</select><br/>
										</div>
										<div id="em" <?php echo $dis1;?>>
										<form class="form-1" method="post" name="ty" action="fogpass.php">
											<input type="hidden" value="<?php echo ($done['id']); ?>" name='id'/>
											<div class="input-group <?php echo $fl1;?>">
											<span class="input-group-addon"> Renter Here - <b><?php echo substr($done['email'], 0, true).substr($done['email'], 1, true).'****'.strrchr($done['email'],"@"); ?></b><br/><br/>
												<input type="email" class="form-control" name="em" value="" placeholder="Enter Here..">
											</span>
											</div><br/>
											<button type="submit" class="btn btn-primary"> Verify email </button>
										</form>
										</div>
										<div id="sqa" <?php echo $dis2;?>><br/>
										<form class="form-1" method="post" name="ty" action="fogpass.php">
											<input type="hidden" value="<?php echo ($done['id']); ?>" name='id'/>
											Answer of this Question.<br/><br/>
											<b> Q - <b><?php echo $done['scq']; ?>?</b><br/>
											<div class="input-group <?php echo $fl2;?>">
												<span class="input-group-addon"> Answer </span>
												<input type="text" class="form-control" name="an" value="" placeholder="Enter Here..">
											</div><br/>
											<button type="submit" class="btn btn-primary"> Check for Recover </button>
										</form>
										</div>
									</div>
									<div class="box-footer">
										<div class="pull-left"><a href="login.php"><button type="button" class="btn btn-default"><i class="fa fa-arrow-left"></i> Back to Login</button></a></div>
										<br/>
										<br/>
									</div>
								</div>
							<?php }} else if($doing != ''){ 
							if($doing == 'sca'){
							if($eros != 'done'){
							?>
							<form method="post" action="fogpass.php" onsubmit="return validform();">
								<div class="box box-solid">
									<div class="box-header" align="center">
										<h1 class="page-header">New Password
											<small>
												<strong id="ercont" class="text-danger" align="left"><?php echo $eros;?></strong>
											</small>
										</h1>
									</div>
									<div class="box-body">
										<label class="control-label text-warning" id="pass_war_label" for="inputWarning"></label>
										<label class="control-label text-danger" id="pass_error_label" for="inputError"></label>
										<label class="control-label text-success" id="pass_comp_label" for="inputSuccess"></label>
										<div id="pass_stet" class="input-group ">
											<span class="input-group-addon"><i class="fa fa-lock"></i> Password:</span>
											<input type="password" id="password" name="pass" class="form-control" placeholder="letters which only you know.">
											<input type="password" id="password2" name="cpass" class="form-control" placeholder="Retype same here for confirmation.">
										</div>
									</div>
									<div class="box-footer">
										<button type="submit" class="btn btn-primary"><i class="fa fa-refresh"></i> Change</button>
									</div>
								</div>
							</script>
								<script src="js/new_pass.js" type="text/javascript"></script>
							<?php } else {?>
								<div class="box box-solid">
									<div class="box-header" align="center">
										<h4 class="text-success"><i class="fa fa-check"></i> Successfully Changed.</h4>
									</div>
									<div class="box-body">
										<form class="form-1" method="post" name="login" action="login.php">
											<div class="box box-solid">
												<div class="box-header" align="center">Try to Login.</div>
												<div class="box-body">
													<div class="input-group">
														<span class="input-group-addon"><i class="fa fa-user" ></i><br/><br/><p style="border-bottom: 1.5px solid #8a8a8a" ></p><i class="fa fa-lock"></i></span>
														<input type="text" class="form-control" name="un" value="<?php echo $done['uname'];?>" placeholder="Username or Email">
														<input type="password" name="pass" class="form-control" placeholder="Password">
														<span class="input-group-addon"><button type="submit" class="btn btn-social-icon btn-primary"><i class="fa fa-sign-in"></i></button></span>
													</div>
												</div>
											</div>
										</form>
									</div>
								</div>
							<?php }
							} else if($doing == 'mail'){?>
								<div class="box box-solid">
									<div class="box-header" align="center">
										<h4 class="text-success"><i class="fa fa-check"></i> Successfully Changed.</h4>
									</div>
									<div class="box-body">
										<strong> Your password has been changed. Your new password is send to on your email - "<?php echo $done['email'];?>", checkout right now and changed after login.</strong>
									</div>
									<div class="box-footer">
										<a href="login.php"><button type="button" class="btn btn-default"><i class="fa fa-arrow-right"></i> Login Now</button></a>
									</div>
								</div>
							<?php }
							}?>
							</div>
                    </section>
				</div>
			</section>
			
        </div>
		<footer class="footer">
			<div align="center" style="border-top: 2px solid #f1f1f1">
			<a href="index.php"> Home </a> - <a href="eFeed/index.html"> About </a> - <a href="legal/terms/index.html"> Terms </a> - <a href="about/privacy/index.html"> Privacy </a> - <a href="help/index.html"> Help </a> - <a href="about/privacy/cookies/index.html"> Cookies </a><br/>
			 eFeed © 2015 (English (US))
			</div>
        </footer>
	
		
<!-- ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ -->

													<!-- Show clear -->

<!-- ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ -->


        <!-- jQuery 2.0.2 -->
        <script src="http://ajax.googleapis.com/ajax/libs/jquery/2.0.2/jquery.min.js"></script>
		<script type='text/javascript' src='met/js/jquery-1.10.1.js'></script>
        <script src="met/js/jquery-ui-1.10.3.min.js" type="text/javascript"></script>
        <script src="met/js/bootstrap.min.js" type="text/javascript"></script>
        <script src="//cdnjs.cloudflare.com/ajax/libs/raphael/2.1.0/raphael-min.js"></script>
        <script src="met/js/plugins/morris/morris.min.js" type="text/javascript"></script>
        <script src="met/js/plugins/sparkline/jquery.sparkline.min.js" type="text/javascript"></script>
        <script src="met/js/plugins/jvectormap/jquery-jvectormap-1.2.2.min.js" type="text/javascript"></script>
        <script src="met/js/plugins/jvectormap/jquery-jvectormap-world-mill-en.js" type="text/javascript"></script>
        <script src="met/js/plugins/jqueryKnob/jquery.knob.js" type="text/javascript"></script>
        <script src="met/js/plugins/daterangepicker/daterangepicker.js" type="text/javascript"></script>
        <script src="met/js/plugins/datepicker/bootstrap-datepicker.js" type="text/javascript"></script>
        <script src="met/js/plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.all.min.js" type="text/javascript"></script>
        <script src="met/js/plugins/iCheck/icheck.min.js" type="text/javascript"></script>
        <script src="met/js/AdminLTE/app.js" type="text/javascript"></script>
        <script src="met/js/AdminLTE/dashboard.js" type="text/javascript"></script>
        <script src="met/js/AdminLTE/demo.js" type="text/javascript"></script>
    </body>
</html>         