<?php
require("common.php");
ob_start();

session_start();
if(!empty($_SESSION['user']))
{
    header("Location: index.php");
    die("Redirecting to index.php");
}	
	require 'fb_src/facebook.php';
	$fb_app_url = 'http://efeed.in/fb_login.php';
	$facebook = new Facebook(array(
	'appId'  => '285236605006172',
	'secret' => '462a61d7c286f774c8268eb33eac62ab',
	'cookie' => true
	));
	$facebook_login_url = $facebook->getLoginUrl(array(
		'canvas' => 1,
		'fbconnect' => 0,
		'scope' => 'email,public_profile',
		'redirect_uri' => $fb_app_url
	));
	$id = $facebook->getUser();

if ( $id != '0' ) {

	$id = $facebook->getUser();
	$q = "SELECT * FROM users WHERE pass = '".$id."' AND salt = 'FB'";
	$ch = mysqli_num_rows(mysqli_query($conn, $q));
	if($ch != 0){
		$_SESSION['user'] = mysqli_fetch_assoc(mysqli_query($conn, $q));
		header("Location: index.php");
		die("Redirecting to: index.php");
	} else {
		
		$email = $facebook>getUser('email');
		
		if($email != null || $email != "" && filter_var($email, FILTER_VALIDATE_EMAIL)){
	$emq = "
				SELECT
					1
				FROM users 
				WHERE
					email = :email
			";
			$emq_params = array(
				':email' => $_POST['email'] );
			try
			{$emstmt = $db->prepare($emq);
			 $emresult = $emstmt->execute($emq_params);}
			catch(PDOException $ex)
			{die("Failed to run query: " . $ex->getMessage());}
		$emf = $emstmt->fetch();
	}
	if ($email == null || $email == ""){
		echo $er = "<i class='fa fa-times-circle-o'></i> Invalid email format";
		die();}
	else if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
		echo $er = "<i class='fa fa-times-circle-o'></i> Invalid email format";
		die();}
	else if($emf){
		echo $er = "<i class='fa fa-times-circle-o'></i> Emailaddress is already used.";
		die();}
		
		$uname = 'fb:'.$facebook>getUser('id');
		$pass = $facebook>getUser('id');
		$salt = 'FB';
	    $fname = $facebook>getUser('first_name');
	    $lname = $facebook>getUser('last_name');
	    $enroll = 'FACEBOOK';
	    $mn = '';
	    $tzo = 'Asia/Kolkata';
	    $stet = $facebook>getUser('quotes');
	    $gen = $facebook>getUser('gender');
			$bdate = $facebook>getUser('birthday');
			$year = substr(strrchr($bdate,"/"), 1);
			$month = strchr(substr(strchr($bdate,"/"), 1),"/",true);
			$day = strchr($bdate,'/',true);
		$bdate = $month.'/'.$day.'/'.$year;
		$crd = '-200%';
		$abt = $facebook>getUser('bio');
		$prop = 'https://graph.facebook.com/'.$id.'/picture?height=500&width=500';
		$propt = 'https://graph.facebook.com/'.$id.'/picture?height=250&width=250';
		$propic = 'https://graph.facebook.com/'.$id.'/picture?height=64&width=64';
		
/*  	    echo $fbfullname = $facebook>getUser('name') .'<br/>';
	    echo $cov = $facebook>getUser('cover')       .'<br/>';
	    echo $hw = $facebook>getUser('hometown')   .'<br/>';
	    echo $loc = $facebook>getUser('location')    .'<br/>';
	    echo $edu = $facebook>getUser('education')   .'<br/>';
	    echo $wrk = $facebook>getUser('work')        .'<br/>'; */
		
		$qry = "INSERT INTO users (
                email,
                uname,
                pass,
                salt,
                fname,
                lname,
                enroll,
                mobn,
				tzo,
				stet,
                gen,
                bdate,
                crd,
				about,
				prop,
				propt,
				propic
            ) VALUES (
                '".$email."',
                '".$uname."',
                '".$pass."',
                '".$salt."',
                '".$fname."',
                '".$lname."',
                '".$enroll."',
                '".$mn."',
                '".$tzo."',
				'".$stet."',
                '".$gen."',
                '".$bdate."',
                '".$crd."',
				'".$abt."',
				'".$prop."',
				'".$propt."',
				'".$propic."'
            )
        ";
		mysqli_query($conn, $qry);
		$_SESSION['user'] = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM users WHERE pass = '".$pass."' AND salt = 'FB'"));
		header("Location: exlog.php?q=".$pass."&q1=FB");
	}

} else {
  header("Location: ".$facebook_login_url);
}
?>