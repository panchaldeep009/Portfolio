<?php
ob_start();
require("common.php");
$er = "";
date_default_timezone_set('Asia/Kolkata');
$ef1="";$ef2="";$ef3="";$ef4="";$ef5="";$ef6="";$ef7="";$ef8="";$ef9="";$ef10="";
if ($_SERVER["REQUEST_METHOD"] == "POST") {
$fn = $_POST["fname"];
$ln = $_POST["lname"];
if (isset($_POST["gen"])) $gen = $_POST["gen"];
$d = $_POST["date"];
$m = $_POST["month"];
$y = $_POST["year"];
$un = $_POST["uname"];
$em = $_POST["email"];
$pass = $_POST["pass"];
$cpass = $_POST["cpass"];
$mn = $_POST["mobn"];
$en="";
if ($un != null || $un != "" && strlen($un) >= 4 && preg_match("/^[a-zA-Z0-9]*$/",$un)){
$unq = "SELECT
                1
            FROM users
            WHERE
                uname = :username
        ";
        $unq_params = array(
            ':username' => $_POST['uname'] );
        try
        {$unstmt = $db->prepare($unq);
         $unresult = $unstmt->execute($unq_params);}
        catch(PDOException $ex)
        {die("Failed to run query: " . $ex->getMessage());}
    $unf = $unstmt->fetch();
    
	$aunq = "SELECT
                1
            FROM ausers
            WHERE
                uname = :username
        ";
        $aunq_params = array(
            ':username' => $_POST['uname'] );
        try
        {$aunstmt = $db->prepare($aunq);
         $aunresult = $aunstmt->execute($aunq_params);}
        catch(PDOException $ex)
        {die("Failed to run query: " . $ex->getMessage());}
    $aunf = $aunstmt->fetch();
}
if($em != null || $em != "" && filter_var($em, FILTER_VALIDATE_EMAIL)){
$emq = "
            SELECT
                1
            FROM users 
            WHERE
                email = :email
        ";
        $emq_params = array(
            ':email' => $_POST['email'] );
        try
        {$emstmt = $db->prepare($emq);
         $emresult = $emstmt->execute($emq_params);}
        catch(PDOException $ex)
        {die("Failed to run query: " . $ex->getMessage());}
    $emf = $emstmt->fetch();
	
	$aemq = "
            SELECT
                1
            FROM ausers 
            WHERE
                email = :email
        ";
        $aemq_params = array(
            ':email' => $_POST['email'] );
        try
        {$aemstmt = $db->prepare($aemq);
         $aemresult = $aemstmt->execute($aemq_params);}
        catch(PDOException $ex)
        {die("Failed to run query: " . $ex->getMessage());}
    $aemf = $aemstmt->fetch();
}
if($fn == null || $fn == ""){
	$ef1 = "has-error";
	$er = "<i class='fa fa-times-circle-o'></i> You must be enter First name!";}
else if (strlen($fn) < 2 && strlen($fn) >= 1){
	$ef1 = "has-error";
	$er = "<i class='fa fa-times-circle-o'></i> Minimum 2 letter is Required in First name!";}
else if (!preg_match("/^[a-zA-Z ]*$/",$fn)) {
	$ef1 = "has-error";
	$er = "<i class='fa fa-times-circle-o'></i> Only letters and white space allowed in First name!";}
else if($ln == null || $ln == ""){
	$ef2 = "has-error";
	$er = "<i class='fa fa-times-circle-o'></i> You must be enter Last name !";}
else if (strlen($ln) < 2 && strlen($ln) >= 1){
	$ef2 = "has-error";
	$er = "<i class='fa fa-times-circle-o'></i> Minimum 2 letter is Required in Last name!";}
else if (!preg_match("/^[a-zA-Z ]*$/",$ln)) {
	$ef2 = "has-error";
	$er = "<i class='fa fa-times-circle-o'></i> Only letters and white space allowed in Last name!";}
else if (empty($_POST["gen"])){
	$ef3 = "has-error";
	$er = "<i class='fa fa-times-circle-o'></i> Select your gender!";}
else if ($d == null || $d == ""){
	$ef4 = "has-error";
	$er = "<i class='fa fa-times-circle-o'></i> Enter the Date!";}
else if ($d > 31 || !is_numeric($d)){
	$ef4 = "has-error";
	$er = "<i class='fa fa-times-circle-o'></i> Invalide Date!";}
else if ($m == null || $m == ""){
	$ef4 = "has-error";
	$er = "<i class='fa fa-times-circle-o'></i> Enter the Month!";}
else if ($m > 12 || !is_numeric($m)){
	$ef4 = "has-error";
	$er = "<i class='fa fa-times-circle-o'></i> Invalide Month!";}
else if ($y == null || $y == ""){
	$ef4 = "has-error";
	$er = "<i class='fa fa-times-circle-o'></i> Enter the Year!";}
else if (strlen($y) < 4 || strlen($y) > 4 || !is_numeric($y)){
	$ef4 = "has-error";$er = "<i class='fa fa-times-circle-o'></i> Invalide Year!";}
else if ($y >= ((date('Y'))-13) || $y < 1900){
	$ef4 = "has-error";$er = "<i class='fa fa-times-circle-o'></i> You must are not be under the age!";}
else if (!checkdate($m,$d,$y)){
	$ef4 = "has-error";$er = "<i class='fa fa-times-circle-o'></i> Invalide Birthdate!";}
else if ($un == null || $un == ""){
	$ef5 = "has-error";$er = "<i class='fa fa-times-circle-o'></i> Enter the username !";}
else if (strlen($un) < 4){
	$ef5 = "has-error";$er = "<i class='fa fa-times-circle-o'></i> Minimum 4 letter is Required in Username!!";}
else if (!preg_match("/^[a-zA-Z0-9]*$/",$un)){
	$ef5 = "has-error";$er = "<i class='fa fa-times-circle-o'></i> Invalide Username,Only latters & number is can use !";}
else if($unf){
    $ef5 = "has-error";$er = "<i class='fa fa-times-circle-o'></i> Username is already used.";}
else if($aunf){
    $ef5 = "has-error";$er = "<i class='fa fa-times-circle-o'></i> Username is already used.";}
else if ($em == null || $em == ""){
	$ef6 = "has-error";$er = "<i class='fa fa-times-circle-o'></i> Enter your correct email address!";}
else if (!filter_var($em, FILTER_VALIDATE_EMAIL)) {
    $ef6 = "has-error";$er = "<i class='fa fa-times-circle-o'></i> Invalid email format"; }
else if($emf){
    $ef6 = "has-error";$er = "<i class='fa fa-times-circle-o'></i> Emailaddress is already used.";}
else if($aemf){
	$ef6 = "has-error";$er = "<i class='fa fa-times-circle-o'></i> Emailaddress is already used.";}
else if ($pass == null || $pass == ""){
	$ef7 = "has-error";$er = "<i class='fa fa-times-circle-o'></i> Enter the password!";}
else if (strlen($pass) < 6){
	$ef7 = "has-error";$er = "<i class='fa fa-times-circle-o'></i> Minimum 6 letter is Required in Password!";}
else if ($cpass == null || $cpass == ""){
	$ef7 = "has-error";$er = "<i class='fa fa-times-circle-o'></i> Enter the Re-enter password!";}
else if ($pass != $cpass){
	$ef7 = "has-error";$er = "<i class='fa fa-times-circle-o'></i> Re-enter password is not match!";}
else if ($mn == null || $mn == ""){
	$ef8 = "has-error";$er = "<i class='fa fa-times-circle-o'></i> Enter your Mobile number!";}
else if (strlen($mn) < 10 || strlen($mn) > 10 || !is_numeric($mn)){
	$ef8 = "has-error";$er = "<i class='fa fa-times-circle-o'></i> Invalid your mobile number !";}
else{
	
	if($gen=="male"){ 
	$prop = 'pic/avtar/user_m.jpg';
	$propt = 'pic/avtar/user_m_t.jpg';
	$propic = 'pic/avtar/user_m_ic.jpg';
	}
	else{
	$prop = 'pic/avtar/user_f.jpg';
	$propt = 'pic/avtar/user_f_t.jpg';
	$propic = 'pic/avtar/user_f_ic.jpg';
	}
	 include 'gninfo.php';
		date_default_timezone_set(''.$timez.'');
 
	$query = "
            INSERT INTO users (
                email,
                uname,
                pass,
                salt,
                fname,
                lname,
                enroll,
                mobn,
				tzo,
                gen,
                bdate,
                crd,
				prop,
				propt,
				propic
            ) VALUES (
                :email,
                :username,
                :pass,
                :salt,
                :fn,
                :ln,
                :en,
                :mn,
                :tzo,
                :gen,
                :bdate,
                :crd,
				:prop,
				:propt,
				:propic
            )
        ";
        $salt = dechex(mt_rand(0, 2147483647)) . dechex(mt_rand(0, 2147483647));
        $pass = hash('sha256', $_POST['pass'] . $salt);
		$bdate = $d."/".$m."/".$y;
		$crd = '-100%';
        for($round = 0; $round < 65536; $round++)
        {
            $pass = hash('sha256', $pass . $salt);
        }
		
        $query_params = array(
            ':username' => $un,
            ':pass' => $pass,
            ':salt' => $salt,
			':email' => $em,
            ':fn' => $fn,
            ':ln' => $ln,
            ':gen' => $gen,
            ':bdate' => $bdate,
            ':en' => $en,
			':prop' => $prop,
			':propt' => $propt,
			':propic' => $propic,
			':crd' => $crd,
            ':mn' => $mn,
            ':tzo' => $timez
        );
        try
        {
            $stmt = $db->prepare($query);
            $result = $stmt->execute($query_params);
        }
        catch(PDOException $ex)
        {
            die("Failed to run query: " . $ex->getMessage());
        }
		ob_start();
session_start();
		$_SESSION['chp'];
		$_SESSION['chp']['un'] = $un;
		$_SESSION['chp']['em'] = $em;
		$_SESSION['chp']['en'] = $en;
        header("Location: chp.php");
        die("Redirecting to chp.php");
}
}

/* strtoupper(dechex(ceil(((abs(date('Hdm')+(((($en-date('110Hd30000')) << 27 ) >> 37)+date('Hd'))))*2)/12)));
date_default_timezone_set('Asia/Kolkata');
echo date('d/m/y H:i:s'); */
?>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html;charset=utf-8" />
        <title>Sign Up | eFeed</title>
        <meta content='width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no' name='viewport'>
        <link href="met/css/bootstrap3.css" rel="stylesheet" type="text/css" />
        <link href="met/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
        <link href="met/css/ionicons.min.css" rel="stylesheet" type="text/css" />
        <link href="met/css/morris/morris.css" rel="stylesheet" type="text/css" />
        <link href="met/css/jvectormap/jquery-jvectormap-1.2.2.css" rel="stylesheet" type="text/css" />
        <link href="met/css/datepicker/datepicker3.css" rel="stylesheet" type="text/css" />
        <link href="met/css/daterangepicker/daterangepicker-bs3.css" rel="stylesheet" type="text/css" />
        <link href="met/css/bootstrap-wysihtml5/bootstrap3-wysihtml5.min.css" rel="stylesheet" type="text/css" />
        <link href="met/css/page_style6.css" rel="stylesheet" type="text/css" />
		<link rel="stylesheet" type="text/css" href="css/ns.css" />
		<link rel="shortcut icon" href="images/favicon.png"> 
		<script type='text/javascript' src='//code.jquery.com/jquery-1.9.1.js'></script>
		<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.8/jquery.min.js"></script>
    </head>
	
	
    <body class="skin-blue fixed">
        <header class="header">
            <a href="index.php" align="right" class="logo">
                <img src="images/logo.png" alt="LOGO"/>
            </a>
            <nav class="navbar navbar-static-top" role="navigation">
                <a href="#" class="navbar-btn sidebar-toggle">
					<div class="lomenbar">

                    <img  src="images/logo.png" alt="LOGO"/>
					</div>
                </a>
            </nav>
        </header>
        <div class="wrapper">
            <section class="content container">
                <div class="row">
					<section class="col-lg-2">
					</section>
                    <section class="col-lg-8">
						<h4 class="page-header">
							Sign up
							<small>Create new account.</small>
						</h4>
						<div class="box box-solid">
							<div class="box-body">
								<p></p>
								<div class="row">
									<section class="col-lg-7" style="border-right: 2px solid #f4f4f4">
										<div class="box box-solid">
										<form method="post" onsubmit="return validsignup();">
											<div class="box-body">
												<div class="page-header text-center">
												<h3>Create New account</h3>
													<small>also with</small>
													<a class="btn btn-social-icon btn-facebook"><i class="fa fa-facebook"></i></a>
													<a class="btn btn-social-icon btn-google-plus"><i class="fa fa-google-plus"></i></a>
													<a class="btn btn-social-icon btn-twitter"><i class="fa fa-twitter"></i></a>
													<small>else</small>
												</div>
												<div class="form-group">
													<label class="control-label text-danger" for="inputError"><?php if(isset($er)){echo $er;} ?></label>
													<label id="fname_el" class="control-label text-danger" for="inputError"></label>
													<div id="fname_st" class="input-group <?php if(isset($ef1)){ echo $ef1; } ?>">
														<span class="input-group-addon">First Name:</span>
														<input id="fname" name="fname" type="text" value="<?php if(isset($_POST['fname'])){echo $_POST['fname'];}?>" class="form-control" placeholder="Your Name">
													</div>
													<label id="lname_el" class="control-label text-danger" for="inputError"></label>
													<div id="lname_st" class="input-group <?php if(isset($ef2)){echo $ef2;} ?>">
														<span class="input-group-addon">Last Name:</span>
														<input id="lname" name="lname" type="text" value="<?php if(isset($_POST['lname'])){echo $_POST['lname'];}?>" class="form-control" placeholder="Your Surname">
													</div><br/>
													<div class="form-group" align="center">
														Choose Gender :<br/>
														<label>
															<input type="radio" name="gen" class="minimal-rad" value="male" <?php if((isset($_POST['gen']) && $_POST['gen']=='female') || (isset($_POST['gen']) && $_POST['gen']!='male')){echo '';} else { echo 'checked';} ?> /> Male
														</label>
														<label>
															<input type="radio" name="gen" class="minimal-rad" value="female" <?php if(isset($_POST['gen']) && $_POST['gen']=='female'){echo 'checked';} ?>/> Female
														</label>
													</div>
													<label id="bday_error_label" class="control-label text-danger" for="inputError"></label>
													<div id="bday_stet" class="input-group <?php if(isset($ef4)){echo $ef4;}?>">
														<span class="input-group-addon"><i class="fa fa-calendar"></i> Birthday:</span>
														<span class="input-group-addon">DD<br/><div>-------</div>MM<br/><div>-------</div>YYYY</span>
														<input type="text" class="form-control" name="date" value="<?php if(isset($_POST['date'])){echo $_POST['date'];}?>" onkeypress="return isNum(event)" id="date" placeholder="Date"/>
														<input type="text" class="form-control" name="month" value="<?php if(isset($_POST['month'])){echo $_POST['month'];}?>" onkeypress="return isNum(event)" id="month" placeholder="Month"/>
														<input type="text" class="form-control" name="year" value="<?php if(isset($_POST['year'])){echo $_POST['year'];}?>" onkeypress="return isNum(event)" id="year" placeholder="Year"/>	
													</div>
													<label id="un_error_label" class="control-label text-danger" for="inputError"></label>
													<div id="un_stet" class="input-group <?php if(isset($ef5)){echo $ef5;}?>">
														<span class="input-group-addon"><i class="fa fa-user" ></i> Username:</span>
														<input type="text" class="form-control" name="uname" value="<?php if(isset($_POST['uname'])){echo $_POST['uname'];}?>" id="username" placeholder="example : name08">
													</div>
													<label id="em_error_label" class="control-label text-danger" for="inputError"></label>
													<div id="em_stet" class="input-group <?php if(isset($ef6)){echo $ef6;}?>">
														<span class="input-group-addon">@ Email Address:</span>
														<input type="text" id="email" name="email" value="<?php if(isset($_POST['email'])){echo $_POST['email'];}?>" class="form-control" placeholder="Enter your email address.">
													</div>
													<label class="control-label text-warning" id="pass_war_label" for="inputWarning" ></label>
													<label class="control-label text-danger" id="pass_error_label" for="inputError"></label>
													<label class="control-label text-success" id="pass_comp_label" for="inputSuccess"></label>
													<div id="pass_stet" class="input-group <?php if(isset($ef7)){echo $ef7;}?>">
														<span class="input-group-addon"><i class="fa fa-lock"></i> Password:</span>
														<input type="password" id="password" name="pass" class="form-control" placeholder="letters which only you know.">
														<input type="password" id="password2" name="cpass" class="form-control" placeholder="Retype same here for confirmation.">
													</div>
													<label id="pn_error_label" class="control-label text-danger" for="inputError"></label>
													<div id="pn_stet" class="input-group <?php if(isset($ef8)){echo $ef8;}?>">
														<div class="input-group-addon"><i class="fa fa-phone"></i> Phone number</div>
														<input type="text" id="phonen" placeholder="Your Phone Number" value="<?php if(isset($_POST['mobn'])){echo $_POST['mobn'];}?>" class="form-control" data-inputmask='"mask": "(999) 999-9999"' data-mask/>
														<input id="hiden_org_num" name="mobn" style="display:none;" value="<?php if(isset($_POST['mobn'])){echo $_POST['mobn'];}?>"/>
													</div><br/>
													<label id="cb_error_label" class="control-label text-danger" for="inputError"></label>
													<div class="checkbox">
														<label>
															<input id="agrement" type="checkbox" checked/>
														</label>
														I agree with this <a href="legal/terms/">Terms</a> and that I have read this <a href="about/privacy">Privacy Policy</a> including this <a href="about/privacy/cookies">cookie use</a>.May be receive email and sms notification from eFeed and can opt out at any time.
													</div>
												</div>
											</div>
											<div class="box-footer" align="right">
												<button type="submit" class="btn btn-social btn-primary">
													<i class="fa fa-plus"></i> Register
												</button>
											</div>
										</form>
										</div>
									</section>
									<section class="col-lg-5">
										<form class="form-1" method="post" name="login" action="login.php">
											<div class="box box-solid">
												<div class="box-header" align="center">
													<h1 class="page-header">I have already account.
														<small>
															then login here.
														</small>
													</h1>
												</div>
												<div class="box-body">
													<div class="input-group">
														<span class="input-group-addon"><i class="fa fa-user" ></i><br/><br/><p style="border-bottom: 1.5px solid #8a8a8a" ></p><i class="fa fa-lock"></i></span>
														<input type="text" class="form-control" name="un" value="" placeholder="Username or Email">
														<input type="password" name="pass" class="form-control" placeholder="Password">
														<span class="input-group-addon"><button type="submit" class="btn btn-social-icon btn-primary"><i class="fa fa-sign-in"></i></button></span>
													</div>
												</div>
											</div>
										</form>
										<div class="box box-solid box-body">
											<div class="page-header">
												<a class="btn btn-block btn-social btn-facebook">
													<i class="fa fa-facebook"></i> Sign in with Facebook
												</a>
											</div>
											<div class="page-header">
												<a class="btn btn-block btn-social btn-google-plus">
													<i class="fa fa-google-plus"></i> Sign in with Google
												</a>
											</div>
											<div class="">
												<a class="btn btn-block btn-social btn-twitter">
													<i class="fa fa-twitter"></i> Sign in with Twitter
												</a>
											</div>
										</div>
									</section>
								</div>
							</div>
						</div>
                    </section>
				</div>
			</section>
			
        </div>
		<footer class="footer">
			<div align="center" style="border-top: 2px solid #f1f1f1">
			<a href="index.php"> Home </a> - <a href="eFeed/index.html"> About </a> - <a href="legal/terms/index.html"> Terms </a> - <a href="about/privacy/index.html"> Privacy </a> - <a href="help/index.html"> Help </a> - <a href="about/privacy/cookies/index.html"> Cookies </a><br/>
			 eFeed © 2015 (English (US))
			</div>
        </footer>

		
<!-- ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ -->
													<!-- Show clear -->
<!-- ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ -->
        <script src="http://ajax.googleapis.com/ajax/libs/jquery/2.0.2/jquery.min.js"></script>
        <script src="met/js/jquery.ajax.2.0.2.min.js" type="text/javascript"></script>
        <script src="met/js/bootstrap.min.js" type="text/javascript"></script>
        <script src="met/js/plugins/input-mask/jquery.inputmask.js" type="text/javascript"></script>
        <script src="met/js/plugins/input-mask/jquery.inputmask.extensions.js" type="text/javascript"></script>
        <script src="met/js/AdminLTE/app.js" type="text/javascript"></script>
        <script src="met/js/AdminLTE/demo.js" type="text/javascript"></script>
        <script src="met/js/general_form.js" type="text/javascript"></script>
    </body>
</html>