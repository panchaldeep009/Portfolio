$(window).load(function(){
$(document).ready(function () {

    var length = $('#left').height() - $('#sidebar').height() + $('#left').offset().top;

    $(window).scroll(function () {

        var scroll = $(this).scrollTop();
        var height = $('#sidebar').height() + 'px';

        if (scroll < $('#left').offset().top) {

            $('#sidebar').css({
                'position': 'absolute',
                'top': '0'
            });

        } else if (scroll > length) {

            $('#sidebar').css({
                'position': 'absolute',
                'bottom': '0',
                'top': 'auto'
            });

        } else {

            $('#sidebar').css({
                'position': 'fixed',
                'top': '0',
                'height': height
            });

        }
    });

});
});

document.getElementById('uploadpp1').onchange = function (evt) { 
var tgt = evt.target || window.event.srcElement, files = tgt.files;
if (FileReader && files && files.length) {
var fr = new FileReader();
fr.onload = function () 
{document.getElementById("pp1").src = fr.result;} 
fr.readAsDataURL(files[0]); }
};
document.getElementById('uploadpp2').onchange = function (evt) { 
var tgt = evt.target || window.event.srcElement, files = tgt.files;
if (FileReader && files && files.length) {
var fr = new FileReader();
fr.onload = function () 
{ document.getElementById("pp2").src = fr.result;} 
fr.readAsDataURL(files[0]); }
};
document.getElementById('uploadpp3').onchange = function (evt) { 
var tgt = evt.target || window.event.srcElement, files = tgt.files;
if (FileReader && files && files.length) {
var fr = new FileReader();
fr.onload = function () 
{ document.getElementById("pp3").src = fr.result;} 
fr.readAsDataURL(files[0]); }
};
document.getElementById('uploadpp4').onchange = function (evt) { 
var tgt = evt.target || window.event.srcElement, files = tgt.files;
if (FileReader && files && files.length) {
var fr = new FileReader();
fr.onload = function () 
{ document.getElementById("pp4").src = fr.result; 
document.getElementById("ic4").hide()} 
fr.readAsDataURL(files[0]); }
};