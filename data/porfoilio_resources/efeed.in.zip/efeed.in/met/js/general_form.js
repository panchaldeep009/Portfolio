$(function() {
    $("[data-mask]").inputmask();
});
function validsignup(){
	if(checksignup()){return true;}
	else{
	return false;}
}
function checksignup() {
        if(is('fname','fname_el','fname_st','input-group',2)){return false;}
   else if(is('lname','lname_el','lname_st','input-group',3)){return false;}
   else if(is('date','bday_error_label','bday_stet','input-group',1)){return false;}
   else if(is('month','bday_error_label','bday_stet','input-group',1)){return false;}
   else if(is('year','bday_error_label','bday_stet','input-group',4)){return false;}
   else if(is('username','un_error_label','un_stet','input-group',4)){return false;}
   else if(is('email','em_error_label','em_stet','input-group',6)){return false;}
   else if(is('password','pass_error_label','pass_stet','input-group',6)){return false;}
   else if(is('password2','pass_error_label','pass_stet','input-group',6)){return false;}
   else if(is('hiden_org_num','pn_error_label','pn_stet','input-group',10)){return false;}
   else if(checkbox()){return false;}
   else {return true;}
}
function checkbox(){
	if(document.getElementById('agrement').checked){
		document.getElementById("cb_error_label").innerHTML = ''; 
		return false;
	}
	else{ 
		document.getElementById("cb_error_label").innerHTML = '<i class="fa fa-times-circle-o"></i> You need to agree with this then after you can use eFeed.';
		return true;
	}
}
function req(id,reid,reid_class,limit) {
	var perameter = document.getElementById(id).value;
	if(perameter.length < limit){
		document.getElementById(reid).innerHTML = '<i class="fa fa-times-circle-o"></i> Minimum '+limit+' latters are required';
		document.getElementById(reid_class).className = 'input-group has-error';
		return true;
	} else {
		document.getElementById(reid).innerHTML = '';
		document.getElementById(reid_class).className = 'input-group';
		return false;
	}
}
function has_error(id) {
	var perameter = document.getElementById(id).value;
	if(perameter.length != 0){
		return true;
		document.getElementById("cb_error_label").innerHTML = 'solve the error first';
	} else { return false;}
}
function is(id,er_l,er_c,cl_name,limit) {
	var perameter = document.getElementById(id).value;
	if(perameter.length == 0){
		document.getElementById(er_l).innerHTML = '<i class="fa fa-times-circle-o"></i> It is empty.';
		document.getElementById(er_c).className = cl_name+' has-error';
		return true;
	} else {
		if(req(id,er_l,er_c,limit)){return true;}
		else{return false;}
	}
}


function isNum(evt) {
	evt = (evt) ? evt : window.event;
	var charCode = (evt.which) ? evt.which : evt.keyCode;
	if (charCode > 31 && (charCode < 48 || charCode > 57)) {
		return false;
	}
	return true;
}

document.getElementById("username").onkeyup = function() {veluidlc("username")};

function veluidlc(id) {
	var x = document.getElementById(id);
	x.value = x.value.toLowerCase();
}

var CapsLock = (function(){
  var capsLock = false;
  var listeners = [];
  var isMac = /Mac/.test(navigator.platform);
  function isOn(){
	return capsLock;
  }
  function addListener(listener){
	listeners.push(listener);

  }
  function handleKeyPress(e){
	if (!e) e = window.event;
	var priorCapsLock = capsLock;
	var charCode = (e.charCode ? e.charCode : e.keyCode);
	if (charCode >= 97 && charCode <= 122){
	  capsLock = e.shiftKey;
	}else if (charCode >= 65 && charCode <= 90 && !(e.shiftKey && isMac)){
	  capsLock = !e.shiftKey;
	}
	if (capsLock != priorCapsLock){
	  for (var index = 0; index < listeners.length; index ++){
		listeners[index](capsLock);
	  }
	}

  }
  if (window.addEventListener){
	window.addEventListener('keypress', handleKeyPress, false);
  }else{
	document.documentElement.attachEvent('onkeypress', handleKeyPress);
  }
  return {
	isOn        : isOn,
	addListener : addListener
  };

})();	

document.getElementById("password").onkeyup = function() {
	if (CapsLock.isOn()){
		document.getElementById('pass_stet').className = "input-group has-warning";
		document.getElementById('pass_war_label').innerHTML = '<i class="fa fa-warning"></i> Warning - CapsLock is on.';
		document.getElementById('pass_error_label').innerHTML = '';
	}
	if (!CapsLock.isOn()){
		document.getElementById('pass_stet').className = "input-group";
		document.getElementById('pass_war_label').innerHTML = "";
	}
};

document.getElementById("password2").onkeyup = function() {
	if (CapsLock.isOn()){
		document.getElementById('pass_stet').className = "input-group has-warning";
		document.getElementById('pass_war_label').innerHTML = '<i class="fa fa-warning"></i> Warning - CapsLock is on.';
		document.getElementById('pass_error_label').innerHTML = '';
	}
	if (!CapsLock.isOn()){
		document.getElementById('pass_stet').className = "input-group";
		document.getElementById('pass_war_label').innerHTML = "";
	}
};

document.getElementById("phonen").onkeyup = function() {document.getElementById('hiden_org_num').value = document.getElementById("phonen").value.replace(/[&\/\\#,_ +()$~%.'":*?<>{}]/g, '').replace(/[^\w\s]/gi, '');};

document.getElementById("fname").onchange = function() {length_id_error('fname','fname_el','fname_st',2)};
document.getElementById("lname").onchange = function() {length_id_error('lname','lname_el','lname_st',2)};
document.getElementById("username").onchange = function() {length_id_error('username','un_error_label','un_stet',4)};
document.getElementById("phonen").onchange = function() {length_id_error('hiden_org_num','pn_error_label','pn_stet',10)};

document.getElementById("email").onchange = function vadem() {
	var emila = document.getElementById("email").value;
	if (!validatemail(emila)){
		document.getElementById('em_error_label').innerHTML = '<i class="fa fa-times-circle-o"></i> Enter valid email address.';
		document.getElementById('em_stet').className = 'input-group has-error';
		return false;
	} else {
		document.getElementById('em_error_label').innerHTML = '';
		document.getElementById('em_stet').className = 'input-group';
		return true;
	}
};
document.getElementById("password").onchange = function() {passcheck()};
function passcheck() {
	var perameter = document.getElementById("password").value;
	if(perameter.length != 0){
		if(perameter.length < 6){
			document.getElementById('pass_error_label').innerHTML = '<i class="fa fa-times-circle-o"></i> Minimum six characters are required for Password';
			document.getElementById('pass_stet').className = 'input-group has-error';
			document.getElementById('pass_war_label').innerHTML = '';
			document.getElementById('pass_comp_label').innerHTML = '';
		} else {
			document.getElementById('pass_war_label').innerHTML = '';
			document.getElementById('pass_error_label').innerHTML = '';
			document.getElementById('pass_comp_label').innerHTML = '';
			document.getElementById('pass_stet').className = 'input-group';
		}
	} else {
		document.getElementById('pass_war_label').innerHTML = '';
		document.getElementById('pass_error_label').innerHTML = '';
		document.getElementById('pass_comp_label').innerHTML = '';
		document.getElementById('pass_stet').className = 'input-group';
	}
}
	
document.getElementById("password2").onchange = function() {
	var pass = document.getElementById("password").value;
	var pass2 = document.getElementById("password2").value;
	if(pass.length > 5){
		if (pass != pass2){
			document.getElementById('pass_war_label').innerHTML = '';
			document.getElementById('pass_comp_label').innerHTML = '';
			document.getElementById('pass_error_label').innerHTML = '<i class="fa fa-times-circle-o"></i> Confirm password is not geting match';
			document.getElementById('pass_stet').className = 'input-group has-error';
		} else {
			document.getElementById('pass_war_label').innerHTML = '';
			document.getElementById('pass_error_label').innerHTML = '';
			document.getElementById('pass_comp_label').innerHTML = '<i class="fa fa-check"></i> Successfully match.';
			document.getElementById('pass_stet').className = 'input-group has-success';
		}
	} else {
	passcheck();
	}
};

function validatemail(value) {
    var x = value;
    var atpos = x.indexOf("@");
    var dotpos = x.lastIndexOf(".");
    if (atpos<1 || dotpos<atpos+2 || dotpos+2>=x.length) {
        return false;
    } else { return true;}
}

function length_id_error(id,reid,reid_class,limit) {
	var perameter = document.getElementById(id).value;
	if(perameter.length != 0){
		if(perameter.length < limit){
			document.getElementById(reid).innerHTML = '<i class="fa fa-times-circle-o"></i> Minimum '+limit+' latters are required';
			document.getElementById(reid_class).className = 'input-group has-error';
		} else {
			document.getElementById(reid).innerHTML = '';
			document.getElementById(reid_class).className = 'input-group';
		}
	}
}

document.getElementById("date").onkeyup = function() {maxminunder(31,1,'date')};
document.getElementById("month").onkeyup = function() {maxminunder(12,1,'month')};
document.getElementById("year").onkeyup = function() {if(document.getElementById("year").value.length >= 4){maxminunder(yearmax(),1930,'year')}};
document.getElementById("year").onchange = function() {maxminunder(yearmax(),1930,'year')};

function yearmax() {
	var d = new Date();
	var n = d.getFullYear();
	return n - 9;
}

function maxminunder(max,min,id) 
{
	var num = document.getElementById(id).value;
	if(num > max){document.getElementById(id).value = max;}
	if(num < min){document.getElementById(id).value = min;}
	if(num == ''){document.getElementById(id).value = '';}
}