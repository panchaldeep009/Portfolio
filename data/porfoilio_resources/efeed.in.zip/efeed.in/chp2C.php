<?php
    require("common.php");
    ob_start();
session_start();
    if(empty($_SESSION['user']))
    {
        header("Location: login.php");
        die("Redirecting to login.php");
    }
	if(!empty($_SESSION['auser']))
    {
        header("Location: login.php");
        die("Redirecting to login.php");
    }
$data = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM users WHERE id = ".$_SESSION['user']['id']));
error_reporting (E_ALL ^ E_NOTICE);
if (!isset($_SESSION['user_file_ext'])){ 
	$_SESSION['user_file_ext']= "";
}
if(!empty($_SESSION['auser']))
    {
        header("Location: login.php");
        die("Redirecting to login.php");
    }
    if(empty($_SESSION['user']))
    {
        header("Location: login.php");
        die("Redirecting to login.php");
    }



$upload_dir = "pic/user_prop"; 				
$upload_path = $upload_dir."/";	
$large_image_prefix = "prop_"; 			
$thumb_image_prefix = "propt_";			
$ic_image_prefix = "propic_";			
$large_image_name = $large_image_prefix.$_SESSION['user']['uname'];     
$thumb_image_name = $thumb_image_prefix.$_SESSION['user']['uname'];  
$ic_image_name = $ic_image_prefix.$_SESSION['user']['uname'];   
$max_file = "3"; 			
$max_width = "800";							
$thumb_width = "250";						
$thumb_height = "250";	
$ic_width = "64";						
$ic_height = "64";	
$allowed_image_types = array('image/pjpeg'=>"jpg",'image/jpeg'=>"jpg",'image/jpg'=>"jpg",'image/png'=>"png",'image/x-png'=>"png",'image/gif'=>"gif");
$allowed_image_ext = array_unique($allowed_image_types);
$image_ext = "";
foreach ($allowed_image_ext as $mime_type => $ext) {
    $image_ext.= strtoupper($ext)." ";
}







function resizeImage($image,$width,$height,$scale) {
	list($imagewidth, $imageheight, $imageType) = getimagesize($image);
	$imageType = image_type_to_mime_type($imageType);
	$newImageWidth = ceil($width * $scale);
	$newImageHeight = ceil($height * $scale);
	$newImage = imagecreatetruecolor($newImageWidth,$newImageHeight);
	switch($imageType) {
		case "image/gif":
			$source=imagecreatefromgif($image); 
			break;
	    case "image/pjpeg":
		case "image/jpeg":
		case "image/jpg":
			$source=imagecreatefromjpeg($image); 
			break;
	    case "image/png":
		case "image/x-png":
			$source=imagecreatefrompng($image); 
			break;
  	}
	imagecopyresampled($newImage,$source,0,0,0,0,$newImageWidth,$newImageHeight,$width,$height);
	
	switch($imageType) {
		case "image/gif":
	  		imagegif($newImage,$image); 
			break;
      	case "image/pjpeg":
		case "image/jpeg":
		case "image/jpg":
	  		imagejpeg($newImage,$image,90); 
			break;
		case "image/png":
		case "image/x-png":
			imagepng($newImage,$image);  
			break;
    }
	
	chmod($image, 0777);
	return $image;
}



function resizeThumbnailImage($thumb_image_name, $image, $width, $height, $start_width, $start_height, $scale){
	list($imagewidth, $imageheight, $imageType) = getimagesize($image);
	$imageType = image_type_to_mime_type($imageType);
	
	$newImageWidth = ceil($width * $scale);
	$newImageHeight = ceil($height * $scale);
	$newImage = imagecreatetruecolor($newImageWidth,$newImageHeight);
	switch($imageType) {
		case "image/gif":
			$source=imagecreatefromgif($image); 
			break;
	    case "image/pjpeg":
		case "image/jpeg":
		case "image/jpg":
			$source=imagecreatefromjpeg($image); 
			break;
	    case "image/png":
		case "image/x-png":
			$source=imagecreatefrompng($image); 
			break;
  	}
	imagecopyresampled($newImage,$source,0,0,$start_width,$start_height,$newImageWidth,$newImageHeight,$width,$height);
	switch($imageType) {
		case "image/gif":
	  		imagegif($newImage,$thumb_image_name); 
			break;
      	case "image/pjpeg":
		case "image/jpeg":
		case "image/jpg":
	  		imagejpeg($newImage,$thumb_image_name,90); 
			break;
		case "image/png":
		case "image/x-png":
			imagepng($newImage,$thumb_image_name);  
			break;
    }
	chmod($thumb_image_name, 0777);
	return $thumb_image_name;
	chmod($ic_image_name, 0777);
	return $ic_image_name;
}



function getHeight($image) {
	$size = getimagesize($image);
	$height = $size[1];
	return $height;
}



function getWidth($image) {
	$size = getimagesize($image);
	$width = $size[0];
	return $width;
}




$large_image_location = $upload_path.$large_image_name.$_SESSION['user_file_ext'];
$thumb_image_location = $upload_path.$thumb_image_name.$_SESSION['user_file_ext'];
$ic_image_location = $upload_path.$ic_image_name.$_SESSION['user_file_ext'];




if(!is_dir($upload_dir)){
	mkdir($upload_dir, 0777);
	chmod($upload_dir, 0777);
}


if (file_exists($large_image_location)){
	if(file_exists($thumb_image_location)){
		$thumb_photo_exists = "<img src=\"".$upload_path.$thumb_image_name.$_SESSION['user_file_ext']."\" alt=\"Thumbnail Image\"/>";
		$ic_photo_exists = "<img src=\"".$upload_path.$ic_image_name.$_SESSION['user_file_ext']."\" alt=\"ICON Image\"/>";
	    include '_set-db.php';
		$imgP  = $large_image_location;
		$imgT = $thumb_image_location;
		$imgI = $ic_image_location;
		$conn = mysql_connect($hosted, $usered, $passed);
		mysql_select_db($dbed);
		$sqlIMG ="UPDATE users SET 
					prop='$imgP',
					propt='$imgT',
					propic='$imgI'
					WHERE id=".$_SESSION['user']['id'];
		$current_id = mysql_query($sqlIMG) or die("<b>Error:</b> Problem on Image Insert<br/>" . mysql_error());
		mysql_close($conn);
		if(isset($current_id)) {
	    $_SESSION['user_file_ext']= "";
		unset($_SESSION['user_file_ext']);
		$large_photo_exists = "";
		$thumb_photo_exists = "";
		header("Location: index.php");
		}else{
		$uper="ERROR";
		$large_photo_exists = "";
		$thumb_photo_exists = "";
		}
	}else{
		$thumb_photo_exists = "";
		$ic_photo_exists = "";
	}
   	$large_photo_exists = "<img src=\"".$upload_path.$large_image_name.$_SESSION['user_file_ext']."\" alt=\"Large Image\"/>";
} else {
   	$large_photo_exists = "";
	$thumb_photo_exists = "";
	$ic_photo_exists = "";
}

if (isset($_POST["upload"])) { 

	$userfile_name = $_FILES['image']['name'];
	$userfile_tmp = $_FILES['image']['tmp_name'];
	$userfile_size = $_FILES['image']['size'];
	$userfile_type = $_FILES['image']['type'];
	$filename = basename($_FILES['image']['name']);
	$file_ext = strtolower(substr($filename, strrpos($filename, '.') + 1));
	
	if((!empty($_FILES["image"])) && ($_FILES['image']['error'] == 0)) {
		
		foreach ($allowed_image_types as $mime_type => $ext) {
			if($file_ext==$ext && $userfile_type==$mime_type){
				$error = "";
				break;
			}else{
				$error = "Only <strong>".$image_ext."</strong> images accepted for upload<br />";
			}
		}
		
		if ($userfile_size > ($max_file*1048576)) {
			$error.= "Images must be under ".$max_file."MB in size";
		}
		
	}else{
		$error= "Select an image for upload";
	}
	//Everything is ok, so we can upload the image.
	if (strlen($error)==0){
		
		if (isset($_FILES['image']['name'])){
			$large_image_location = $large_image_location.".".$file_ext;
			$thumb_image_location = $thumb_image_location.".".$file_ext;
			$ic_image_location = $ic_image_location.".".$file_ext;
			$_SESSION['user_file_ext']=".".$file_ext;
			
			move_uploaded_file($userfile_tmp, $large_image_location);
			chmod($large_image_location, 0777);
			
			$width = getWidth($large_image_location);
			$height = getHeight($large_image_location);
			if ($width > $max_width){
				$scale = $max_width/$width;
				$uploaded = resizeImage($large_image_location,$width,$height,$scale);
				
			}else{
				$scale = 1;
				$uploaded = resizeImage($large_image_location,$width,$height,$scale);
			}

			if (file_exists($thumb_image_location)) {
				unlink($thumb_image_location);
			}else if (file_exists($thumb_image_location)) {
				unlink($thumb_image_location);
			}
		}
		header("location:".$_SERVER["PHP_SELF"]);
		exit();
	}
}

if (isset($_POST["upload_thumbnail"]) && strlen($large_photo_exists)>0) {
	$x1 = $_POST["x1"];
	$y1 = $_POST["y1"];
	$x2 = $_POST["x2"];
	$y2 = $_POST["y2"];
	$w = $_POST["w"];
	$h = $_POST["h"];
	$scale = $thumb_width/$w;
	$cropped = resizeThumbnailImage($thumb_image_location, $large_image_location,$w,$h,$x1,$y1,$scale);
	$scale = $ic_width/$w;
	$cropped = resizeThumbnailImage($ic_image_location, $large_image_location,$w,$h,$x1,$y1,$scale);
	header("location:".$_SERVER["PHP_SELF"]);
	exit();
	
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
	<title>Upload Profile Picture</title>
	<script type="text/javascript" src="js/jquery-pack.js"></script>
	<script type="text/javascript" src="js/jquery.imgareaselect.min.js"></script>
	<meta content='width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no' name='viewport'>
    <link href="met/css/bootstrap.css" rel="stylesheet" type="text/css" />
    <link href="met/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
    <link href="met/css/AdminLTE.css" rel="stylesheet" type="text/css" />
	<link rel="shortcut icon" href="images/favicon.png"> 
	<script src="http://ajax.googleapis.com/ajax/libs/jquery/2.0.2/jquery.min.js"></script>
    <script src="met/js/bootstrap.min.js" type="text/javascript"></script>
</head>
<body>

                    <div class="row">
						
                        <section class="col-lg-9">
						
							<form method="post" action="chp.php">
								<div class="box box-solid">
									<div class="box-header">
										<h3 class="box-title">Profile Picture</h3>
									</div>
									<div class="box-body">
									
									
			<?php
//Only display the javacript if an image has been uploaded
if(strlen($large_photo_exists)>0){
	$current_large_image_width = getWidth($large_image_location);
	$current_large_image_height = getHeight($large_image_location);?>
<script type="text/javascript">
function preview(img, selection) { 
	var scaleX = <?php echo $thumb_width;?> / selection.width; 
	var scaleY = <?php echo $thumb_height;?> / selection.height; 
	
	$('#thumbnail + div > img').css({ 
		width: Math.round(scaleX * <?php echo $current_large_image_width;?>) + 'px', 
		height: Math.round(scaleY * <?php echo $current_large_image_height;?>) + 'px',
		marginLeft: '-' + Math.round(scaleX * selection.x1) + 'px', 
		marginTop: '-' + Math.round(scaleY * selection.y1) + 'px' 
	});
	$('#x1').val(selection.x1);
	$('#y1').val(selection.y1);
	$('#x2').val(selection.x2);
	$('#y2').val(selection.y2);
	$('#w').val(selection.width);
	$('#h').val(selection.height);
} 

$(document).ready(function () { 
	$('#save_thumb').click(function() {
		var x1 = $('#x1').val();
		var y1 = $('#y1').val();
		var x2 = $('#x2').val();
		var y2 = $('#y2').val();
		var w = $('#w').val();
		var h = $('#h').val();
		if(x1=="" || y1=="" || x2=="" || y2=="" || w=="" || h==""){
			alert("You must make a selection first");
			return false;
		}else{
			return true;
		}
	});
}); 

$(window).load(function () { 
	$('#thumbnail').imgAreaSelect({ aspectRatio: '1:<?php echo $thumb_height/$thumb_width;?>', onSelectChange: preview }); 
});

</script>
<?php }
//Display error message if there are any
if(strlen($error)>0){
	echo "<h4 align='center' class='text-red'>Error ! - ".$error."</h4>";
}
if(strlen($large_photo_exists)>0 && strlen($thumb_photo_exists)>0){
header("Location: index.php");
}else{
		if(strlen($large_photo_exists)>0){?>
		<h3 align="center">Crop & Upload Photo</h3>
		<div align="center">
			<img src="<?php echo $upload_path.$large_image_name.$_SESSION['user_file_ext'];?>" style="float: left; margin-right: 10px;" id="thumbnail" alt="Create Thumbnail" />
			<br style="clear:both;"/>
			<form name="thumbnail" action="<?php echo $_SERVER["PHP_SELF"];?>" method="post">
				<?php
				$tx_centreX = round($current_large_image_width / 2);
				$tx_centreY = round($current_large_image_height / 2);
				if($current_large_image_width > $current_large_image_height){
					$tx_sq = $current_large_image_height;
				} else {
					$tx_sq = $current_large_image_width;
				}
				$tx_cropWidth  = $tx_sq;
				$tx_cropHeight = $tx_sq;
				$tx_cropWidthHalf  = round($tx_cropWidth / 2); 
				$tx_cropHeightHalf = round($tx_cropHeight / 2);

				$tx_x1 = max(0, $tx_centreX - $tx_cropWidthHalf);
				$tx_y1 = max(0, $tx_centreY - $tx_cropHeightHalf);

				$tx_x2 = min($current_large_image_width, $tx_centreX + $tx_cropWidthHalf);
				$tx_y2 = min($current_large_image_height, $tx_centreY + $tx_cropHeightHalf);
				?>
				<input type="hidden" name="x1" value="<?php echo $tx_x1; ?>" id="x1" />
				<input type="hidden" name="y1" value="<?php echo $tx_y1; ?>" id="y1" />
				<input type="hidden" name="x2" value="<?php echo $tx_x2; ?>" id="x2" />
				<input type="hidden" name="y2" value="<?php echo $tx_y2; ?>" id="y2" />
				<input type="hidden" name="w" value="<?php echo $tx_cropWidth;?>" id="w" />
				<input type="hidden" name="h" value="<?php echo $tx_cropHeight;?>" id="h" /><br/>
				<input type="submit"  class="btn btn-primary btn-flat"  name="upload_thumbnail" value="Upload" id="save_thumb" />
			</form>
		</div>
	<hr />
	<?php 	} ?>
	<?php if(!strlen($large_photo_exists)>0) {?>
<h4 align="center" class="text-red"><?php echo $uper;?></h4>
<h3 align="center">Upload Photo</h3>
<div align="center"><img src="<?php echo $data['propt'];?>" id="pp1" width="300px"  style="border: 3px solid red; border-radius: 3%;"/></div>

<form name="photo" enctype="multipart/form-data" action="<?php echo $_SERVER["PHP_SELF"];?>" method="post">
<div align="center">
	<div class="ppupload btn btn-flat">
		<div class="btn btn-primary btn-flat">Select</div>
		<input id="uploadpp" type="file" name="image" class="upload" accept="image/*"/> 
	</div>
		<input id="upbtn" class="btn btn-primary btn-flat" type="submit" name="upload" value="Upload" />
</div>
<div align="right">
	<a href="index.php"><button class="btn btn-primary btn-flat" >Skip <i class="fa fa-arrow-right"></i></button></a>
</div>
</form>
<script>
document.getElementById('uploadpp').onchange = function (evt) { 
var tgt = evt.target || window.event.srcElement, files = tgt.files;
if (FileReader && files && files.length) {
var fr = new FileReader();
fr.onload = function () 
{document.getElementById('pp1').src = fr.result;} 
fr.readAsDataURL(files[0]); }
};

$(function(){
    $("#upbtn").hide();
    $("#uploadpp").change(function(){
        $("#upbtn").show();
    });
});
</script>
<?php } ?>
<?php } ?>
									</div>
								</div>
							</form>	
						
                        </section>

					</div>
					<footer class="footer">
			<div align="center" style="border-top: 2px solid #f1f1f1">
			<a href="index.php"> Home </a> - <a href="eFeed/index.html"> About </a> - <a href="legal/terms/index.html"> Terms </a> - <a href="about/privacy/index.html"> Privacy </a> - <a href="help/index.html"> Help </a> - <a href="about/privacy/cookies/index.html"> Cookies </a><br/>
			 eFeed © 2015 (English (US))
			</div>
        </footer>
</body>
</html>