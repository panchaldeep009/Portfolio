<?php
session_start();
// added in v4.0.0
require_once 'autoload.php';
use Facebook\FacebookSession;
use Facebook\FacebookRedirectLoginHelper;
use Facebook\FacebookRequest;
use Facebook\FacebookResponse;
use Facebook\FacebookSDKException;
use Facebook\FacebookRequestException;
use Facebook\FacebookAuthorizationException;
use Facebook\GraphObject;
use Facebook\Entities\AccessToken;
use Facebook\HttpClients\FacebookCurlHttpClient;
use Facebook\HttpClients\FacebookHttpable;
// init app with app id and secret
FacebookSession::setDefaultApplication( '','' );
// login helper with redirect_uri
    $helper = new FacebookRedirectLoginHelper('http://127.0.0.1/1353/fbconfig.php' );
try {
  $session = $helper->getSessionFromRedirect();
} catch( FacebookRequestException $ex ) {
  // When Facebook returns an error
} catch( Exception $ex ) {
  // When validation fails or other local issues
}
// see if we have a session
if ( isset( $session ) ) {
  // graph api request for user data
  $request = new FacebookRequest( $session, 'GET', '/me' );
  $response = $request->execute();
  // get response
  $graphObject = $response->getGraphObject();
     	echo $fbid = $graphObject->getProperty('id')         .'<br/>';
 	    echo $fbfullname = $graphObject->getProperty('name') .'<br/>';
	    echo $femail = $graphObject->getProperty('email')    .'<br/>';
	    echo $fn = $graphObject->getProperty('first_name')   .'<br/>';
	    echo $ln = $graphObject->getProperty('last_name')   .'<br/>';
	    echo $gen = $graphObject->getProperty('gender')    .'<br/>';
	    echo $bdate = $graphObject->getProperty('birthday')  .'<br/>';
	    echo $bio = $graphObject->getProperty('bio')     .'<br/>';
	    echo $qu = $graphObject->getProperty('quotes')       .'<br/>';
	    echo $cov = $graphObject->getProperty('cover')       .'<br/>';
	    echo $hw = $graphObject->getProperty('hometown')   .'<br/>';
	    echo $loc = $graphObject->getProperty('location')    .'<br/>';
	    echo $edu = $graphObject->getProperty('education')   .'<br/>';
	    echo $wrk = $graphObject->getProperty('work')        .'<br/>';
    /* ---- header location after session ----*/
} else {
  $loginUrl = $helper->getLoginUrl();
 header("Location: ".$loginUrl);
}
?>