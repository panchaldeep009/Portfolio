<?php
echo file_get_contents("http://ajax.googleapis.com/ajax/services/search/web?v=1.0&q=test");
?>