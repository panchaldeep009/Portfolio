<?php

    require("common.php");
    ob_start();
session_start();
    if(empty($_SESSION['user']))
    {
		if(isset($_GET['page'])){
			header("Location: login.php?page");
			die("Redirecting to login.php?page");
		}
		else{
			header("Location: login.php?new_sup&q=chp.php");
			die("Redirecting to login.php?new_sup&q=chp.php");
		}
    }
	if(isset($_GET['page'])){ $pg = true; }
	$data = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM users WHERE id = ".$_SESSION['user']['id']));

    if($data['crd']>0){
		if(isset($_GET['page'])){
			header("Location: chp3.php?page");
		}
		else{
			header("Location: chp3.php");
		}
	}
	$errorschp = '';
	$sq1 = "";
	$sqa1 = "";
	if(!empty($_POST)){
	    $sq1 = $_POST['sq1'];
	    $sqa1 = $_POST['sqa1'];
		if($_POST['sq1'] == null || $_POST['sq1'] == ""){
		$errorschp = 'Enter the Security Question';}
		else if(strlen($_POST['sq1']) < 6){
		$errorschp = 'Your Security Question is much short';}
		else if($_POST['sqa1'] == null || $_POST['sqa1'] == ""){
		$errorschp = 'Enter answer for Security Question';}
		else if(strlen($_POST['sqa1']) < 4){
		$errorschp = 'Your Answer for Security Question is much short';}
		else{
			$sq1 = strtoupper($_POST['sq1']);
			$sqa1 = strtoupper($_POST['sqa1']);
			$UPNMSG = "UPDATE users SET scq='".$sq1."',  sca='".$sqa1."', crd='1' WHERE id = ".$_SESSION['user']['id'];
			mysqli_query($conn, $UPNMSG);
			if(isset($_GET['page'])){
				header("Location: chp.php?page");
			}
			else{
				header("Location: chp.php");
			}
		}
		
	}
?>
<!DOCTYPE html>

<html>


    <head>
        <meta charset="UTF-8">
        <title>Complete CheckPoint | eFeed</title>
        <meta content='width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no' name='viewport'>
        <link href="met/css/bootstrap.css" rel="stylesheet" type="text/css" />
        <link href="met/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
        <link href="met/css/AdminLTE.css" rel="stylesheet" type="text/css" />
		<link rel="shortcut icon" href="images/favicon.png"> 
    </head>
	
	
    <body class="skin-blue fixed">
        <header class="header">
            <a href="index.php" align="right" class="logo">
                <img src="images/logo.png" alt="LOGO"/>
            </a>
            <nav class="navbar navbar-static-top" role="navigation">
                <a href="#" class="navbar-btn sidebar-toggle">
					<div class="lomenbar">
                    <span class="sr-only">Toggle navigation</span>
                    <img  src="images/logo.png" alt="LOGO"/>
					</div>
                </a>
                   
                <div class="navbar-right">
                    <ul class="nav navbar-nav" >
						<li class="dropdown user user-menu">
							<a href="#" class="dropdown-toggle" data-toggle="dropdown">
								<i class="glyphicon glyphicon-user"></i>
									<span><?php echo htmlentities($data['uname'], ENT_QUOTES, 'UTF-8'); ?> <i class="caret"></i></span>
							</a>
							<ul class="dropdown-menu">
								<li class="user-header">
									<img src="<?php echo ($data['propt']); ?>" class="img-circle" alt="User Image" />
										<p>
											<?php echo $data['fname']." ".$data['lname'];?> - <?php echo $data['enroll'];?>
											<small><?php echo $data['email'];?></small>
										</p>
								</li>
								<li class="user-footer">
									<div class="pull-right">
										<a href="logout.php" class="btn btn-default btn-flat"><i class="fa fa-sign-out"></i> Logout</a>
									</div>
								</li>
							</ul>
						</li>
                    </ul>
                </div>
            </nav>
        </header>
        <div class="wrapper row-offcanvas row-offcanvas-left">

            <aside class="right-side">
				
                <section class="content-header">
                    <h1>
                      Checkpoint
                        <small>(1)</small>
                    </h1>
                </section>

                <section class="content">
                    <div class="row">
						
                        <section class="col-lg-9">
						
							<form method="post" action="chp.php">
								<div class="box box-solid">
									<div class="box-header">
										<h3 class="box-title">Set Security Question</h3>
									</div>
									
									<div class="box-body">
										<p>- Enter Question and Answer which is only you know because it is use in forgot password conduction so be careful and remember that.</p>
										<h4 class="text-red"><?php echo $errorschp;?></h4>
										<div class="box box-solid">
										<div class="box-body">Question<input type="text" value="<?php echo $sq1;?>" class="form-control" name="sq1"/></div>
										<div class="box-footer">Answer <input type="text" value="<?php echo $sqa1;?>" class="form-control" name="sqa1"/></div>
										</div>
										
									</div>
									<div class="box-footer"><div align="right">
									<button class="btn btn-primary btn-flat" type="submit">Next <i class="fa fa-arrow-right"></i></button>
									</div>
									</div>
								</div>
							</form>	
						
                        </section>

					</div>
					
				</section>
				
            </aside>
			
        </div>
		<footer class="footer">
			<div align="center" style="border-top: 2px solid #f1f1f1">
			<a href="index.php"> Home </a> - <a href="eFeed"> About </a> - <a href="legal/terms"> Terms </a> - <a href="about/privacy"> Privacy </a> - <a href="help"> Help </a> - <a href="about/privacy/cookies"> Cookies </a><br/>
			 eFeed © 2015 (English (US))
			</div>
        </footer>

		
<!-- ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ -->

													<!-- Show clear -->

<!-- ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ -->


        <!-- jQuery 2.0.2 -->
        <script src="http://ajax.googleapis.com/ajax/libs/jquery/2.0.2/jquery.min.js"></script>
		<script type='text/javascript' src='met/js/jquery-1.10.1.js'></script>
        <script src="met/js/jquery-ui-1.10.3.min.js" type="text/javascript"></script>
        <script src="met/js/bootstrap.min.js" type="text/javascript"></script>
        <script src="met/js/plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.all.min.js" type="text/javascript"></script>


	
    </body>
</html>
<?php

?>