<?php
require("common.php");ob_start();

session_start();
if(!empty($_SESSION['user']))
{
    header("Location: index.php");
    die("Redirecting to index.php");
}
$google_client_id 		= '879774293901-jrhbb69gprrdhn2cn5br5kics8v6gl8m.apps.googleusercontent.com';
$google_client_secret 	= 'pzZ0h1Z1QFu4fR2ByuEOlpXE';
$google_redirect_url 	= 'http://www.efeed.in/gp_login.php'; 
$google_developer_key 	= 'xxxxxxxxxxxxxxxxxxxxxxxxxxxxx';

//include google api files
require_once 'gp_src/Google_Client.php';
require_once 'gp_src/contrib/Google_Oauth2Service.php';


$gClient = new Google_Client();
$gClient->setApplicationName('Login to eFeed');
$gClient->setClientId($google_client_id);
$gClient->setClientSecret($google_client_secret);
$gClient->setRedirectUri($google_redirect_url);
$gClient->setDeveloperKey($google_developer_key);

$google_oauthV2 = new Google_Oauth2Service($gClient);

//If user wish to log out, we just unset Session variable
if (isset($_REQUEST['reset'])) 
{
  unset($_SESSION['token']);
  $gClient->revokeToken();
  header('Location: ' . filter_var($google_redirect_url, FILTER_SANITIZE_URL)); //redirect user back to page
}

//If code is empty, redirect user to google authentication page for code.
//Code is required to aquire Access Token from google
//Once we have access token, assign token to session variable
//and we can redirect user back to page and login.
if (isset($_GET['code'])) 
{ 
	$gClient->authenticate($_GET['code']);
	$_SESSION['token'] = $gClient->getAccessToken();
	header('Location: ' . filter_var($google_redirect_url, FILTER_SANITIZE_URL));
	return;
}


if (isset($_SESSION['token'])) 
{ 
	$gClient->setAccessToken($_SESSION['token']);
}


if ($gClient->getAccessToken()) 
{

	  $user = $google_oauthV2->userinfo->get();  
	  $id = $user['id'];
	$q = "SELECT * FROM users WHERE pass = '".$id."' AND salt = 'GP'";
	$ch = mysqli_num_rows(mysqli_query($conn, $q));
	if($ch != 0){
		$_SESSION['user'] = mysqli_fetch_assoc(mysqli_query($conn, $q));
		$prop = filter_var($user['picture'], FILTER_VALIDATE_URL).'?sz=500';
		$propt = filter_var($user['picture'], FILTER_VALIDATE_URL).'?sz=250';
		$propic = filter_var($user['picture'], FILTER_VALIDATE_URL).'?sz=64';
		$T = "UPDATE `users` SET
		`prop` = '".$prop."',
		`propt` = '".$propt."',
		`propic` = '".$propic."'
		WHERE `id` = ".$_SESSION['user']['id'];
		mysqli_query($conn, $T);
		header("Location: index.php");
		die("Redirecting to: index.php");
	} else {
	  
	$email = filter_var($user['email'], FILTER_SANITIZE_EMAIL);
	
	if($email != null || $email != "" && filter_var($email, FILTER_VALIDATE_EMAIL)){
	$emq = "
				SELECT
					1
				FROM users 
				WHERE
					email = :email
			";
			$emq_params = array(
				':email' => $_POST['email'] );
			try
			{$emstmt = $db->prepare($emq);
			 $emresult = $emstmt->execute($emq_params);}
			catch(PDOException $ex)
			{die("Failed to run query: " . $ex->getMessage());}
		$emf = $emstmt->fetch();
	}
	if ($email == null || $email == ""){
		echo $er = "<i class='fa fa-times-circle-o'></i> Invalid email format";
		die();}
	else if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
		echo $er = "<i class='fa fa-times-circle-o'></i> Invalid email format";
		die();}
	else if($emf){
		echo $er = "<i class='fa fa-times-circle-o'></i> Emailaddress is already used.";
		die();}
	
	$uname = 'g+:'.$user['id'];
	$pass = $user['id'];
	$salt = 'GP';
	$fname = filter_var($user['given_name'], FILTER_SANITIZE_SPECIAL_CHARS);
	$lname = filter_var($user['family_name'], FILTER_SANITIZE_SPECIAL_CHARS);
	$enroll = 'GOOGLE+';
	$mn = '';
	$tzo = 'Asia/Kolkata';
	$stet = 'I like eFeed ;)';
	$gen = filter_var($user['gender'], FILTER_SANITIZE_SPECIAL_CHARS);
	$bdate = '';
	$crd = '-200%';
	$abt = '';
	$prop = filter_var($user['picture'], FILTER_VALIDATE_URL).'?sz=500';
	$propt = filter_var($user['picture'], FILTER_VALIDATE_URL).'?sz=250';
	$propic = filter_var($user['picture'], FILTER_VALIDATE_URL).'?sz=64';
	
	  unset($_SESSION['token']);
	$qry = "INSERT INTO users (
                email,
                uname,
                pass,
                salt,
                fname,
                lname,
                enroll,
                mobn,
				tzo,
				stet,
                gen,
                bdate,
                crd,
				about,
				prop,
				propt,
				propic
            ) VALUES (
                '".$email."',
                '".$uname."',
                '".$pass."',
                '".$salt."',
                '".$fname."',
                '".$lname."',
                '".$enroll."',
                '".$mn."',
                '".$tzo."',
				'".$stet."',
                '".$gen."',
                '".$bdate."',
                '".$crd."',
				'".$abt."',
				'".$prop."',
				'".$propt."',
				'".$propic."'
            )
        ";
		mysqli_query($conn, $qry);
		$_SESSION['user'] = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM users WHERE pass = '".$pass."' AND salt = 'GP'"));
		header("Location: exlog.php?q=".$pass."&q1=GP");
	}
}
else 
{
	//For Guest user, get google login url
	$authUrl = $gClient->createAuthUrl();
}

if(isset($authUrl)) //user is not logged in, show login button
{
	header("Location: ".$authUrl);
} 
if(isset($er)){
	echo $er;
}
?>

