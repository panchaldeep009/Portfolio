<?php
require("common.php");
$targate = substr(strrchr($_SERVER['REQUEST_URI'],'/'), 1);
if($targate == 'me'){header('Location: index.php?me');}
else{
$data = mysqli_fetch_assoc(mysqli_query($conn, "SELECT id FROM users WHERE uname='".$targate."'"));
if($data['id'] != null){header('Location: index.php?user='.$data['id'].'');}
else{
$data = mysqli_fetch_assoc(mysqli_query($conn, "SELECT id FROM users WHERE email='".$targate."'"));
if($data['id'] != null){header('Location: index.php?user='.$data['id'].'');}
else{
$data = mysqli_fetch_assoc(mysqli_query($conn, "SELECT id FROM users WHERE id='".$targate."'"));
if($data['id'] != null){header('Location: index.php?user='.$data['id'].'');}
}
}
}
?>
<style>
background:#e6eecc url(images/beige_paper.png) repeat top left;
</style>
<H1 style="font-size: 10em;">404</H1><br />
<H1 style="font-size: 5em;">Wrong Place !</H1><br />
______________________________________________<br />
<img width="100%" height="100%" src="images/404_low.jpg"/>
