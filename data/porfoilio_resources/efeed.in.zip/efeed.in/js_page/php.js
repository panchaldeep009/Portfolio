function loaddiv(link, div)
{
var xmlhttp;
if (window.XMLHttpRequest){
xmlhttp=new XMLHttpRequest();}
else {
xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");}
xmlhttp.onreadystatechange=function(){
if (xmlhttp.readyState==4 && xmlhttp.status==200) {
document.getElementById(div).innerHTML=xmlhttp.responseText; }}
xmlhttp.open("GET",link,true);
xmlhttp.send();
}

function update(link) 
{ 
$.post(link);
}

window.setInterval(function(){
	loaddiv("js_page/msgn.php", "msgn");
	 update("js_page/update.php");
	loaddiv("js_page/msgc.php", "msgc");
	loaddiv("js_page/onml.php", "onmlc");
	loaddiv("js_page/notn.php", "notn");
	loaddiv("js_page/mailn.php", "mailn");
	loaddiv("js_page/notc.php", "notc");
	loaddiv("js_page/mailc.php", "mailc");
}, 3000);

function msgnull(){
	sendd("js_page/sto.php?messages");
	loaddiv("js_page/msgn.php", "msgn");
    loaddiv("js_page/msgc.php", "msgc");
	}
function notsnull(){
	sendd("js_page/sto.php?nots");
	loaddiv("js_page/notn.php", "notn");
	loaddiv("js_page/notc.php", "notc");
	}
function mailnull(){
	sendd("js_page/php.php?mail");
	loaddiv("js_page/mailn.php", "mailn");
	loaddiv("js_page/mailc.php", "mailc");
	}

var oxmlHttpSend;
function sendd(action)
{
    if(typeof XMLHttpRequest != "undefined")
    {
        oxmlHttpSend = new XMLHttpRequest();
    }
    else if (window.ActiveXObject)
    {
       oxmlHttpSend = new ActiveXObject("Microsoft.XMLHttp");
    }
    if(oxmlHttpSend == null)
    {
       alert("Browser does not support XML Http Request");
       return;
    }
    oxmlHttpSend.open("GET",action,true);
    oxmlHttpSend.send(null);
}
