<?php
require("../common.php");
session_start();
$data = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM users WHERE id = ".$_SESSION['user']['id']));
$notsql = "SELECT * FROM nots WHERE revid = '".$_SESSION['user']['id']."' AND state = '1' order by times desc LIMIT 10";
$rownot = mysqli_query($conn, $notsql);
$num_not = mysqli_num_rows($rownot);
$sql = "UPDATE users SET nnot='".$num_not."' WHERE id=".$_SESSION['user']['id'];
$data['nnot'] = $num_not;?>
	<li class="header">You have <?php if($data['nnot'] != 0){ echo ($data['nnot'])." notifications "; } else { echo "no notifications";}?></li>
	<li>
		<ul class="menu">
			<?php while($not = mysqli_fetch_array($rownot)) {?>
			<li>
				<a href="#">
					<i class="<?php echo $not['ic'];?>"></i>
					<?php echo $not['atxt']." ".$not['nots']." ".$not['atxt2'];?>
				</a>
			</li>
			<?php } ?>
		</ul>
		<?php $rlnum_nots = mysqli_num_rows($rownot);
		if($rlnum_nots > 10){
		$leftnots = $rlnum_nots - 10;?>
		<div align="center"><?php echo $leftmsg." ";?> More</div><?php }?>
	</li>
	<li class="footer"><a href="#">View all</a></li>