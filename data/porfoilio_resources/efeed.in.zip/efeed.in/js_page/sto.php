<?php
require("../common.php");
session_start();
if(isset($_GET['messages'])){
$UPNMSG = "UPDATE users SET nmsg='0' WHERE id=".$_SESSION['user']['id'];
mysqli_query($conn, $UPNMSG);
$UPNMSG = "UPDATE msg SET state='0' WHERE revid = ".$_SESSION['user']['id']." AND state = 1";
mysqli_query($conn, $UPNMSG);
}
if(isset($_GET['nots'])){

$UPNMSG = "UPDATE users SET nnot='0' WHERE id=".$_SESSION['user']['id'];
mysqli_query($conn, $UPNMSG);
$UPNMSG = "UPDATE nots SET state='0' WHERE revid = ".$_SESSION['user']['id']." AND state = 1 revid != 0 ";
mysqli_query($conn, $UPNMSG);
} 
if(isset($_GET['mail'])){

$UPNMSG = "UPDATE users SET nmail='0' WHERE id=".$_SESSION['user']['id'];
mysqli_query($conn, $UPNMSG);
$UPNMSG = "UPDATE mail SET state='0' WHERE revid = ".$_SESSION['user']['id']." AND state = 1";
mysqli_query($conn, $UPNMSG);

} 
if(isset($_GET['crd5'])){
$UPNMSG = "UPDATE users SET crd=5 WHERE id = ".$_SESSION['user']['id']."";
mysqli_query($conn, $UPNMSG);
header("Location: ../chp2.php");
} 

?>