<?php
require("../common.php");
session_start();
$data = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM users WHERE id = ".$_SESSION['user']['id']));
$num_mail = mysqli_num_rows(mysqli_query($conn, "SELECT * FROM mail WHERE revid = ".$_SESSION['user']['id']." AND state = 1"));
$data['nmail'] = $num_mail;?>
<i class="fa  fa-envelope-o"></i>
<?php if($data['nmail'] !=	0){
	echo "<span class='label label-danger'>";echo ($data['nmail']);echo "</span>";
} ?>