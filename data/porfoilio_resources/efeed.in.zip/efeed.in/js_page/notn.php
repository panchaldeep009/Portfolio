<?php
require("../common.php");
session_start();
$data = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM users WHERE id = ".$_SESSION['user']['id']));
$num_not = mysqli_num_rows(mysqli_query($conn, "SELECT * FROM nots WHERE revid = '".$_SESSION['user']['id']."' AND state = '1'"));
mysqli_fetch_assoc(mysqli_query($conn, "UPDATE users SET nnot = ".$num_not." WHERE id = ".$_SESSION['user']['id']));
$data['nnot'] = $num_not;?>
<i class="fa fa-globe"></i>
<?php
if($data['nnot'] !=	0){echo "<span class='label label-warning'>";echo ($data['nnot']);echo "</span>";}?>