<?php
require("../common.php");
session_start();
$data = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM users WHERE id = ".$_SESSION['user']['id']));
$num_msg = mysqli_num_rows(mysqli_query($conn, "SELECT * FROM msg WHERE revid = ".$_SESSION['user']['id']." AND state = 1"));
$data['nmsg'] = $num_msg;?>
<i class="fa fa-comments-o"></i>
<?php if($data['nmsg'] !=	0){
	echo "<span class='label label-success'>";echo ($data['nmsg']);echo "</span>";
}?>