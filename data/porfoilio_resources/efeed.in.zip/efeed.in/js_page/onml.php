<?php
require("common.php");
session_start();
$data = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM users WHERE id = ".$_SESSION['user']['id']));
?>
<div class="box-header" data-toggle="collapse" data-widget="collapse">
	<h3 class="box-title">Messages</h3>
</div>
<div class="box-body">											   
	<?php
	$quryrowou = "select a.id, a.propic, a.fname, a.lname, a.llog, count(m.id) as msg_count
					from users a
					left join msg m on a.`id` = m.`sendid` AND ".$_SESSION['user']['id']." = m.`revid` OR a.`id` = m.`revid` AND ".$_SESSION['user']['id']." = m.`sendid`
					group by a.id
					order by msg_count desc limit 6 ";
	$rowinfo = mysqli_query($conn, $quryrowou);
	$nums = mysqli_num_rows(mysqli_query($conn, "SELECT * FROM users WHERE id != ".$_SESSION['user']['id']." AND ".time()." - llog < 5"));
	while($info = mysqli_fetch_array($rowinfo)) {
	if($info['id'] != $_SESSION['user']['id'] && time() - $info['llog'] < 5){?>
	<a>
		<div class="box ">
			<div class="box-header" data-toggle="collapse" data-widget="collapse">
				<h3 class="box-title">
					<a href="#"><img src="<?php echo $info['propic'];?>" class="img-circle"  alt="user image" style="width:40px;"/><?php echo $info['fname']." ".$info['lname'];?></a>
				</h3>
			    <div class="box-tools pull-right">
					<span class="time text-success"><i class="fa fa-certificate"></i> Online</span>
				</div>
			</div>
		</div>
	</a>
	<?php }
	else if($info['id'] != $_SESSION['user']['id']){?>
	<a>
		<div class="box ">
			<div class="box-header" data-toggle="collapse" data-widget="collapse">
				<h3 class="box-title">
					<a href="#"><img src="<?php echo $info['propic'];?>" class="img-circle"  alt="user image" style="width:40px;"/><?php echo $info['fname']." ".$info['lname'];?></a>
				</h3>
				<div class="box-tools pull-right">
					<span class="time"><i class="fa fa-clock-o"></i> <?php  echo timeago($info['llog']);?></span>
				</div>
			</div>
		</div>
	</a>
	<?php }	}?>						
</div><!-- /.box-body -->
<div class="box-footer">
	<?php if($nums > 1){echo $nums.' Users';}else if($nums == 1){echo '1 User';}else{echo 'No Users';}?> Online 
</div>