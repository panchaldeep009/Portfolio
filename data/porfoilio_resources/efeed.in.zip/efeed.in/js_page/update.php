<?php
require("../common.php");
session_start();
$nowt = time();
if ($_SESSION['user']['id']) 
{
mysqli_query($conn, "UPDATE users SET llog = ".$nowt." WHERE id = ".$_SESSION['user']['id']."") or die(mysqli_error());
}

/* if($data['llog'] - time() < 60)
{ online }
 */
?>