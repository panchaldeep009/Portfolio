<?php
require("common.php");
    ob_start();
session_start();
    if(empty($_SESSION['user']))
    {
        header("Location: login.php");
        die("Redirecting to login.php");
    }
	if(!empty($_SESSION['auser']))
    {
        header("Location: login.php");
        die("Redirecting to login.php");
    }

  if(isset($_GET['id']) && isset($_GET['img']) && isset($_GET['ty'])){
	$data = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * from post where id=".$_GET['id']));
	echo '<img src="data:'.$data[''.$_GET['ty'].''].';base64,'.$data[''.$_GET['img'].''].'">';	
  }
?>