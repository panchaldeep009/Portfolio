<?php
    ob_start();
session_start();
    require("common.php");
    $submitted_username = '';
    $error = '';
	$folnk ='';
	if(!empty($_SESSION['user']))
    {
        header("Location: index.php");
        die("Redirecting to index.php");
    }
    if(!empty($_POST))
    {	$un = $_POST["un"];
    	$pas = $_POST["pass"];
		$alogin_ok = false;
		$login_ok = false;
		if($un == null || $un == ""){
		$error = "<i class='fa fa-times-circle-o'></i> Enter Username or Email!";
		}
		else if($pas == null || $pas == ""){
		$error = "<i class='fa fa-times-circle-o'></i> Enter Password !";
		$submitted_username = $_POST['un'];
		}
		else{
        $login_ok = false;
        $alogin_ok = false;
		$query = "SELECT * FROM users WHERE uname = '".$_POST['un']."' or email = '".$_POST['un']."'";
        $row = mysqli_fetch_assoc(mysqli_query($conn, $query));
        if($row)
        {
		
            $check_password = hash('sha256', $_POST['pass'] . $row['salt']);
            for($round = 0; $round < 65536; $round++)
            {
                $check_password = hash('sha256', $check_password . $row['salt']);
            }
            
            if($check_password === $row['pass'])
            {
                $login_ok = true;
                $alogin_ok = false;
            }
			else
            { 
			$error = "<i class='fa fa-times-circle-o'></i> Login Failed , Password is not match.<br/><a class='text-red' href='fogpass.php?un=".$_POST['un']."'>Forgot Password ?</a>";
			$folnk = '?un='.$_POST['un'];
            $submitted_username = htmlentities($_POST['un'], ENT_QUOTES, 'UTF-8');
            }
        }
        else
        {  
		$login_ok = false;
		$query = "SELECT * FROM ausers WHERE uname = '".$_POST['un']."' or email = '".$_POST['un']."'";
        $row = mysqli_fetch_assoc(mysqli_query($conn, $query));
        if($row)
        {
		
            $check_password = hash('sha256', $_POST['pass'] . $row['salt']);
            for($round = 0; $round < 65536; $round++)
            {
                $check_password = hash('sha256', $check_password . $row['salt']);
            }
            
            if($check_password === $row['pass'])
            {
                $alogin_ok = true;
                $login_ok = false;
            }
			else
            { 
			$error = "<i class='fa fa-times-circle-o'></i> Login Failed , Password is not match<br/><a class='text-red' href='fogpass.php?un=".$_POST['un']."'>Forgot Password ?</a>";
			$folnk = '?un='.$_POST['un'];
            $submitted_username = $_POST['un'];
            }
        }
        else
        {  if (is_numeric($_POST['un'])){
			$error = "<i class='fa fa-times-circle-o'></i> Login Failed , Enrollment is wrong.";}
	       else if (filter_var($_POST['un'], FILTER_VALIDATE_EMAIL)){
			$error = "<i class='fa fa-times-circle-o'></i> Login Failed , Email is undefined.";}
	       else	{
			$error = "<i class='fa fa-times-circle-o'></i> Login Failed , Username is undefined.";}
            $submitted_username = $_POST['un'];
        }
		}
        if($login_ok)
        {
            unset($row['salt']);
            unset($row['pass']);
            

            $_SESSION['user'] = $row;
			if(isset($_GET['q'])){
            header("Location: ".$_GET['q']);
            die("Redirecting to: ".$_GET['q']);}
			else{
				if(isset($_GET['page'])){
					header("Location: index.php?page");
					die("Redirecting to index.php?page");
				}
				else{
					header("Location: index.php");
					die("Redirecting to index.php");
				}
			}
        }
		else if($alogin_ok)
        {
            unset($row['salt']);
            unset($row['pass']);
           
            $_SESSION['auser'] = $row;
            header("Location: admin/index.php");
            die("Redirecting to: admin/index.php");
        }
		}
		if(isset($error))
		{
			$unerror="";
			$passerror="";
			if($error == "<i class='fa fa-times-circle-o'></i> Login Failed , Password is not match." || $error == "<i class='fa fa-times-circle-o'></i> Enter Password !")
			{
				$unerror="";
				$passerror="has-error";
			} else {
				$unerror="has-error";
				$passerror="";
			}
		}
	}
?>
<!DOCTYPE html>

<html>


    <head>
        <meta http-equiv="Content-Type" content="text/html;charset=utf-8" />
        <title>Welcome to eFeed | login</title>
		<meta name="title" content="Login | eFeed">
		<meta name="description" content="Get Login into the eFeed. Required to use eFeed and also login with Facebook and Google+. It is highly secured 128bit encrypt password login.">
		<meta name="author" content="eFeed">
		<meta name="keywords" content="efeed,efeed.in,eFeed,efeeds,eFeeds,eFeed.in,social,site,login,signup,signin,create,new,account,panchal,deep,akash,panchaldeep009,panchaldeep009@gmail.com,feed,of,eduction,connection,for,you">
		<meta property="og:url" content="http://www.efeed.in/">
		<meta property="og:site_name" content="eFeed">
		<meta property="og:image" content="http://www.efeed.in/images/logo-large.png">
        <meta content='width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no' name='viewport'>
        <link href="met/css/bootstrap3.css" rel="stylesheet" type="text/css" />
        <link href="met/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
        <link href="met/css/ionicons.min.css" rel="stylesheet" type="text/css" />
        <link href="met/css/morris/morris.css" rel="stylesheet" type="text/css" />
        <link href="met/css/jvectormap/jquery-jvectormap-1.2.2.css" rel="stylesheet" type="text/css" />
        <link href="met/css/datepicker/datepicker3.css" rel="stylesheet" type="text/css" />
        <link href="met/css/daterangepicker/daterangepicker-bs3.css" rel="stylesheet" type="text/css" />
        <link href="met/css/bootstrap-wysihtml5/bootstrap3-wysihtml5.min.css" rel="stylesheet" type="text/css" />
        <link href="met/css/page_style6.css" rel="stylesheet" type="text/css" />
		<link rel="stylesheet" type="text/css" href="css/ns.css" />
		<link rel="shortcut icon" href="images/favicon.png"> 
		<script type='text/javascript' src='//code.jquery.com/jquery-1.9.1.js'></script>
		<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.8/jquery.min.js"></script>
    </head>
	
	
    <body class="skin-blue fixed">
        <header class="header">
            <a href="index.php" align="right" class="logo">
                <img src="images/logo.png" alt="LOGO"/>
            </a>
            <nav class="navbar navbar-static-top" role="navigation">
                <a href="#" class="navbar-btn sidebar-toggle">
					<div class="lomenbar">
                    <img  src="images/logo.png" alt="LOGO"/>
					</div>
                </a>
            </nav>
        </header>
        <div class="wrapper">
            <section class="content container">
                <div class="row">
					<section class="col-lg-2">
					</section>
                    <section class="col-lg-7">
						<h4 class="page-header">
							Welcome to eFeed
							<small>Feeds for eduction.</small>
						</h4>
						<div class="box box-solid">
							<div class="box-body">
								<p></p>
								<div class="row">
									<section class="col-lg-6" style="border-right: 2px solid #f4f4f4">
									<?php	if(isset($_GET['page'])){
												$ac = 'login.php?page';
											}
											else{
												$ac = 'login.php';
											} ?>
										<form class="form-1" method="post" name="login" action="<?php echo $ac; ?>">
											<div class="box box-solid">
												<div class="box-header" align="center">
													<h1 class="page-header"><?php if(isset($_GET['new_sup']) || isset($_GET['page'])){ echo 'Try to ';}?>Login
														<small>
															<strong class="text-danger" align="left"><?php echo $error;?></strong>
														</small>
													</h1>
												</div>
												<div class="box-body">
													<div class="input-group <?php echo $unerror;?>">
														<span class="input-group-addon"><i class="fa fa-user"></i></span>
														<input type="text" class="form-control" name="un" value="<?php echo $submitted_username; ?>" placeholder="Username or Email">
													</div><br/>
													<div class="input-group <?php echo $passerror;?>"><!-- has-error -->
														<span class="input-group-addon"><i class="fa fa-lock"></i></span>
														<input type="password" name="pass" class="form-control" placeholder="Password">
													</div>
												</div>
												<div class="box-footer">
													<button type="submit" class="btn btn-social btn-primary pull-right">
														<i class="fa fa-sign-in"></i> Login 
													</button>
													<br/><br/>
												</div>
											</div>
										</form>
									</section>
									<section class="col-lg-6">
									<div class="box box-solid box-body">
										<div class="page-header">
											<a href="register.php" class="btn btn-block btn-social btn-primary">
												<i class="fa fa-plus" align="left"></i>  Create new account
											</a>
										</div>
										<div class="page-header">
											<a href="fb_login.php" class="btn btn-block btn-social btn-facebook">
												<i class="fa fa-facebook"></i> Sign in with Facebook
											</a>
										</div>
										<div class="page-header">
											<a href="gp_login.php" class="btn btn-block btn-social btn-google-plus">
												<i class="fa fa-google-plus"></i> Sign in with Google
											</a>
										</div>
										<div class="">
											<a href="register.php?page" class="btn btn-block btn-social bg-orange">
												<i class="fa fa-star"></i> Create new Page
											</a>
										</div>
									</div>
									</section>
								</div>
							</div>
						</div>    						
                    </section>
				</div>
			</section>
			
        </div>
		<footer class="footer">
			<div align="center" style="border-top: 2px solid #f1f1f1">
			<a href="index.php"> Home </a> - <a href="eFeed/index.html"> About </a> - <a href="legal/terms/index.html"> Terms </a> - <a href="about/privacy/index.html"> Privacy </a> - <a href="help/index.html"> Help </a> - <a href="about/privacy/cookies/index.html"> Cookies </a><br/>
			 eFeed © 2015 (English (US))
			</div>
        </footer>

		
<!-- ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ -->

													<!-- Show clear -->

<!-- ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ -->


        <!-- jQuery 2.0.2 -->
        <script src="http://ajax.googleapis.com/ajax/libs/jquery/2.0.2/jquery.min.js"></script>
		<script type='text/javascript' src='met/js/jquery-1.10.1.js'></script>
        <script src="met/js/jquery-ui-1.10.3.min.js" type="text/javascript"></script>
        <script src="met/js/bootstrap.min.js" type="text/javascript"></script>
        <script src="//cdnjs.cloudflare.com/ajax/libs/raphael/2.1.0/raphael-min.js"></script>
        <script src="met/js/plugins/morris/morris.min.js" type="text/javascript"></script>
        <script src="met/js/plugins/sparkline/jquery.sparkline.min.js" type="text/javascript"></script>
        <script src="met/js/plugins/jvectormap/jquery-jvectormap-1.2.2.min.js" type="text/javascript"></script>
        <script src="met/js/plugins/jvectormap/jquery-jvectormap-world-mill-en.js" type="text/javascript"></script>
        <script src="met/js/plugins/jqueryKnob/jquery.knob.js" type="text/javascript"></script>
        <script src="met/js/plugins/daterangepicker/daterangepicker.js" type="text/javascript"></script>
        <script src="met/js/plugins/datepicker/bootstrap-datepicker.js" type="text/javascript"></script>
        <script src="met/js/plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.all.min.js" type="text/javascript"></script>
        <script src="met/js/plugins/iCheck/icheck.min.js" type="text/javascript"></script>
        <script src="met/js/AdminLTE/app.js" type="text/javascript"></script>
        <script src="met/js/AdminLTE/dashboard.js" type="text/javascript"></script>
        <script src="met/js/AdminLTE/demo.js" type="text/javascript"></script>
    </body>
</html>         