<?php

    require("common.php");
    ob_start();
session_start();
    if(empty($_SESSION['user']))
    {
		if(isset($_GET['page'])){
			header("Location: login.php?page");
			die("Redirecting to login.php?page");
		}
		else{
			header("Location: login.php?new_sup&q=chp.php");
			die("Redirecting to login.php?new_sup&q=chp.php");
		}
    }
	$pg = false;
	if(isset($_GET['page'])){ $pg = true; }
	$data = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM users WHERE id = ".$_SESSION['user']['id']));
    if($data['gen'] == 'page'){ 
		if(!isset($_GET['page'])){ header("Location: chp3.php?page");  }
	}
	$num = mysqli_num_rows(mysqli_query($conn, "SELECT * FROM aboutu WHERE pid = ".$_SESSION['user']['id']." and acid = 1"));
	if($num > 0){header("Location: index.php");}
	if(!empty($_POST)){
	$city = $_POST['clp'];
	$stcity = $_POST['stclp'];
	$scity = $_POST['syclp']."/".$_POST['smclp']."/".$_POST['sdclp'];
	$hwt = $_POST['htw'];
	$sthwt = $_POST['sthwt'];
	$abt = $_POST['abt'];
	$stabt = $_POST['stabt'];
	$pfs = $_POST['pfs'];
	$stpfs = $_POST['stpfs'];
	$stmn = $_POST['stmn'];
	$stem = $_POST['stem'];
	$stun = $_POST['stun'];
	$lug1 = $_POST['lug1'];
	$lug2 = $_POST['lug2'];
	$lug3 = $_POST['lug3'];
	$qut = $_POST['qut'];
	$stedu = $_POST['stedu'];
	$tyedu = $_POST['eduty'];
	$edu = $_POST['edu'];
	$wedu = $_POST['wedu'];
	$sedu = $_POST['syedu']."/".$_POST['smedu']."/".$_POST['sdedu'];
	$eedu = $_POST['eyedu']."/".$_POST['emedu']."/".$_POST['ededu'];
	$stwrk = $_POST['stwk'];
	$wrk = $_POST['wrk'];
	$pwrk = $_POST['pwrk'];
	$dwrk = $_POST['dwrk'];
	$swrk = $_POST['sywk']."/".$_POST['smwk']."/".$_POST['sdwk'];
	$ewrk = $_POST['eywk']."/".$_POST['emwk']."/".$_POST['edwk'];
	$relty = $_POST['relty'];
	$strl = $_POST['strl'];
	$relname = $_POST['rlname'];
	$srel = $_POST['ryear']."/".$_POST['rmonth']."/".$_POST['rday'];

	$num = mysqli_num_rows(mysqli_query($conn, "SELECT * FROM aboutu WHERE pid = ".$_SESSION['user']['id']." and acid = 1"));
	if($num > 0){header("Location: chp2.php");}
	else {
		mysqli_query($conn, "INSERT INTO `aboutu` (
		`id`,
		`pid`,
		`acid`,
		`stprop`,
		`wok`,
		`wwok`,
		`swok`,
		`ewok`,
		`dwok`,
		`idwok`,
		`idwwok`,
		`stwok`,
		`edu`,
		`tedu`,
		`wedu`,
		`sedu`,
		`eedu`,
		`idedu`,
		`idwedu`,
		`stedu`,
		`skil`,
		`idskil`,
		`stskil`,
		`city`,
		`scity`,
		`ecity`,
		`stecity`,
		`contcity`,
		`modcity`,
		`idcity`,
		`stcity`,
		`stemail`,
		`stmob`,
		`stbdate`,
		`stabout`,
		`lang1`,
		`stlang1`,
		`lang2`,
		`stlang2`,
		`lang3`,
		`stlang3`,
		`instin`,
		`stinstin`,
		`relship`,
		`strelship`,
		`namrel`,
		`idrelship`,
		`srelship`,
		`fmem`,
		`tyfmem`,
		`genfmem`,
		`idfmem`
		) VALUES (
		NULL,
		'".$_SESSION['user']['id']."',
		'1',
		'0',
		'".$wrk."',
		'".$pwrk."',
		'".$swrk."',
		'".$ewrk."',
		'".$dwrk."',
		'".$_POST['wrksl']."',
		'".$_POST['pwrksl']."',
		'".$stwrk."',
		'".$edu."',
		'".$tyedu."',
		'".$wedu."',
		'".$sedu."',
		'".$eedu."',
		'".$_POST['edusl']."',
		'".$_POST['wedusl']."',
		'".$stedu."',
		'".$pfs."',
		'".$_POST['pfssl']."',
		'".$stpfs."',
		'".$city."',
		'".$scity."',
		'0',
		'".$hwt."',
		'".$sthwt."', 
		'1', 
		'".$_POST['clpsl']."', 
		'".$stcity."',
		'".$stem."',
		'".$stmn."',
		'".$stun."',
		'".$stabt."',
		'".$lug1."',
		'0',
		'".$lug2."',
		'0',
		'".$lug3."',
		'0',
		'0',
		'0',
		'".$relty."',
		'".$strl."',
		'".$relname."',
		'".$_POST['']."',
		'".$srel."',
		'0',
		'0',
		'0',
		'0'
		)");
		mysqli_query($conn, "UPDATE `users` SET `stet` = '".$qut."', `about` = '".$abt."' WHERE `id` = ".$_SESSION['user']['id']);
		if(isset($_GET['page'])){
			header("Location: chp2.php?page");
		}
		else{
			header("Location: chp2.php");
		}
	}
	}
$data = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM users WHERE id = ".$_SESSION['user']['id']));
?>
<!DOCTYPE html>

<html>


    <head>
        <meta charset="UTF-8">
        <title>Complete Information | eFeed</title>
        <meta content='width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no' name='viewport'>
        <link href="met/css/bootstrap.css" rel="stylesheet" type="text/css" />
        <link href="met/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
        <link href="met/css/AdminLTE.css" rel="stylesheet" type="text/css" />
		<link rel="shortcut icon" href="images/favicon.png"> 
		<script type="text/javascript" src="js/jquery-1.11.2.min.js"></script>
		<script type="text/javascript" src="js/gen.js"></script>
    </head>
	
	
    <body class="skin-blue fixed">
        <header class="header">
            <a href="index.php" align="right" class="logo">
                <img src="images/logo.png" alt="LOGO"/>
            </a>
            <nav class="navbar navbar-static-top" role="navigation">
                <a href="#" class="navbar-btn sidebar-toggle">
					<div class="lomenbar">
                    <span class="sr-only">Toggle navigation</span>
                    <img  src="images/logo.png" alt="LOGO"/>
					</div>
                </a>
                   
                <div class="navbar-right">
                    <ul class="nav navbar-nav" >
						<li class="dropdown user user-menu">
							<a href="#" class="dropdown-toggle" data-toggle="dropdown">
								<i class="glyphicon glyphicon-user"></i>
									<span><?php echo htmlentities($data['uname'], ENT_QUOTES, 'UTF-8'); ?> <i class="caret"></i></span>
							</a>
							<ul class="dropdown-menu">
								<li class="user-header">
									<img src="<?php echo ($data['propt']); ?>" class="img-circle" alt="User Image" />
										<p>
											<?php echo $data['fname']." ".$data['lname'];?> - <?php echo $data['enroll'];?>
											<small><?php echo $data['email'];?></small>
										</p>
								</li>
								<li class="user-footer">
									<div class="pull-right">
										<a href="logout.php" class="btn btn-default btn-flat"><i class="fa fa-sign-out"></i> Logout</a>
									</div>
								</li>
							</ul>
						</li>
                    </ul>
                </div>
            </nav>
        </header>
        <div class="wrapper row-offcanvas row-offcanvas-left">

            <aside class="right-side">
				
                <section class="content-header">
                    <h1>
                      Fill Your Information
                        <small></small>
                    </h1>
                </section>

                <section class="content">
                    <div class="row">
						
                        <section class="col-lg-9">
						<?php	if(isset($_GET['page'])){
									$ac = 'chp3.php?page';
								}
								else{
									$ac = 'chp3.php';
								} ?>
							<form method="post" action="<?php echo $ac; ?>">
								<div class="row">
								<script>
									function setitonf(id,f,ans,url){
										document.getElementById(f).value = ans;
										$.get('src_s/'+url+'.php?ch='+id);
										document.getElementById(f+'sl').value = '-1';
										$("#"+f+"r").hide();
									}
									var ch = /^[0-9a-zA-Z ,.]+$/;
									var ch2 = /^[ ]+$/;
								</script>
									<?php if($pg){ ?>
									<div class="col-lg-6">
										<div class="box box-solid">
											<div class="box-header">
												<h3 class="box-title"> Location <small>(optional)</small> </h3>
											</div>
											<div class="box-body">
												<small>(ex : City, State, Country)</small>
												<div class="input-group">
													<span class="input-group-addon"><i class="fa fa-map-marker"></i></span>
													<input type="text" class="form-control" name="clp" id="clp" value="" placeholder="Enter Location">
													<input id="share1" type="hidden" value="0" name="stclp"/>
												</div>
												<div class="input-group-addon" id="clpr">
												</div>
												<input type="hidden" id="clpsl" name="clpsl" value="0"/>
												<script>
													$(document).ready(function(){
													$("#clpr").hide();
													$("#clp").blur(function(){setTimeout(function(){$("#clpr").hide();}, 3500);});
													$("#clp").keyup(function()
													{
													var search = $(this).val();var searchbox = search.trim();
													var dataString = 'searchword='+ searchbox;
													if(!searchbox.match(ch) || searchbox.match(ch2))
													{
													$("#clpr").hide();
													}
													else
													{
													$.ajax({
													type: "POST",
													url: "src_s/loc.php?f=clp",
													data: dataString,
													cache: false,
													success: function(html)
													{
													$("#clpr").html(html).show();
													}
													});
													}return false; 
													});
													});
												</script>
												<div class="input-group">
												<span class="input-group-addon">Since : </span>
													<select name="syclp" class="form-control" id="syear">
														<option value="no" disabled selected>Year</option>
													</select>
													<select name="smclp" class="form-control" id="smonth">
														<option value="no" disabled selected>Month</option>
														<option value="1">Jan</option>
														<option value="2">Feb</option>
														<option value="3">Mar</option>
														<option value="4">Apr</option>
														<option value="5">May</option>
														<option value="6">June</option>
														<option value="7">July</option>
														<option value="8">Aug</option>
														<option value="9">Sept</option>
														<option value="10">Oct</option>
														<option value="11">Nov</option>
														<option value="12">Dec</option>
													</select>
													<select name="sdclp" class="form-control" id="sday">
														<option value="no" disabled selected>Day</option>
														<option value="1">1</option>
														<option value="2">2</option>
														<option value="3">3</option>
														<option value="4">4</option>
														<option value="5">5</option>
														<option value="6">6</option>
														<option value="7">7</option>
														<option value="8">8</option>
														<option value="9">9</option>
														<option value="10">10</option>
														<option value="11">11</option>
														<option value="12">12</option>
														<option value="13">13</option>
														<option value="14">14</option>
														<option value="15">15</option>
														<option value="16">16</option>
														<option value="17">17</option>
														<option value="18">18</option>
														<option value="19">19</option>
														<option value="20">20</option>
														<option value="21">21</option>
														<option value="22">22</option>
														<option value="23">23</option>
														<option value="24">24</option>
														<option value="25">25</option>
														<option value="26">26</option>
														<option value="27">27</option>
														<option value="28">28</option>
													</select>
													<script>
													document.getElementById('sday').style.display = 'none';
													document.getElementById('smonth').style.display = 'none';
													var d = new Date(); var y = d.getFullYear();
													<?php 
													$bd = setssql($conn,"bdate","users","id",$_SESSION['user']['id'],0,0,0,0,0,0);
													$year = substr(strrchr($bd,'/'), 1);
													$month = substr(substr($bd, strlen(strchr($bd,'/',true))+1), 0, strpos( substr($bd, strlen(strchr($bd,'/',true))+1), '/'));
													$day = strchr($bd,'/',true);?>
													var a = <?php echo $year;?>;
													var dif = y-a;
													var i = 1;
													for(i = 1;i <= dif+1;i++)
													{
														document.getElementById('syear').innerHTML += '<option value="'+y+'">'+y+'</option>';
														y--;
													}
													document.getElementById('syear').onchange = function () {
														var a = document.getElementById('syear').value;
														if(a != 'no'){
														document.getElementById('smonth').style.display = 'block';
														var b = <?php echo $year;?>;
														if(a == b){
																var c = <?php echo $month;?>;
															} else {var c = 1;}
																var m = '<option value="no" disabled selected>Month</option>';
																switch (c-1) {
																	case 0:
																		m += '<option value="1">Jan</option>';
																	case 1:
																		m += '<option value="2">Feb</option>';
																	case 2:
																		m += '<option value="3">Mar</option>';
																	case 3:
																		m += '<option value="4">Apr</option>';
																	case 4:
																		m += '<option value="5">May</option>';
																	case 5:
																		m += '<option value="6">June</option>';
																	case 6:
																		m += '<option value="7">July</option>';
																	case 7:
																		m += '<option value="8">Aug</option>';
																	case 8:
																		m += '<option value="9">Sept</option>';
																	case 9:
																		m += '<option value="10">Oct</option>';
																	case 10:
																		m += '<option value="11">Nov</option>';
																	case 11:
																		m += '<option value="12>Dec</option>';
																	case 12:
																		m += '<option value="12>Dec</option>';
																}
																document.getElementById('smonth').innerHTML = m;
														}
													}
													document.getElementById('smonth').onchange = function () {
														var m = document.getElementById('smonth').value;
														var a = <?php echo $month;?>;
														if(m != 'no'){
															document.getElementById('sday').style.display = 'block';
															if(a != m){
																if(m == '2'){
																	if(b%4 == 0){
																		document.getElementById('sday').innerHTML += '<option value="29">29</option>';
																	}
																}
																else if(m == '4' || m == '6' || m == '9' || m == '11'){document.getElementById('sday').innerHTML += '<option value="29">29</option><option value="30">30</option>';}
																else{document.getElementById('sday').innerHTML += '<option value="29">29</option><option value="30">30</option><option value="31">31</option>';}
															} else {
																if(m == '2'){
																	if(b%4 == 0){
																		var ld = 29;
																	} else { var ld = 28; }
																}
																else if(m == '4' || m == '6' || m == '9' || m == '11'){var ld = 30;}
																else{var ld = 31;}
																var i = 1;
																var d = <?php echo $day;?>;
																od = '<option value="no" disabled selected>Day</option>';
																for(i = d;i <= ld;i++){ 
																	od += '<option value="'+i+'">'+i+'</option>';
																}
																document.getElementById('sday').innerHTML = od;
															}
														}
													}
												</script>
												</div>
											</div>
											<div class="box-body" style="display:none;">
												<div class="input-group" style="display:none;">
													<span class="input-group-addon"><i class="fa fa-home"></i></span>
													<input type="hidden" class="form-control" name="htw" id="htw" value="" placeholder="Enter Location">
													<input id="share1" name="sthtw" type="hidden" value="0"/>
												</div>
												<div id="htwr"></div>
												<input type="hidden" id="htwsl" value="0"/>
											</div>
											<div class="box-header">
												<?php if($pg){ ?>
												<h3 class="box-title">About Page</h3>
												<?php } else { ?>
												<h3 class="box-title">About You</h3>
												<?php } ?>
											</div>
											<div class="box-body">
												<div class="input-group">
													<span class="input-group-addon"><i class="fa fa-user"></i></span>
													<textarea class="form-control" name="abt" id="abt" value="<?php echo $data['about'];?>" placeholder="Enter Text about you."></textarea>
													<input name="stabt" type="hidden" value="0"/>
												</div>
											</div>
											<div class="box-body" style="display:none;">
												<div class="input-group">
													<span class="input-group-addon"><i class="fa fa-suitcase"></i></span>
													<input type="hidden" class="form-control" name="pfs" id="pfs" value="" placeholder="Enter Your Skills">
													<input type="hidden" id="stpfs" value="0"/>
												</div>
												<div class="input-group-addon" id="pfsr"></div>
												<input type="hidden" id="pfssl" name="pfssl" value="0"/>
											</div>
											<div class="box-header">
												<h3 class="box-title">Contact Info</h3>
											</div>
											<div class="box-body">
												<div class="input-group">
												<span class="input-group-addon">
													<div class="pull-left">
														<i class="fa fa-phone"></i>    <b>  Contact  </b>  : <?php echo $data['mobn'];?>
													</div><br/><br/>
													<select align="right" name="stmn" class="fa pull-right"> 
														<option value="no" disabled >  Share with  </option>
														<option value="0" Selected>  Public</option>
														<option value="1">  Group</option>
														<option value="2">  Me Only</option>
													</select><br/><br/><br/>
													<div class="pull-left">
														<i class="fa fa-envelope"></i>  <b> Email </b>  : <?php echo $data['email'];?>
													</div><br/><br/>
													<select align="right" name="stem" class="fa pull-right"> 
														<option value="no" disabled >  Share with  </option>
														<option value="0" Selected>  Public</option>
														<option value="1">  Group</option>
														<option value="2">  Me Only</option>
													</select><br/><br/><br/>
													<div class="pull-left">
														<i class="fa fa-circle"></i>  <b> eFeed </b>  : /<?php echo $data['uname'];?>
													</div><br/><br/>
													<select name="stun" class="fa pull-right"> 
														<option value="no" disabled >  Share with  </option>
														<option value="0" Selected>  Public</option>
														<option value="1">  Group</option>
														<option value="2">  Me Only</option>
													</select>
												</span>
												</div>
											</div>
											<div class="box-body" style="display:none;"><span class="input-group-addon"><h4 class="pull-left" id="l1g">1). ____________</h4><button id="rel1g" onclick="removelug(1)" type="button" class="btn pull-right">&times;</button></span>
												<input type="hidden" name="lug1" id="lug1" value="English">
												<input type="hidden" name="lug2" id="lug2" value="">
												<input type="hidden" name="lug3" id="lug3" value="">
											</div>
											<div class="box-header">
												<h3 class="box-title">Quotes</h3>
											</div>
											<div class="box-body">
												<div class="input-group">
													<span class="input-group-addon"><i class="fa fa-quote-left"></i></span>
													<input type="text" class="form-control" name="qut" id="qut" value="<?php echo $data['stet'];?>" placeholder="I am on eFeed :)">
													<span class="input-group-addon"><i class="fa fa-quote-right"></i></span>
													<button class="btn btn-default btn-flat" id="equt" type="button" onclick="onclkune('qut')">😆</button>
												</div>
												<div id="contqut"></div>
											</div>
										</div>
									</div>
									<?php } else { ?>
									<div class="col-lg-6">
										<div class="box box-solid">
											<div class="box-header">
												<h3 class="box-title">Current living Place </h3>
											</div>
											<div class="box-body">
												<small>(ex : City, State, Country)</small>
												<div class="input-group">
													<span class="input-group-addon"><i class="fa fa-map-marker"></i></span>
													<input type="text" class="form-control" name="clp" id="clp" value="" placeholder="Enter Location">
													<select id="share1" name="stclp" class="fa">
														<option value="no" disabled > Share with  </option>
														<option value="0" Selected>  Public</option>
														<option value="1">  Group</option>
														<option value="2">  Me Only</option>
													</select>
												</div>
												<div class="input-group-addon" id="clpr">
												</div>
												<input type="hidden" id="clpsl" name="clpsl" value="0"/>
												<script>
													$(document).ready(function(){
													$("#clpr").hide();
													$("#clp").blur(function(){setTimeout(function(){$("#clpr").hide();}, 3500);});
													$("#clp").keyup(function()
													{
													var search = $(this).val();var searchbox = search.trim();
													var dataString = 'searchword='+ searchbox;
													if(!searchbox.match(ch) || searchbox.match(ch2))
													{
													$("#clpr").hide();
													}
													else
													{
													$.ajax({
													type: "POST",
													url: "src_s/loc.php?f=clp",
													data: dataString,
													cache: false,
													success: function(html)
													{
													$("#clpr").html(html).show();
													}
													});
													}return false; 
													});
													});
												</script>
												<div class="input-group">
												<span class="input-group-addon">From : </span>
													<select name="syclp" class="form-control" id="syear">
														<option value="no" disabled selected>Year</option>
													</select>
													<select name="smclp" class="form-control" id="smonth">
														<option value="no" disabled selected>Month</option>
														<option value="1">Jan</option>
														<option value="2">Feb</option>
														<option value="3">Mar</option>
														<option value="4">Apr</option>
														<option value="5">May</option>
														<option value="6">June</option>
														<option value="7">July</option>
														<option value="8">Aug</option>
														<option value="9">Sept</option>
														<option value="10">Oct</option>
														<option value="11">Nov</option>
														<option value="12">Dec</option>
													</select>
													<select name="sdclp" class="form-control" id="sday">
														<option value="no" disabled selected>Day</option>
														<option value="1">1</option>
														<option value="2">2</option>
														<option value="3">3</option>
														<option value="4">4</option>
														<option value="5">5</option>
														<option value="6">6</option>
														<option value="7">7</option>
														<option value="8">8</option>
														<option value="9">9</option>
														<option value="10">10</option>
														<option value="11">11</option>
														<option value="12">12</option>
														<option value="13">13</option>
														<option value="14">14</option>
														<option value="15">15</option>
														<option value="16">16</option>
														<option value="17">17</option>
														<option value="18">18</option>
														<option value="19">19</option>
														<option value="20">20</option>
														<option value="21">21</option>
														<option value="22">22</option>
														<option value="23">23</option>
														<option value="24">24</option>
														<option value="25">25</option>
														<option value="26">26</option>
														<option value="27">27</option>
														<option value="28">28</option>
													</select>
													<script>
													document.getElementById('sday').style.display = 'none';
													document.getElementById('smonth').style.display = 'none';
													var d = new Date(); var y = d.getFullYear();
													<?php 
													$bd = setssql($conn,"bdate","users","id",$_SESSION['user']['id'],0,0,0,0,0,0);
													$year = substr(strrchr($bd,'/'), 1);
													$month = substr(substr($bd, strlen(strchr($bd,'/',true))+1), 0, strpos( substr($bd, strlen(strchr($bd,'/',true))+1), '/'));
													$day = strchr($bd,'/',true);?>
													var a = <?php echo $year;?>;
													var dif = y-a;
													var i = 1;
													for(i = 1;i <= dif+1;i++)
													{
														document.getElementById('syear').innerHTML += '<option value="'+y+'">'+y+'</option>';
														y--;
													}
													document.getElementById('syear').onchange = function () {
														var a = document.getElementById('syear').value;
														if(a != 'no'){
														document.getElementById('smonth').style.display = 'block';
														var b = <?php echo $year;?>;
														if(a == b){
																var c = <?php echo $month;?>;
															} else {var c = 1;}
																var m = '<option value="no" disabled selected>Month</option>';
																switch (c-1) {
																	case 0:
																		m += '<option value="1">Jan</option>';
																	case 1:
																		m += '<option value="2">Feb</option>';
																	case 2:
																		m += '<option value="3">Mar</option>';
																	case 3:
																		m += '<option value="4">Apr</option>';
																	case 4:
																		m += '<option value="5">May</option>';
																	case 5:
																		m += '<option value="6">June</option>';
																	case 6:
																		m += '<option value="7">July</option>';
																	case 7:
																		m += '<option value="8">Aug</option>';
																	case 8:
																		m += '<option value="9">Sept</option>';
																	case 9:
																		m += '<option value="10">Oct</option>';
																	case 10:
																		m += '<option value="11">Nov</option>';
																	case 11:
																		m += '<option value="12>Dec</option>';
																	case 12:
																		m += '<option value="12>Dec</option>';
																}
																document.getElementById('smonth').innerHTML = m;
														}
													}
													document.getElementById('smonth').onchange = function () {
														var m = document.getElementById('smonth').value;
														var a = <?php echo $month;?>;
														if(m != 'no'){
															document.getElementById('sday').style.display = 'block';
															if(a != m){
																if(m == '2'){
																	if(b%4 == 0){
																		document.getElementById('sday').innerHTML += '<option value="29">29</option>';
																	}
																}
																else if(m == '4' || m == '6' || m == '9' || m == '11'){document.getElementById('sday').innerHTML += '<option value="29">29</option><option value="30">30</option>';}
																else{document.getElementById('sday').innerHTML += '<option value="29">29</option><option value="30">30</option><option value="31">31</option>';}
															} else {
																if(m == '2'){
																	if(b%4 == 0){
																		var ld = 29;
																	} else { var ld = 28; }
																}
																else if(m == '4' || m == '6' || m == '9' || m == '11'){var ld = 30;}
																else{var ld = 31;}
																var i = 1;
																var d = <?php echo $day;?>;
																od = '<option value="no" disabled selected>Day</option>';
																for(i = d;i <= ld;i++){ 
																	od += '<option value="'+i+'">'+i+'</option>';
																}
																document.getElementById('sday').innerHTML = od;
															}
														}
													}
												</script>
												</div>
											</div>
											<div class="box-header">
												<h3 class="box-title">Hometown / Birth Place</h3>
											</div>
											<div class="box-body">
												<small>(ex : City, State, Country)</small>
												<div class="input-group">
													<span class="input-group-addon"><i class="fa fa-home"></i></span>
													<input type="text" class="form-control" name="htw" id="htw" value="" placeholder="Enter Location">
													<select id="share1" name="sthtw" class="fa">
														<option value="no" disabled >  Share with  </option>
														<option value="0" Selected>  Public</option>
														<option value="1">  Group</option>
														<option value="2">  Me Only</option>
													</select>
												</div>
												<div class="input-group-addon" id="htwr">
												</div>
												<input type="hidden" id="htwsl" value="0"/>
												<script>
													$(document).ready(function(){
													$("#htwr").hide();
													$("#htw").blur(function(){setTimeout(function(){$("#htwr").hide();}, 3500);});
													$("#htw").keyup(function()
													{
													var search = $(this).val();var searchbox = search.trim();
													var dataString = 'searchword='+ searchbox;
													if(!searchbox.match(ch) || searchbox.match(ch2))
													{
													$("#htwr").hide();
													}
													else
													{
													$.ajax({
													type: "POST",
													url: "src_s/loc.php?f=htw",
													data: dataString,
													cache: false,
													success: function(html)
													{
													$("#htwr").html(html).show();
													}
													});
													}return false; 
													});
													});
												</script>
											</div>
											<div class="box-header">
												<h3 class="box-title">About You</h3>
											</div>
											<div class="box-body">
												<div class="input-group">
													<span class="input-group-addon"><i class="fa fa-user"></i></span>
													<input type="text" class="form-control" name="abt" id="abt" value="<?php echo $data['about'];?>" placeholder="Enter Text about you.">
													<select name="stabt" class="fa">
														<option value="no" disabled >  Share with  </option>
														<option value="0" Selected>  Public</option>
														<option value="1">  Group</option>
														<option value="2">  Me Only</option>
													</select>
												</div>
											</div>
											<div class="box-header">
												<h3 class="box-title">Professional Skills</h3>
											</div>
											<div class="box-body">
												<small>(ex : Singing, Cricket)</small>
												<div class="input-group">
													<span class="input-group-addon"><i class="fa fa-suitcase"></i></span>
													<input type="text" class="form-control" name="pfs" id="pfs" value="" placeholder="Enter Your Skills">
													<select name="stpfs" class="fa">
														<option value="no" disabled >  Share with  </option>
														<option value="0" Selected>  Public</option>
														<option value="1">  Group</option>
														<option value="2">  Me Only</option>
													</select>
												</div>
												<div class="input-group-addon" id="pfsr">
												</div>
												<input type="hidden" id="pfssl" name="pfssl" value="0"/>
												<script>
													$(document).ready(function(){
													$("#pfsr").hide();
													$("#pfs").blur(function(){setTimeout(function(){$("#pfsr").hide();}, 3500);});
													$("#pfs").keyup(function()
													{
													var search = $(this).val();var searchbox = search.trim();
													var dataString = 'searchword='+ searchbox;
													if(!searchbox.match(ch) || searchbox.match(ch2))
													{
													$("#pfsr").hide();
													}
													else
													{
													$.ajax({
													type: "POST",
													url: "src_s/pfs.php?f=pfs",
													data: dataString,
													cache: false,
													success: function(html)
													{
													$("#pfsr").html(html).show();
													}
													});
													}return false; 
													});
													});
												</script>
											</div>
											<div class="box-header">
												<h3 class="box-title">Contact Info</h3>
											</div>
											<div class="box-body">
												<div class="input-group">
												<span class="input-group-addon">
													<div class="pull-left">
														<i class="fa fa-phone"></i>    <b>  Mobile  </b>  : <?php echo $data['mobn'];?>
													</div><br/><br/>
													<select align="right" name="stmn" class="fa pull-right"> 
														<option value="no" disabled >  Share with  </option>
														<option value="0" Selected>  Public</option>
														<option value="1">  Group</option>
														<option value="2">  Me Only</option>
													</select><br/><br/><br/>
													<div class="pull-left">
														<i class="fa fa-envelope"></i>  <b> Email </b>  : <?php echo $data['email'];?>
													</div><br/><br/>
													<select align="right" name="stem" class="fa pull-right"> 
														<option value="no" disabled >  Share with  </option>
														<option value="0" Selected>  Public</option>
														<option value="1">  Group</option>
														<option value="2">  Me Only</option>
													</select><br/><br/><br/>
													<div class="pull-left">
														<i class="fa fa-circle"></i>  <b> eFeed </b>  : /<?php echo $data['uname'];?>
													</div><br/><br/>
													<select name="stun" class="fa pull-right"> 
														<option value="no" disabled >  Share with  </option>
														<option value="0" Selected>  Public</option>
														<option value="1">  Group</option>
														<option value="2">  Me Only</option>
													</select>
												</span>
												</div>
											</div>
											<div class="box-header">
												<h3 class="box-title">Languages</h3>
											</div>
											<div class="box-body">
											<small> Select 3 Languages which you are use to communicate.</small>
												<div class="input-group">
													<span class="input-group-addon">Select : </span>
													<select class="form-control" id="lugset">
														<option value="no" disabled selected>Select Lunguage</option>
														<option value="no" disabled ></option>
														<option value="no" disabled >--- Most Selected ---</option>
														<option value="no" disabled ></option>
														<option id="English" value="English">English  - English</option>
														<option id="Hindi" value="Hindi">Hindi  - हिन्दी</option>
														<option id="Gujarati" value="Gujarati">Gujarati  - ગુજરાતી</option>
														<option value="no" disabled ></option>
														<option value="no" disabled >---- All ----</option>
														<option value="no" disabled ></option>
														<option id="Abaza" value="Abaza">Abaza - Aбаза бызшва</option>
														<option id="Abenaki" value="Abenaki">Abenaki †  - Alnôba, Wôbanakiôdwawôgan</option>
														<option id="Abkhaz" value="Abkhaz">Abkhaz  - Aҧсуа бызшәа, Aҧсшәа</option>
														<option id="Adangme" value="Adangme">Adangme  - Adangbɛ</option>
														<option id="Adangbe" value="Adangbe">Adangbe  - Adangbe</option>
														<option id="Adyghe" value="Adyghe">Adyghe  - Aдыгэбзэ</option>
														<option id="Afar" value="Afar">Afar  - ʿAfár af</option>
														<option id="Afrikaans" value="Afrikaans">Afrikaans  – Afrikaans, "kitchen Dutch"</option>
														<option id="Ainu" value="Ainu">Ainu  - アイヌ イタク, Aynu Itak</option>
														<option id="Aji%C3%AB" value="Ajië">Ajië  - A’jie, Ajië, Houailou, Wai, Wailu</option>
														<option id="Akan" value="Akan">Akan  - Akan, Fante, Twi</option>
														<option id="Albanian" value="Albanian">Albanian  - Shqip, Shqiptar</option>
														<option id="Aleut" value="Aleut">Aleut  - Unangam Tunuu, Унáҥам Тунý</option>
														<option id="Amdang" value="Amdang">Amdang   - Sìmí Amdangtí</option>
														<option id="Amharic" value="Amharic">Amharic  - ኣማርኛ</option>
														<option id="Egyptian" value="Egyptian">Ancient Egyptian †</option>
														<option id="Angika" value="Angika">Angika  - अंगिका</option>
														<option id="Apache" value="Apache">Apache  - Ndéé</option>
														<option id="Arabic" value="Arabic">Arabic  - اللغة العربية</option>
														<option id="Aragonese" value="Aragonese">Aragonese  - l'Aragonés</option>
														<option id="Aramaic" value="Aramaic">Aramaic  - ܐܪܡܝܐ</option>
														<option id="Arapaho" value="Arapaho">Arapaho  - Hinono'eitiitt</option>
														<option id="Armenian" value="Armenian">Armenian  - Հայերեն</option>
														<option id="Eastern_Armenian" value="Eastern Armenian">Armenian (Eastern)  - Արևելահայերեն</option>
														<option id="Western_Armenian" value="Western Armenian">Armenian (Western)  - Արեւմտահայերէն</option>
														<option id="Arrernte" value="Arrernte">Arrernte  - Arrernte Angkentye</option>
														<option id="Assamese" value="Assamese">Assamese  - অসমীয়া</option>
														<option id="Asturian" value="Asturian">Asturian  - Asturianu</option>
														<option id="Avar" value="Avar">Avar  - MагIарул MацI</option>
														<option id="Avestan" value="Avestan">Avestan  - 𐬆𐬬𐬈𐬯𐬙𐬆𐬥</option>
														<option id="Aymara" value="Aymara">Aymara  - Aymar Aru</option>
														<option id="Azerbaijani" value="Azerbaijani">Azerbaijani  - Azərbaycanca, آذربایجان دیلی</option>
														<option id="Baga" value="Baga">Baga † - Barka</option>
														<option id="Bai" value="Bai">Bai  - 白语</option>
														<option id="Balinese" value="Balinese">Balinese  - <span style="font-family:'Aksara Bali';">ᬩᬲᬩᬮᬶ</span></option>
														<option id="Balti" value="Balti">Balti  - སྦལ་ཏིའི་སྐད་, بلتی</option>
														<option id="Bambara" value="Bambara">Bambara  - Bamanankan</option>
														<option id="Bantu_s" value="Bantu s">Bantu † - Narrow Bantu</option>
														<option id="Basa-Gumna" value="Basa-Gumna">Basa-Gumna † - Basa-Kaduna, Basa Kuta</option>
														<option id="Bashkir" value="Bashkir">Bashkir  - башҡорт Теле, Başqort Tele</option>
														<option id="Basque" value="Basque">Basque  - Euskara</option>
														<option id="Bassa" value="Bassa">Bassa  - ɓasaá</option>
														<option id="Batak_s" value="Batak s">Batak </option>
														<option id="Belarusian" value="Belarusian">Belarusian  - Беларуская</option>
														<option id="Bemba" value="Bemba">Bemba  - iciBemba</option>
														<option id="Bengali" value="Bengali">Bengali  - বাংলা</option>
														<option id="Berber_s" value="Berber s">Berber  - Tamaziɣt, Tamazight, or ⵜⴰⵎⴰⵣⵉⵖⵜ</option>
														<option id="Berta" value="Berta">Berta  - Gebeto or Wetawit</option>
														<option id="Bhojpuri" value="Bhojpuri">Bhojpuri  - भोजपुरी, بھوجپوري</option>
														<option id="Bislama" value="Bislama">Bislama  - Bislama</option>
														<option id="Blackfoot" value="Blackfoot">Blackfoot  - ᑯᖾᖹ, ᓱᖽᐧᖿ</option>
														<option id="Bodo" value="Bodo">Bodo  - बड़ो</option>
														<option id="Bosnian" value="Bosnian">Bosnian  - Босански, Bosanski</option>
														<option id="Braille" value="Braille">Braille  - ⠃⠗⠁⠊⠇⠑</option>
														<option id="Breton" value="Breton">Breton  – Ar Brezhoneg</option>
														<option id="Buginese" value="Buginese">Buginese  - ᨅᨔ ᨕᨘᨁᨗ</option>
														<option id="Buhid" value="Buhid">Buhid  - <span style="font-family:'Code2000';">ᝊᝓᝑᝒᝇ</span></option>
														<option id="Bulgarian" value="Bulgarian">Bulgarian  - български език</option>
														<option id="Burmese" value="Burmese">Burmese  - မြန်မာစာ or မြန်မာစကား</option>
														<option id="Cahuilla" value="Cahuilla">Cahuilla  - Ivia</option>
														<option id="Cantonese" value="Cantonese">Cantonese  - 廣東話</option>
														<option id="Carrier" value="Carrier">Carrier  - ᑐᑊᘁᗕᑋᗸ</option>
														<option id="Catalan" value="Catalan">Catalan  - Català</option>
														<option id="Cayuga" value="Cayuga">Cayuga  - Gayogo̱hó:nǫ’</option>
														<option id="Cebuano" value="Cebuano">Cebuano  - Bisaya, Sinugboanon</option>
														<option id="Chamorro" value="Chamorro">Chamorro  - Chamoru, Fino'Chamorro</option>
														<option id="Chechen" value="Chechen">Chechen  - Нохчийн Mотт</option>
														<option id="Cherokee" value="Cherokee">Cherokee  – ᏣᎳᎩ, ᏣᎳᎩ ᎦᏬᏂᎯᏍᏗ</option>
														<option id="Chewa" value="Chewa">Chewa  - Nyanja</option>
														<option id="Cheyenne" value="Cheyenne">Cheyenne  - Tsėhesenėstsestotse, Tsisinstsistots</option>
														<option id="Chhattisgarhi" value="Chhattisgarhi">Chhattisgarhi  - छत्तीसगढ़ी</option>
														<option id="Chickasaw" value="Chickasaw">Chickasaw  - Chikasha</option>
														<option id="Chinese" value="Chinese">Chinese  - 汉语, 漢語, 华语, 華語, or 中文</option>
														<option id="Classical_Chinese" value="Classical Chinese">Chinese (Classical)  - 文言</option>
														<option id="Chipewyan" value="Chipewyan">Chipewyan  - ᑌᓀᓲᒢᕄᓀ, Dene Suline, Dëne Sųłiné</option>
														<option id="Choctaw" value="Choctaw">Choctaw  - Chahta', Chahta Anumpa</option>
														<option id="Chuvash" value="Chuvash">Chuvash  - Чӑвашла, Çăvaşla</option>
														<option id="Cimbrian" value="Cimbrian">Cimbrian  - Zimbrisch</option>
														<option id="Comanche" value="Comanche">Comanche  - Nʉmʉ Tekwapʉ</option>
														<option id="Coptic" value="Coptic">Coptic  - <span style="font-family:'MPH 2B Damase';">ⲘⲉⲧⲢⲉⲙ̀ⲛⲭⲏⲙⲓ</span></option>
														<option id="Cornish" value="Cornish">Cornish  – Kernewek, Kernowek</option>
														<option id="Corsican" value="Corsican">Corsican  - Corsu</option>
														<option id="Cree" value="Cree">Cree  - ᓀᐦᐃᔭᐍᐏᐣ</option>
														<option id="Croatian" value="Croatian">Croatian  - Hrvatski</option>
														<option id="Cupe%C3%B1o" value="Cupeño">Cupeño † - Kupangaxwicham Pe'memelki</option>
														<option id="Czech" value="Czech">Czech  - Český Jazyk, Čeština</option>
														<option id="Dakhini" value="Dakhini">Dakhini  - دکنی</option>
														<option id="Dakota" value="Dakota">Dakota  - Dakȟótiyapi</option>
														<option id="Dalecarlian" value="Dalecarlian">Dalecarlian  - Dalmål</option>
														<option id="Danish" value="Danish">Danish  - Dansk</option>
														<option id="Dargwa" value="Dargwa">Dargwa  - Дарган Mез</option>
														<option id="Dari_Persian" value="Dari Persian" >Dari  - فارسی, دری, دريلو, or Yazdi</option>
														<option id="Dhivehi" value="Dhivehi">Dhivehi  - ދިވެހި</option>
														<option id="Drehu" value="Drehu">Drehu  - Dehu, Lifou, Lifu, Qene Drehu</option>
														<option id="Dungan" value="Dungan">Dungan  - 回族语言, Xуэйзў йүян</option>
														<option id="Dutch" value="Dutch">Dutch  - Nederlands</option>
														<option id="Dzongkha" value="Dzongkha">Dzongkha  - རྫོང་ཁ་</option>
														<option id="Egyptian_Arabic" value="Egyptian Arabic">Egyptian Arabic † - اللغة المصرية العامية</option>
														<option id="Erzya" value="Erzya">Erzya  - Эрзянь Kель</option>
														<option id="Esperanto" value="Esperanto">Esperanto  - Esperanto</option>
														<option id="Estonian" value="Estonian">Estonian  - Eesti</option>
														<option id="Evenki" value="Evenki">Evenki  - Эвэды̄ турэ̄н</option>
														<option id="Ewe" value="Ewe">Ewe  - Èʋe, Èʋegbe</option>
														<option id="Eyak" value="Eyak">Eyak  - I•ya•q</option>
														<option id="Faroese" value="Faroese">Faroese  - Føroyskt</option>
														<option id="Fijian" value="Fijian">Fijian  – Na vosa vaka-Viti, Vakaviti</option>
														<option id="Fiji_Hindi" value="Fiji Hindi">Fiji Hindi  - फिजी बात or Fiji Baat</option>
														<option id="Filipino" value="Filipino">Filipino  - Wikang Filipino</option>
														<option id="Finnish" value="Finnish">Finnish  - Suomi</option>
														<option id="Fon" value="Fon">Fon  - Fon gbè, Fɔngbè</option>
														<option id="French" value="French">French  - Français</option>
														<option id="North_Frisian" value="North Frisian">Frisian (North)  - Noordfreesk</option>
														<option id="Saterland_Frisian" value="Saterland Frisian">Frisian (Saterland)  - Seeltersk</option>
														<option id="West_Frisian" value="West Frisian">Frisian (West)  - Frysk</option>
														<option id="Friulian" value="Friulian">Friulian  - Furlan</option>
														<option id="Fula" value="Fula">Fula  - Fulani, Fulfulde, Pulaar, Pular'Fulaare</option>
														<option id="Fur_s" value="Fur s">Fur  - For</option>
														<option id="Ga" value="Ga">Ga  - Gã</option>
														<option id="Galician" value="Galician">Galician  - Galego</option>
														<option id="Gan" value="Gan">Gan  - 赣语, 贛語</option>
														<option id="Ge%27ez" value="Ge'ez">Ge'ez  - ግዕዝ</option>
														<option id="Georgian" value="Georgian">Georgian  - ქართული</option>
														<option id="German" value="German">German  - Deutsch</option>
														<option id="Gikuyu" value="Gikuyu">Gikuyu  - Gĩkũyũ</option>
														<option id="Gilbertese" value="Gilbertese">Gilbertese  – Taetae ni Kiribati</option>
														<option id="Godoberi" value="Godoberi">Godoberi  - ГъибдилӀи Mицци, Ɣibdiƛi Micci</option>
														<option id="Gothic" value="Gothic">Gothic † - 𐌲𐍉𐍄𐌷𐌹𐌺</option>
														<option id="Greek" value="Greek">Greek  - Ελληνικά</option>
														<option id="Greenlandic" value="Greenlandic">Greenlandic  - Kalaallisut</option>
														<option id="Guaran%C3%AD" value="Guaraní">Guaraní  - Avañe'ẽ or Javy ju</option>
														<option id="Gumuz" value="Gumuz">Gumuz  - Bega</option>
														<option id="Gurung" value="Gurung">Gurung  - तमु क्यी</option>
														<option id="Gwich%27in" value="Gwich'in">Gwich'in  - Gwich'in</option>
														<option id="Haida" value="Haida">Haida  - Xaat Kíl</option>
														<option id="Hainanese" value="Hainanese">Hainanese  - 海南話</option>
														<option id="Haitian_Creole" value="Haitian Creole">Haitian Creole  – Kreyòl Ayisyen</option>
														<option id="Hakka" value="Hakka">Hakka  - 客家話, 客家话</option>
														<option id="Harari" value="Harari">Harari  - ሃራሪ</option>
														<option id="Hausa" value="Hausa">Hausa  - حَوْسَ</option>
														<option id="Hawaiian" value="Hawaiian">Hawaiian  - ʻŌlelo Hawaiʻi</option>
														<option id="Hebrew" value="Hebrew">Hebrew  - עברית</option>
														<option id="Herero" value="Herero">Herero  - Otjiherero</option>
														<option id="Himba" value="Himba">Himba  - Omuhimba, Simba</option>
														<option id="Hindustani" value="Hindustani">Hindustani  - ہندوستانی, हिन्दुस्तानी</option>
														<option id="Hiri_Motu" value="Hiri Motu">Hiri Motu  - Hiri Motu</option>
														<option id="Hmong" value="Hmong">Hmong  - lol Hmongb, lus Hmoob, lug Moob</option>
														<option id="Hopi" value="Hopi">Hopi  - Hopilàvayi or Hopílavayi</option>
														<option id="Hungarian" value="Hungarian">Hungarian  - Magyar</option>
														<option id="Icelandic" value="Icelandic">Icelandic  - Íslenska</option>
														<option id="Ido" value="Ido">Ido  - Ido</option>
														<option id="Igbo" value="Igbo">Igbo  - Asụsụ Igbo</option>
														<option id="Ik" value="Ik">Ik  - Icetot</option>
														<option id="Ilocano" value="Ilocano">Ilocano  - Iloko</option>
														<option id="Indonesian" value="Indonesian">Indonesian  - Bahasa Indonesia</option>
														<option id="Ingush" value="Ingush">Ingush  - ГӀалгӀай мотт</option>
														<option id="Interlingua" value="Interlingua">Interlingua  - Interlingua</option>
														<option id="Inuktitut" value="Inuktitut">Inuktitut  – ᐃᓄᒃᑎᑐᑦ</option>
														<option id="Inupiat" value="Inupiat">Inupiat  - Iñupiatun</option>
														<option id="Irish" value="Irish">Irish  - Gaeilge</option>
														<option id="Isthmus_Nahuatl" value="Isthmus Nahuatl">Isthmus Nahuatl  - Mela'tájtol</option>
														<option id="Italian" value="Italian">Italian  - Italiano</option>
														<option id="Japanese" value="Japanese">Japanese  - 日本語</option>
														<option id="Javanese" value="Javanese">Javanese  - ꦧꦱꦗꦮ</option>
														<option id="Judaeo-Spanish" value="Judaeo-Spanish">Judaeo-Spanish  - גֿודֿיאו-איספאנייול</option>
														<option id="Jutish" value="Jutish">Jutish  - Jydsk</option>
														<option id="J%C3%A8rriais" value="Jèrriais">Jèrriais  - Jèrriais</option>
														<option id="Kabardian" value="Kabardian">Kabardian  - Kъэбэрдеибзэ</option>
														<option id="Kabyle" value="Kabyle">Kabyle  - شئعم</option>
														<option id="Kaingang" value="Kaingang">Kaingang  - Kanhgág</option>
														<option id="Kannada" value="Kannada">Kannada  - ಕನ್ನಡ</option>
														<option id="Kanuri" value="Kanuri">Kanuri  - Kanuri</option>
														<option id="Karakalpak" value="Karakalpak">Karakalpak  - Қарақалпақ тили, Qaraqalpaq tili</option>
														<option id="Karamojong" value="Karamojong">Karamojong  - ŋaKaramojoŋ or ŋaKarimojoŋ</option>
														<option id="Karelian" value="Karelian">Karelian  - Karjalan Kieli</option>
														<option id="Kashmiri" value="Kashmiri">Kashmiri  - كٲشُر, कॉशुर, Kạ̄šur, Koshur</option>
														<option id="Kashubian" value="Kashubian">Kashubian  - Kaszëbsczi Jãzëk</option>
														<option id="Kazakh" value="Kazakh">Kazakh  - Қазақ Tілі</option>
														<option id="Kelantanese_Malay" value="Kelantanese Malay" >Kelantanese Malay  - بهاس ملايو كلنتن or Baso Kelate</option>
														<option id="Kendeje" value="Kendeje">Kendeje  - Kendeje</option>
														<option id="Khakas" value="Khakas">Khakas  - Хакас Tілі</option>
														<option id="Khmer" value="Khmer">Khmer  - ភាសាខ្មែរ</option>
														<option id="Khoekhoe" value="Khoekhoe">Khoekhoe  - Khoekhoegowab</option>
														<option id="Khowar" value="Khowar">Khowar  - کھوار</option>
														<option id="Kinyarwanda" value="Kinyarwanda">Kinyarwanda  - Ikinyarwanda or Runyarwanda</option>
														<option id="Kiribati" value="Kiribati">Kiribati  - Taetae Ni Kiribati</option>
														<option id="Klingon" value="Klingon">Klingon  - </option>
														<option id="Konkani" value="Konkani">Konkani  - कोंकणी, Konknni, കൊങ്കണി, ಕೊಂಕಣಿ</option>
														<option id="Korean" value="Korean">Korean  - 조선말, 한국어</option>
														<option id="Kuliak_s" value="Kuliak s">Kuliak  - Rub</option>
														<option id="Kumyk" value="Kumyk">Kumyk  - Къумукъ Tил</option>
														<option id="Kurdish" value="Kurdish">Kurdish  - Kurdí, کوردی, or K’öрди</option>
														<option id="Kutchi" value="Kutchi">Kutchi  - کچھی or કચ્છી</option>
														<option id="Kwadi" value="Kwadi">Kwadi † -&nbsp;!Kwa/tse</option>
														<option id="Ladakhi" value="Ladakhi">Ladakhi  - ལ་དྭགས་སྐད།</option>
														<option id="Ladin" value="Ladin">Ladin  - Ladin</option>
														<option id="Lakota" value="Lakota">Lakota  - Lakȟótiyapi</option>
														<option id="Lao" value="Lao">Lao  - ພາສາລາວ</option>
														<option id="Latin" value="Latin">Latin   - Latina</option>
														<option id="Latvian" value="Latvian">Latvian  - Latviešu</option>
														<option id="Laz" value="Laz">Laz  - ლაზური ნენა</option>
														<option id="Leonese" value="Leonese">Leonese  - Llïonés</option>
														<option id="Lepcha" value="Lepcha">Lepcha  </option>
														<option id="Limbu" value="Limbu">Limbu  - ᤕᤰᤌᤢᤱ ᤐᤠᤴ</option>
														<option id="Limburgish" value="Limburgish">Limburgish  - Lèmburgs</option>
														<option id="Lingala" value="Lingala">Lingala  - Lingála</option>
														<option id="Lisu" value="Lisu">Lisu  - ꓡꓲ-ꓢꓴ</option>
														<option id="Lithuanian" value="Lithuanian">Lithuanian  - Lietuvių</option>
														<option id="Livonian" value="Livonian">Livonian  - Līvõ Kēļ or Rāndakēļ</option>
														<option id="Low_German" value="Low German">Low German  - Plattdüütsch</option>
														<option id="Low_Prussian_dialect" value="Low Prussian dialect">Low Prussian Dialect - Niederpreußisch</option>
														<option id="Luba-Kasai" value="Luba-Kasai">Luba-Kasai  - Tshiluba</option>
														<option id="Luganda" value="Luganda">Luganda  - Luganda, LùGáànda, Oluganda</option>
														<option id="Luise%C3%B1o" value="Luiseño">Luiseño  - Cham'teela</option>
														<option id="Luo" value="Luo">Luo  - Kavirondo or Dholuo</option>
														<option id="Luri" value="Luri">Luri  - لری or Lori</option>
														<option id="Luxembourgish" value="Luxembourgish">Luxembourgish  - Lëtzebuergesch</option>
														<option id="Maasai" value="Maasai">Maasai  - ɔl Maa</option>
														<option id="Macedonian" value="Macedonian">Macedonian  - Mакедонски</option>
														<option id="Magahi" value="Magahi">Magahi  - मगही</option>
														<option id="Magar" value="Magar">Magar  - मगर भाषा</option>
														<option id="Maithili" value="Maithili">Maithili  - मैथिली, মৈথিলী</option>
														<option id="Makassarese" value="Makassarese">Makassarese  - Basa Mangkasara' or ᨅᨔ ᨆᨀᨔᨑ</option>
														<option id="Malay" value="Malay">Malay  - بهاس ملايو or Bahasa Melayu</option>
														<option id="Malayalam" value="Malayalam">Malayalam  - മലയാളം</option>
														<option id="Maltese" value="Maltese">Maltese  - Malti</option>
														<option id="Manchu" value="Manchu">Manchu  - ᠮᠠᠨᠵᡠ ᡤᡳᠰᡠᠨ</option>
														<option id="Mandarin" value="Mandarin">Mandarin  - 國語</option>
														<option id="Manx" value="Manx">Manx  – Gaelg</option>
														<option id="Marathi" value="Marathi">Marathi  - मराठी</option>
														<option id="Marshallese" value="Marshallese">Marshallese  - Ebon, Kajin M̧ajeļ, Kajin Majõl</option>
														<option id="Masalit" value="Masalit">Masalit  - kana masara</option>
														<option id="Meitei" value="Meitei">Meitei  - মনিপুরি, মৈতৈলোল্, মৈতৈলোন্, মৈথৈ</option>
														<option id="Miami-Illinois" value="Miami-Illinois">Miami-Illinois  - Myaamia</option>
														<option id="Michoac%C3%A1n_Nahuatl" value="Michoacán Nahuatl">Michoacán Nahuatl  - Pómaro Nahuatl</option>
														<option id="Min_Chinese" value="Min Chinese">Min  - 閩語 or 闽语</option>
														<option id="Min_Bei" value="Min Bei" >Min Bei  - 闽北语</option>
														<option id="Min_Dong" value="Min Dong" >Min Dong  - 閩東語</option>
														<option id="Min_Nan" value="Min Nan" >Min Nan  - 閩南語 or 闽南语</option>
														<option id="Min_Zhong" value="Min Zhong" >Min Zhong  - 闽中话</option>
														<option id="Mon" value="Mon">Mon  - <span style="font-family:'Padauk';">ဘာသာ မန်</span></option>
														<option id="Mongolian" value="Mongolian">Mongolian  - Монгол Хэл, ᠮᠣᠨᠭᠭᠣᠯ ᠬᠡᠯᠡ</option>
														<option id="Muscogee_Creek" value="Muscogee Creek">Muscogee Creek  - Mvskoke, Mvskokē</option>
														<option id="Musgu" value="Musgu">Musgu  - Mulwi</option>
														<option id="Muskum" value="Muskum">Muskum † - Muzuk</option>
														<option id="M%C4%81ori" value="Māori">Māori  – te Reo Māori</option>
														<option id="Nagumi" value="Nagumi">Nagumi † - Gong or Ngong</option>
														<option id="Nahuatl" value="Nahuatl">Nahuatl  - Māsēwallahtōlli, Mexicano, or Nāhuatlahtōlli</option>
														<option id="Navajo" value="Navajo">Navajo  – Diné bizaad</option>
														<option id="Ndyuka" value="Ndyuka">Ndyuka </option>
														<option id="Nepal_Bhasa" value="Nepal Bhasa" >Nepal Bhasa  - नेपाल भाषा</option>
														<option id="Nepali" value="Nepali">Nepali  - नेपाली</option>
														<option id="Ngbee" value="Ngbee">Ngbee † - Lingbee</option>
														<option id="Northern_Thai" value="Northern Thai">Northern Thai  - <span style="font-family:'Lanna Alif';">ᨣᩴᩤᨾᩮᩥᩬᨦ</span></option>
														<option id="Norwegian" value="Norwegian">Norwegian  - Norsk</option>
														<option id="Nuosu" value="Nuosu">Nuosu  - ꆈꌠ꒿</option>
														<option id="Nyangia" value="Nyangia">Nyangia  - Nyang'i</option>
														<option id="Occidental" value="Occidental">Occidental  - Interlingue</option>
														<option id="Occitan" value="Occitan">Occitan  - Occitan</option>
														<option id="Ojibwe" value="Ojibwe">Ojibwe  - ᐊᓂᔑᓈᐯᒧᐎᓐ</option>
														<option id="Okinawan_Japanese" value="Okinawan Japanese">Okinawan Japanese  - ウチナーヤマトゥグチ</option>
														<option id="Old_Church_Slavonic" value="Old Church Slavonic">Old Church Slavonic † - Словѣ́ньскъ Ѩзꙑ́къ or ⰔⰎⰀⰂⰑⰐⰊⰍ</option>
														<option id="Old_English" value="Old English">Old English †  - Anglisc, Ænglisc, Englisc, or ᚫᛝᛚᛁᛋᚻ</option>
														<option id="Omotik" value="Omotik">Omotik † - Laamoot</option>
														<option id="Oriya" value="Oriya">Oriya  - ଓଡ଼ିଆ</option>
														<option id="Pahari_s" value="Pahari s">Pahari  - पहाड़ी</option>
														<option id="Palula" value="Palula">Palula  - پالولہ</option>
														<option id="Pattani_Malay" value="Pattani Malay" >Pattani Malay  - بهاس جاوي, Bahasa Jawi, or ภาษายาวี</option>
														<option id="Persian" value="Persian">Persian  - فارسی</option>
														<option id="Phoenician" value="Phoenician">Phoenician</option>
														<option id="Piman_s" value="Piman s">Piman  - Tepiman</option>
														<option id="Pipil" value="Pipil">Pipil  - Náhuat or Nawat</option>
														<option id="Pitjantjatjara" value="Pitjantjatjara">Pitjantjatjara  - Pitjantjatjara</option>
														<option id="Plautdietsch" value="Plautdietsch">Plautdietsch  - Plautdietsch</option>
														<option id="Polish" value="Polish">Polish  - Język Polski, Polski, or Polszczyzna</option>
														<option id="Portuguese" value="Portuguese">Portuguese  - Português</option>
														<option id="Punjabi" value="Punjabi">Punjabi   - पंजाबी, ਪੰਜਾਬੀ, or پنجابی</option>
														<option id="Pu-Xian_Min" value="Pu-Xian Min">Pu-Xian Min  - 興化話 or 莆仙話</option>
														<option id="Raga" value="Raga">Raga  - Hano</option>
														<option id="Rajasthani" value="Rajasthani">Rajasthani  - राजस्थानी</option>
														<option id="Romani" value="Romani">Romani  - Romani Ćhib</option>
														<option id="Romanian" value="Romanian">Romanian  - Română</option>
														<option id="Romansh" value="Romansh">Romansh  - Rumantsch</option>
														<option id="Russian" value="Russian">Russian  - Русский</option>
														<option id="Rusyn" value="Rusyn">Rusyn  - Русиньский Язык, Русиньска Бесїда</option>
														<option id="Ruthenian" value="Ruthenian">Ruthenian † - Руский Языкъ</option>
														<option id="Samoan" value="Samoan">Samoan  – Gagana Sāmoa</option>
														<option id="Sanskrit" value="Sanskrit">Sanskrit  - संस्कृतम्, संस्कृता वाक्</option>
														<option id="Sardinian" value="Sardinian">Sardinian  - Sardu</option>
														<option id="Saurashtra" value="Saurashtra">Saurashtra  - <span style="font-family:'Sourashtra';">ꢱꣃꢬꢵꢰ꣄ꢜ꣄ꢬꢵ</span></option>
														<option id="Scots" value="Scots">Scots  - Scots, Scottis, Scots leid, Lallans</option>
														<option id="Scottish_Gaelic" value="Scottish Gaelic">Scottish Gaelic  - Gàidhlig</option>
														<option id="Serbian" value="Serbian">Serbian  - Српски, Srpski</option>
														<option id="Shan" value="Shan">Shan  - <span style="font-family:'Padauk';">လိၵ်ႈတႆး</span></option>
														<option id="Shanghaiese" value="Shanghaiese" >Shanghaiese  - 上海闲话</option>
														<option id="Sherpa" value="Sherpa">Sherpa   - शेर्पा, ཤེར་པཱ།</option>
														<option id="Shona" value="Shona">Shona  - Shona</option>
														<option id="Sicilian" value="Sicilian">Sicilian  - Sicilianu</option>
														<option id="Sikkimese" value="Sikkimese">Sikkimese - འབྲས་ལྗོངས་</option>
														<option id="Sindhi" value="Sindhi">Sindhi  - سنڌي</option>
														<option id="Sinhala" value="Sinhala">Sinhala  - සිංහල</option>
														<option id="Slovak" value="Slovak">Slovak  - Slovenčina</option>
														<option id="Slovene" value="Slovene">Slovene  - Slovenščina</option>
														<option id="Somali" value="Somali">Somali  - اللغة الصومالية, Af-Soomaali</option>
														<option id="Sotho" value="Sotho">Sotho  - Sesotho</option>
														<option id="Spanish" value="Spanish">Spanish  - Español</option>
														<option id="Stellingwerfs" value="Stellingwerfs">Stellingwarfs  - Stellingwerfs</option>
														<option id="Sundanese" value="Sundanese">Sundanese  - <span style="font-family:'Sundanese Unicode';">ᮘᮞ ᮞᮥᮔ᮪ᮓ</span></option>
														<option id="Swahili" value="Swahili">Swahili  – Kiswahili</option>
														<option id="Swedish" value="Swedish">Swedish  - Svenska</option>
														<option id="Swiss_German" value="Swiss German">Swiss German  - Schwyzerdütsch</option>
														<option id="Sylheti" value="Sylheti">Sylheti  - ছিলটী, সিলেটী</option>
														<option id="Tagalog" value="Tagalog">Tagalog  - <span style="font-family:'Tagalog Doctrina 1593';">ᜊᜊᜌᜒ, ᜊᜌ᜔ᜊᜌᜒᜈ᜔</span>, Wikang Tagalog</option>
														<option id="Tahitian" value="Tahitian">Tahitian  - Reo Mā'ohi, Reo Tahiti</option>
														<option id="Turkish" value="Turkish">Turkish  - Türkçe</option>
														<option id="Tai_Dam" value="Tai Dam">Tai Dam  - <span style="font-family:'Tai Heritage Pro';">ꪺꪕꪒꪾ</span></option>
														<option id="Kh%C3%BCn" value="Khün">Tai Khün  - ไทเขิน </option>
														<option id="Tai_L%C3%BC" value="Tai Lü">Tai Lü  - <span style="font-family:'Dai Banna SIL Book';">ᦑᦺᦟᦹᧉ</span> </option>
														<option id="Tai_N%C3%BCa" value="Tai Nüa">Tai Nüa  - ᥖᥭᥰᥖᥬᥳᥑᥨᥒᥰ </option>
														<option id="Tamang" value="Tamang">Tamang  - तामाङ</option>
														<option id="Tamil" value="Tamil">Tamil  - தமிழ்</option>
														<option id="Tangut" value="Tangut">Tangut  - 西夏文 </option>
														<option id="Tatar" value="Tatar">Tatar  - تاتارچا, Tatarça, Tатарча</option>
														<option id="Telugu" value="Telugu">Telugu  - తెలుగు</option>
													</select>
												</div>
												<div class="input-group">
													<span class="input-group-addon"><h4 class="pull-left" id="l1g">1). ____________</h4><button id="rel1g" onclick="removelug(1)" type="button" class="btn pull-right">&times;</button></span>
													<input type="hidden" name="lug1" id="lug1" value="">
												</div>
												<div class="input-group">
													<span class="input-group-addon"><h4 class="pull-left" id="l2g">2). ____________</h4><button id="rel2g" onclick="removelug(2)" type="button" class="btn pull-right">&times;</button></span>
													<input type="hidden" name="lug2" id="lug2" value="">
												</div>
												<div class="input-group">
													<span class="input-group-addon"><h4 class="pull-left" id="l3g">3). ____________</h4><button id="rel3g" onclick="removelug(3)" type="button" class="btn pull-right">&times;</button></span>
													<input type="hidden" name="lug3" id="lug3" value="">
												</div>
												<script>
												$("#rel1g").hide();
												$("#rel2g").hide();
												$("#rel3g").hide();
												document.getElementById('lugset').onchange = function () {
														var a = document.getElementById('lugset').value;
														if(a != 'no'){
															var a1 = document.getElementById('lug1').value;
															var a2 = document.getElementById('lug2').value;
															var a3 = document.getElementById('lug3').value;
															if(a1 == ''){
																document.getElementById('lug1').value = a;
																document.getElementById('l1g').innerHTML = '1). '+document.getElementById(a).innerHTML;
																$("#"+a).hide();
																$("#rel1g").show();
															}
															else if(a2 == ''){
																document.getElementById('lug2').value = a;
																document.getElementById('l2g').innerHTML = '2). '+document.getElementById(a).innerHTML;
																$("#"+a).hide();
																$("#rel2g").show();
															}
															else if(a3 == ''){
																document.getElementById('lug3').value = a;
																document.getElementById('l3g').innerHTML = '3). '+document.getElementById(a).innerHTML;
																$("#"+a).hide();
																$("#rel3g").show();
															}
														}
												}
												function removelug(id){
													document.getElementById('l'+id+'g').innerHTML = id+'). ____________';
													a = document.getElementById('lug'+id+'').value;
													$("#"+a).show();
													document.getElementById('lug'+id+'').value = '';
													$("#rel"+id+"g").hide();
												}
												</script>
											</div>
											<div class="box-header">
												<h3 class="box-title">Favourite Quotes</h3>
											</div>
											<div class="box-body">
												<div class="input-group">
													<span class="input-group-addon"><i class="fa fa-quote-left"></i></span>
													<input type="text" class="form-control" name="qut" id="qut" value="<?php echo $data['stet'];?>" placeholder="I am on eFeed :)">
													<span class="input-group-addon"><i class="fa fa-quote-right"></i></span>
													<button class="btn btn-default btn-flat" id="equt" type="button" onclick="onclkune('qut')">😆</button>
												</div>
												<div id="contqut"></div>
											</div>
										</div>
									</div>
									<?php } $sd = ''; if($pg){ $sd = 'style="display:none"'; } ?>
									<div class="col-lg-6" <?php echo $sd; ?>>
										<div class="box box-solid">
											<div class="box-header">
												<h3 class="box-title">Education</h3>
											</div>
											<div class="box-body">
												<div class="input-group">
												<span class="input-group-addon"><i class="fa fa-trophy"></i>
												<select name="stedu" class="fa">
													<option value="no" disabled >  Share with  </option>
													<option value="0" Selected>  Public</option>
													<option value="1">  Group</option>
													<option value="2">  Me Only</option>
												</select>
												</span>
												</div>
												<div class="input-group">
												<span class="input-group-addon"> Type </span>
												<select class="form-control" name="eduty" id="eduty">
													<option value="1" selected> Collage </option>
													<option value="2" > High School </option>
													<option value="3" > School </option>
													<option value="4" > Course </option>
												</select>
												</div>
												<div class="input-group">
												<span class="input-group-addon"> Name </span>
												<input type="text" class="form-control" name="edu" id="edu" value="" placeholder="Name of institute.">
												</div>
												<div class="input-group-addon" id="edur">
												</div>
												<input type="hidden" id="edusl" name="edusl" value="0"/>
												<script>
													$(document).ready(function(){
													$("#edur").hide();
													$("#edu").blur(function(){setTimeout(function(){$("#edur").hide();}, 3500);});
													$("#edu").keyup(function()
													{
													var search = $(this).val();var searchbox = search.trim();
													var dataString = 'searchword='+ searchbox;
													if(!searchbox.match(ch) || searchbox.match(ch2))
													{
													$("#edur").hide();
													}
													else
													{
													$.ajax({
													type: "POST",
													url: "src_s/edu.php?f=edu",
													data: dataString,
													cache: false,
													success: function(html)
													{
													$("#edur").html(html).show();
													}
													});
													}return false; 
													});
													});
												</script>
												<small id="eduex1">(ex : Engineering, BCOM, PHD, etc.)</small>
												<small id="eduex4">(ex : Computer Networking, Training, etc.)</small>
												<div class="input-group" id="eduf">
												<span class="input-group-addon"> Field </span>
												<input type="text" class="form-control" name="wedu" id="wedu"  placeholder="Field of education.">
												</div>
												<div class="input-group-addon" id="wedur">
												</div>
												<input type="hidden" id="wedusl" name="wedusl" value="0"/>
												<script>
													$(document).ready(function(){
													$("#wedur").hide();
													$("#wedu").blur(function(){setTimeout(function(){$("#wedur").hide();}, 3500);});
													$("#wedu").keyup(function()
													{
													var search = $(this).val();var searchbox = search.trim();
													var dataString = 'searchword='+ searchbox;
													if(!searchbox.match(ch) || searchbox.match(ch2))
													{
													$("#wedur").hide();
													}
													else
													{
													$.ajax({
													type: "POST",
													url: "src_s/wedu.php?f=wedu",
													data: dataString,
													cache: false,
													success: function(html)
													{
													$("#wedur").html(html).show();
													}
													});
													}return false; 
													});
													});
												</script>
												<div class="input-group">
													<span class="input-group-addon">
														<input class="icheckbox_minimal" id="gcheck" type="checkbox">  Graduated 
													</span>
												</div>
												<div class="input-group">
												<span class="input-group-addon">From :</span>
													<select name="syedu" class="form-control" id="eduyear">
														<option value="no" disabled selected>Year</option>
													</select>
													<select name="smedu"class="form-control" id="edumonth">
														<option value="no" disabled selected>Month</option>
														<option value="1">Jan</option>
														<option value="2">Feb</option>
														<option value="3">Mar</option>
														<option value="4">Apr</option>
														<option value="5">May</option>
														<option value="6">June</option>
														<option value="7">July</option>
														<option value="8">Aug</option>
														<option value="9">Sept</option>
														<option value="10">Oct</option>
														<option value="11">Nov</option>
														<option value="12">Dec</option>
													</select>
													<select name="sdedu" class="form-control" id="eduday">
														<option value="no" disabled selected>Day</option>
														<option value="1">1</option>
														<option value="2">2</option>
														<option value="3">3</option>
														<option value="4">4</option>
														<option value="5">5</option>
														<option value="6">6</option>
														<option value="7">7</option>
														<option value="8">8</option>
														<option value="9">9</option>
														<option value="10">10</option>
														<option value="11">11</option>
														<option value="12">12</option>
														<option value="13">13</option>
														<option value="14">14</option>
														<option value="15">15</option>
														<option value="16">16</option>
														<option value="17">17</option>
														<option value="18">18</option>
														<option value="19">19</option>
														<option value="20">20</option>
														<option value="21">21</option>
														<option value="22">22</option>
														<option value="23">23</option>
														<option value="24">24</option>
														<option value="25">25</option>
														<option value="26">26</option>
														<option value="27">27</option>
														<option value="28">28</option>
													</select>
													</div>
													<div class="input-group">
													<span class="input-group-addon">To :</span>
													<select name="eyedu" class="form-control" id="edueyear">
														<option value="no" disabled>Year</option>
														<option value="Present" selected>Present</option>
													</select>
													<select name="emedu" class="form-control" id="eduemonth">
													</select>
													<select name="ededu" class="form-control" id="edueday">
														<option value="no" disabled selected>Day</option>
														<option value="1">1</option>
														<option value="2">2</option>
														<option value="3">3</option>
														<option value="4">4</option>
														<option value="5">5</option>
														<option value="6">6</option>
														<option value="7">7</option>
														<option value="8">8</option>
														<option value="9">9</option>
														<option value="10">10</option>
														<option value="11">11</option>
														<option value="12">12</option>
														<option value="13">13</option>
														<option value="14">14</option>
														<option value="15">15</option>
														<option value="16">16</option>
														<option value="17">17</option>
														<option value="18">18</option>
														<option value="19">19</option>
														<option value="20">20</option>
														<option value="21">21</option>
														<option value="22">22</option>
														<option value="23">23</option>
														<option value="24">24</option>
														<option value="25">25</option>
														<option value="26">26</option>
														<option value="27">27</option>
														<option value="28">28</option>
													</select>
													<script>
													document.getElementById('eduex4').style.display = 'none';
													document.getElementById('eduty').onchange = function () {
														var a = document.getElementById('eduty').value;
														if(a == 1){
															document.getElementById('eduf').style.display = 'block';
															document.getElementById('eduex1').style.display = 'block';
															document.getElementById('eduex4').style.display = 'none';
														}
														else if(a == 4){
															document.getElementById('eduf').style.display = 'block';
															document.getElementById('eduex4').style.display = 'block';
															document.getElementById('eduex1').style.display = 'none';
														}
														else{
															document.getElementById('eduf').style.display = 'none';
															document.getElementById('eduex1').style.display = 'none';
															document.getElementById('eduex4').style.display = 'none';
														}
													}
													document.getElementById('gcheck').onchange = function () {
														var a = document.getElementById('gcheck').checked;
														if(a == true){
															var d = new Date(); var y = d.getFullYear();
															document.getElementById('edueyear').value = y;
														}
														else{
															document.getElementById('edueyear').value = 'Present';
														}
													}
													document.getElementById('eduday').style.display = 'none';
													document.getElementById('edumonth').style.display = 'none';
													document.getElementById('edueday').style.display = 'none';
													document.getElementById('eduemonth').style.display = 'none';
													var d = new Date(); var y = d.getFullYear();
													<?php 
													$bd = setssql($conn,"bdate","users","id",$_SESSION['user']['id'],0,0,0,0,0,0);
													$year = substr(strrchr($bd,'/'), 1);
													$month = substr(substr($bd, strlen(strchr($bd,'/',true))+1), 0, strpos( substr($bd, strlen(strchr($bd,'/',true))+1), '/'));
													$day = strchr($bd,'/',true);?>
													var a = <?php echo $year;?>;
													var dif = y-a;
													var i = 1;
													for(i = 1;i <= dif+1;i++)
													{
														document.getElementById('eduyear').innerHTML += '<option value="'+y+'">'+y+'</option>';
														y--;
													}
													document.getElementById('eduyear').onchange = function () {
														var a = document.getElementById('eduyear').value;
														if(a != 'no'){
														document.getElementById('edumonth').style.display = 'block';
														var b = <?php echo $year;?>;
														if(a == b){
																var c = <?php echo $month;?>;
															} else {var c = 1;}
																var m = '<option value="no" disabled selected>Month</option>';
																switch (c-1) {
																	case 0:
																		m += '<option value="1">Jan</option>';
																	case 1:
																		m += '<option value="2">Feb</option>';
																	case 2:
																		m += '<option value="3">Mar</option>';
																	case 3:
																		m += '<option value="4">Apr</option>';
																	case 4:
																		m += '<option value="5">May</option>';
																	case 5:
																		m += '<option value="6">June</option>';
																	case 6:
																		m += '<option value="7">July</option>';
																	case 7:
																		m += '<option value="8">Aug</option>';
																	case 8:
																		m += '<option value="9">Sept</option>';
																	case 9:
																		m += '<option value="10">Oct</option>';
																	case 10:
																		m += '<option value="11">Nov</option>';
																	case 11:
																		m += '<option value="12>Dec</option>';
																	case 12:
																		m += '<option value="12>Dec</option>';
																}
																document.getElementById('edumonth').innerHTML = m;
															var d = new Date(); var y = d.getFullYear();
															var a = document.getElementById('eduyear').value;
															var dif = y-a;
															var i = 1;
															for(i = 1;i <= dif+1;i++)
															{
																document.getElementById('edueyear').innerHTML += '<option value="'+y+'">'+y+'</option>';
																y--;
															}
														}
													}
													document.getElementById('edumonth').onchange = function () {
														var m = document.getElementById('edumonth').value;
														var a = <?php echo $month;?>;
														if(m != 'no'){
															document.getElementById('eduday').style.display = 'block';
															if(a != m){
																if(m == '2'){
																	if(b%4 == 0){
																		document.getElementById('eduday').innerHTML += '<option value="29">29</option>';
																	}
																}
																else if(m == '4' || m == '6' || m == '9' || m == '11'){document.getElementById('eduday').innerHTML += '<option value="29">29</option><option value="30">30</option>';}
																else{document.getElementById('eduday').innerHTML += '<option value="29">29</option><option value="30">30</option><option value="31">31</option>';}
															} else {
																if(m == '2'){
																	if(b%4 == 0){
																		var ld = 29;
																	} else { var ld = 28; }
																}
																else if(m == '4' || m == '6' || m == '9' || m == '11'){var ld = 30;}
																else{var ld = 31;}
																var i = 1;
																var d = <?php echo $day;?>;
																od = '<option value="no" disabled selected>Day</option>';
																for(i = d;i <= ld;i++){ 
																	od += '<option value="'+i+'">'+i+'</option>';
																}
																document.getElementById('eduday').innerHTML = od;
															}
														}
													}
													document.getElementById('edueyear').onchange = function () {
														var a = document.getElementById('edueyear').value;
														var b = document.getElementById('eduyear').value;
														if(a != 'no' || a != 'Present'){document.getElementById('eduemonth').style.display = 'block';
															if(a == b){
																var c = document.getElementById('edumonth').value;
															} else {var c = 1;}
																var m = '<option value="no" disabled selected>Month</option>';
																switch (c-1) {
																	case 0:
																		m += '<option value="1">Jan</option>';
																	case 1:
																		m += '<option value="2">Feb</option>';
																	case 2:
																		m += '<option value="3">Mar</option>';
																	case 3:
																		m += '<option value="4">Apr</option>';
																	case 4:
																		m += '<option value="5">May</option>';
																	case 5:
																		m += '<option value="6">June</option>';
																	case 6:
																		m += '<option value="7">July</option>';
																	case 7:
																		m += '<option value="8">Aug</option>';
																	case 8:
																		m += '<option value="9">Sept</option>';
																	case 9:
																		m += '<option value="10">Oct</option>';
																	case 10:
																		m += '<option value="11">Nov</option>';
																	case 11:
																		m += '<option value="12>Dec</option>';
																	case 12:
																		m += '<option value="12>Dec</option>';
																}
																document.getElementById('eduemonth').innerHTML = m;
														}
													}
													document.getElementById('eduemonth').onchange = function () {
														var a = document.getElementById('eduemonth').value;
														if(a != 'no'){
															document.getElementById('edueday').style.display = 'block';
															var b = document.getElementById('edueyear').value;
															var d = document.getElementById('eduday').value;
															var m = document.getElementById('edumonth').value;
															if(a != m){
																if(m == '2'){
																	if(b%4 == 0){
																		document.getElementById('edueday').innerHTML += '<option value="29">29</option>';
																	}
																}
																else if(m == '4' || m == '6' || m == '9' || m == '11'){document.getElementById('edueday').innerHTML += '<option value="29">29</option><option value="30">30</option>';}
																else{document.getElementById('edueday').innerHTML += '<option value="29">29</option><option value="30">30</option><option value="31">31</option>';}
															} else {
																if(m == '2'){
																	if(b%4 == 0){
																		var ld = 29;
																	} else { var ld = 28; }
																}
																else if(m == '4' || m == '6' || m == '9' || m == '11'){var ld = 30;}
																else{var ld = 31;}
																var i = 1;
																od = '<option value="no" disabled selected>Day</option>';
																for(i = d;i <= ld;i++){ 
																	od += '<option value="'+i+'">'+i+'</option>';
																}
																document.getElementById('edueday').innerHTML = od;
															}
														}
													}
													</script>
												</div>
											</div>
											<div class="box-header">
												<h3 class="box-title">Work</h3>
											</div>
											<div class="box-body">
												<div class="input-group">
												<span class="input-group-addon"><i class="fa fa-building-o"></i>
												<select name="stwk" class="fa">
													<option value="no" disabled >  Share with  </option>
													<option value="0" Selected>  Public</option>
													<option value="1">  Group</option>
													<option value="2">  Me Only</option>
												</select>
												</span>
												</div>
												<div class="input-group">
												<span class="input-group-addon"> Name </span>
												<input type="text" class="form-control" name="wrk" id="wrk" value="" placeholder="Where you do work.">
												</div>
												<div class="input-group-addon" id="wrkr">
												</div>
												<input type="hidden" id="wrksl" name="wrksl" value="0"/>
												<script>
													$(document).ready(function(){
													$("#wrkr").hide();
													$("#wrk").blur(function(){setTimeout(function(){$("#wrkr").hide();}, 3500);});
													$("#wrk").keyup(function()
													{
													var search = $(this).val();var searchbox = search.trim();
													var dataString = 'searchword='+ searchbox;
													if(!searchbox.match(ch) || searchbox.match(ch2))
													{
													$("#wrkr").hide();
													}
													else
													{
													$.ajax({
													type: "POST",
													url: "src_s/wrk.php?f=wrk",
													data: dataString,
													cache: false,
													success: function(html)
													{
													$("#wrkr").html(html).show();
													}
													});
													}return false; 
													});
													});
												</script>
												<div class="input-group">
												<span class="input-group-addon"> Position </span>
												<input type="text" class="form-control" name="pwrk" id="pwrk" value="" placeholder="Your Position.">
												</div>
												<div class="input-group-addon" id="pwrkr">
												</div>
												<input type="hidden" id="pwrksl" name="pwrksl" value="0"/>
												<script>
													$(document).ready(function(){
													$("#pwrkr").hide();
													$("#pwrk").blur(function(){setTimeout(function(){$("#pwrkr").hide();}, 3500);});
													$("#pwrk").keyup(function()
													{
													var search = $(this).val();var searchbox = search.trim();
													var dataString = 'searchword='+ searchbox;
													if(!searchbox.match(ch) || searchbox.match(ch2))
													{
													$("#pwrkr").hide();
													}
													else
													{
													$.ajax({
													type: "POST",
													url: "src_s/pwrk.php?f=pwrk",
													data: dataString,
													cache: false,
													success: function(html)
													{
													$("#pwrkr").html(html).show();
													}
													});
													}return false; 
													});
													});
												</script>
												<div class="input-group">
												<span class="input-group-addon"> Description </span>
												<textarea name="dwrk" class="form-control" ></textarea>
												</div>
												<div class="input-group">
												<span class="input-group-addon">From : </span>
													<select name="sywk" class="form-control" id="wkyear">
														<option value="no" disabled selected>Year</option>
													</select>
													<select name="smwk" class="form-control" id="wkmonth">
														<option value="no" disabled selected>Month</option>
														<option value="1">Jan</option>
														<option value="2">Feb</option>
														<option value="3">Mar</option>
														<option value="4">Apr</option>
														<option value="5">May</option>
														<option value="6">June</option>
														<option value="7">July</option>
														<option value="8">Aug</option>
														<option value="9">Sept</option>
														<option value="10">Oct</option>
														<option value="11">Nov</option>
														<option value="12">Dec</option>
													</select>
													<select name="sdwk" class="form-control" id="wkday">
														<option value="no" disabled selected>Day</option>
														<option value="1">1</option>
														<option value="2">2</option>
														<option value="3">3</option>
														<option value="4">4</option>
														<option value="5">5</option>
														<option value="6">6</option>
														<option value="7">7</option>
														<option value="8">8</option>
														<option value="9">9</option>
														<option value="10">10</option>
														<option value="11">11</option>
														<option value="12">12</option>
														<option value="13">13</option>
														<option value="14">14</option>
														<option value="15">15</option>
														<option value="16">16</option>
														<option value="17">17</option>
														<option value="18">18</option>
														<option value="19">19</option>
														<option value="20">20</option>
														<option value="21">21</option>
														<option value="22">22</option>
														<option value="23">23</option>
														<option value="24">24</option>
														<option value="25">25</option>
														<option value="26">26</option>
														<option value="27">27</option>
														<option value="28">28</option>
													</select>
												</div>
												<div class="input-group">
												<span class="input-group-addon">To : </span>
													<select name="eywk" class="form-control" id="wkeyear">
														<option value="no" disabled>Year</option>
														<option value="Present" selected>Present</option>
													</select>
													<select name="emwk" class="form-control" id="wkemonth">
													</select>
													<select name="edwk" class="form-control" id="wkeday">
														<option value="no" disabled selected>Day</option>
														<option value="1">1</option>
														<option value="2">2</option>
														<option value="3">3</option>
														<option value="4">4</option>
														<option value="5">5</option>
														<option value="6">6</option>
														<option value="7">7</option>
														<option value="8">8</option>
														<option value="9">9</option>
														<option value="10">10</option>
														<option value="11">11</option>
														<option value="12">12</option>
														<option value="13">13</option>
														<option value="14">14</option>
														<option value="15">15</option>
														<option value="16">16</option>
														<option value="17">17</option>
														<option value="18">18</option>
														<option value="19">19</option>
														<option value="20">20</option>
														<option value="21">21</option>
														<option value="22">22</option>
														<option value="23">23</option>
														<option value="24">24</option>
														<option value="25">25</option>
														<option value="26">26</option>
														<option value="27">27</option>
														<option value="28">28</option>
													</select>
													<script>
													document.getElementById('wkday').style.display = 'none';
													document.getElementById('wkmonth').style.display = 'none';
													document.getElementById('wkeday').style.display = 'none';
													document.getElementById('wkemonth').style.display = 'none';
													var d = new Date(); var y = d.getFullYear();
													<?php 
													$bd = setssql($conn,"bdate","users","id",$_SESSION['user']['id'],0,0,0,0,0,0);
													$year = substr(strrchr($bd,'/'), 1);
													$month = substr(substr($bd, strlen(strchr($bd,'/',true))+1), 0, strpos( substr($bd, strlen(strchr($bd,'/',true))+1), '/'));
													$day = strchr($bd,'/',true);?>
													var a = <?php echo $year;?>;
													var dif = y-a;
													var i = 1;
													for(i = 1;i <= dif+1;i++)
													{
														document.getElementById('wkyear').innerHTML += '<option value="'+y+'">'+y+'</option>';
														y--;
													}
													document.getElementById('wkyear').onchange = function () {
														var a = document.getElementById('wkyear').value;
														if(a != 'no'){
														document.getElementById('wkmonth').style.display = 'block';
														var b = <?php echo $year;?>;
														if(a == b){
																var c = <?php echo $month;?>;
															} else {var c = 1;}
																var m = '<option value="no" disabled selected>Month</option>';
																switch (c-1) {
																	case 0:
																		m += '<option value="1">Jan</option>';
																	case 1:
																		m += '<option value="2">Feb</option>';
																	case 2:
																		m += '<option value="3">Mar</option>';
																	case 3:
																		m += '<option value="4">Apr</option>';
																	case 4:
																		m += '<option value="5">May</option>';
																	case 5:
																		m += '<option value="6">June</option>';
																	case 6:
																		m += '<option value="7">July</option>';
																	case 7:
																		m += '<option value="8">Aug</option>';
																	case 8:
																		m += '<option value="9">Sept</option>';
																	case 9:
																		m += '<option value="10">Oct</option>';
																	case 10:
																		m += '<option value="11">Nov</option>';
																	case 11:
																		m += '<option value="12>Dec</option>';
																	case 12:
																		m += '<option value="12>Dec</option>';
																}
																document.getElementById('wkmonth').innerHTML = m;
															var d = new Date(); var y = d.getFullYear();
															var a = document.getElementById('wkyear').value;
															var dif = y-a;
															var i = 1;
															for(i = 1;i <= dif+1;i++)
															{
																document.getElementById('wkeyear').innerHTML += '<option value="'+y+'">'+y+'</option>';
																y--;
															}
														}
													}
													document.getElementById('wkmonth').onchange = function () {
														var m = document.getElementById('wkmonth').value;
														var a = <?php echo $month;?>;
														if(m != 'no'){
															document.getElementById('wkday').style.display = 'block';
															if(a != m){
																if(m == '2'){
																	if(b%4 == 0){
																		document.getElementById('wkday').innerHTML += '<option value="29">29</option>';
																	}
																}
																else if(m == '4' || m == '6' || m == '9' || m == '11'){document.getElementById('wkday').innerHTML += '<option value="29">29</option><option value="30">30</option>';}
																else{document.getElementById('wkday').innerHTML += '<option value="29">29</option><option value="30">30</option><option value="31">31</option>';}
															} else {
																if(m == '2'){
																	if(b%4 == 0){
																		var ld = 29;
																	} else { var ld = 28; }
																}
																else if(m == '4' || m == '6' || m == '9' || m == '11'){var ld = 30;}
																else{var ld = 31;}
																var i = 1;
																var d = <?php echo $day;?>;
																od = '<option value="no" disabled selected>Day</option>';
																for(i = d;i <= ld;i++){ 
																	od += '<option value="'+i+'">'+i+'</option>';
																}
																document.getElementById('wkday').innerHTML = od;
															}
														}
													}
													document.getElementById('wkeyear').onchange = function () {
														var a = document.getElementById('wkeyear').value;
														var b = document.getElementById('wkyear').value;
														if(a != 'no' || a != 'Present'){document.getElementById('wkemonth').style.display = 'block';
															if(a == b){
																var c = document.getElementById('wkmonth').value;
															} else {var c = 1;}
																var m = '<option value="no" disabled selected>Month</option>';
																switch (c-1) {
																	case 0:
																		m += '<option value="1">Jan</option>';
																	case 1:
																		m += '<option value="2">Feb</option>';
																	case 2:
																		m += '<option value="3">Mar</option>';
																	case 3:
																		m += '<option value="4">Apr</option>';
																	case 4:
																		m += '<option value="5">May</option>';
																	case 5:
																		m += '<option value="6">June</option>';
																	case 6:
																		m += '<option value="7">July</option>';
																	case 7:
																		m += '<option value="8">Aug</option>';
																	case 8:
																		m += '<option value="9">Sept</option>';
																	case 9:
																		m += '<option value="10">Oct</option>';
																	case 10:
																		m += '<option value="11">Nov</option>';
																	case 11:
																		m += '<option value="12>Dec</option>';
																	case 12:
																		m += '<option value="12>Dec</option>';
																}
																document.getElementById('wkemonth').innerHTML = m;
														}
													}
													document.getElementById('wkemonth').onchange = function () {
														var a = document.getElementById('wkemonth').value;
														if(a != 'no'){
															document.getElementById('wkeday').style.display = 'block';
															var b = document.getElementById('wkeyear').value;
															var d = document.getElementById('wkday').value;
															var m = document.getElementById('wkmonth').value;
															if(a != m){
																if(m == '2'){
																	if(b%4 == 0){
																		document.getElementById('wkeday').innerHTML += '<option value="29">29</option>';
																	}
																}
																else if(m == '4' || m == '6' || m == '9' || m == '11'){document.getElementById('wkeday').innerHTML += '<option value="29">29</option><option value="30">30</option>';}
																else{document.getElementById('wkeday').innerHTML += '<option value="29">29</option><option value="30">30</option><option value="31">31</option>';}
															} else {
																if(m == '2'){
																	if(b%4 == 0){
																		var ld = 29;
																	} else { var ld = 28; }
																}
																else if(m == '4' || m == '6' || m == '9' || m == '11'){var ld = 30;}
																else{var ld = 31;}
																var i = 1;
																od = '<option value="no" disabled selected>Day</option>';
																for(i = d;i <= ld;i++){ 
																	od += '<option value="'+i+'">'+i+'</option>';
																}
																document.getElementById('wkeday').innerHTML = od;
															}
														}
													}
													</script>
												</div>
											</div>
											<div class="box-header">
												<h3 class="box-title">Relationship</h3>
											</div>
											<div class="box-body">
												<div class="input-group">
													<span class="input-group-addon"><i class="fa fa-heart"></i></span>
													<select name="relty" id="relty" class="form-control">
														<option value="1" Selected> Single</option>
														<option value="2"> Married</option>
														<option value="3"> Engaged</option>
														<option value="4"> Divorced</option>
													</select>
													<select name="strl" class="fa">
														<option value="no" disabled > Share with  </option>
														<option value="0" Selected>  Public</option>
														<option value="1">  Group</option>
														<option value="2">  Me Only</option>
													</select>
												</div>
												<div id="rlname">
												<div class="input-group">
													<span class="input-group-addon">Name: </span>
													<input type="text" class="form-control" name="rlname" id="rlnames" value="" placeholder="Name of his/her.">
												</div>
												<div class="input-group-addon" id="rlnamesr">
												</div>
												<input type="hidden" id="rlnamessl" name="rlnamessl" value="0"/>
												<script>
													$(document).ready(function(){
													$("#rlnamesr").hide();
													$("#rlnames").blur(function(){setTimeout(function(){$("#rlnamesr").hide();}, 3500);});
													$("#rlnames").keyup(function()
													{
													var search = $(this).val();var searchbox = search.trim();
													var dataString = 'searchword='+ searchbox;
													if(!searchbox.match(ch) || searchbox.match(ch2))
													{
													$("#rlnamesr").hide();
													}
													else
													{
													$.ajax({
													type: "POST",
													url: "src_s/user.php?f=rlnames",
													data: dataString,
													cache: false,
													success: function(html)
													{
													$("#rlnamesr").html(html).show();
													}
													});
													}return false; 
													});
													});
													function setusr(id,f,ans,url){
														document.getElementById(f).value = ans;
														document.getElementById(f+'sl').value = id;
														$("#"+f+"r").hide();
													}
												</script>
												</div>
												<div class="input-group">
												<div id="rlda">
												<span id="rel1" >Anniversary : </span>
												<span id="rel2" >Since : </span>
													<select class="form-control" name="ryear" id="ryear">
														<option value="no" disabled selected>Year</option>
													</select>
													<select class="form-control" name="rmonth" id="rmonth">
														<option value="no" disabled selected>Month</option>
														<option value="1">Jan</option>
														<option value="2">Feb</option>
														<option value="3">Mar</option>
														<option value="4">Apr</option>
														<option value="5">May</option>
														<option value="6">June</option>
														<option value="7">July</option>
														<option value="8">Aug</option>
														<option value="9">Sept</option>
														<option value="10">Oct</option>
														<option value="11">Nov</option>
														<option value="12">Dec</option>
													</select>
													<select class="form-control" name="rday" id="rday">
														<option value="no" disabled selected>Day</option>
														<option value="1">1</option>
														<option value="2">2</option>
														<option value="3">3</option>
														<option value="4">4</option>
														<option value="5">5</option>
														<option value="6">6</option>
														<option value="7">7</option>
														<option value="8">8</option>
														<option value="9">9</option>
														<option value="10">10</option>
														<option value="11">11</option>
														<option value="12">12</option>
														<option value="13">13</option>
														<option value="14">14</option>
														<option value="15">15</option>
														<option value="16">16</option>
														<option value="17">17</option>
														<option value="18">18</option>
														<option value="19">19</option>
														<option value="20">20</option>
														<option value="21">21</option>
														<option value="22">22</option>
														<option value="23">23</option>
														<option value="24">24</option>
														<option value="25">25</option>
														<option value="26">26</option>
														<option value="27">27</option>
														<option value="28">28</option>
													</select>
												</div>
												<script>
													document.getElementById('rlname').style.display = 'none';
													document.getElementById('rlda').style.display = 'none';
													document.getElementById('rel1').style.display = 'none';
													document.getElementById('rel2').style.display = 'none';
													document.getElementById('relty').onchange = function () {
														var a = document.getElementById('relty').value;
														if(a == 2){
															document.getElementById('rlname').style.display = 'block';
															document.getElementById('rlda').style.display = 'block';
															document.getElementById('rel2').style.display = 'none';
															document.getElementById('rel1').style.display = 'block';
														}
														else if(a == 1 || a == 4){
															document.getElementById('rlname').style.display = 'none';
															document.getElementById('rlda').style.display = 'none';
															document.getElementById('rel1').style.display = 'none';
															document.getElementById('rel2').style.display = 'none';
														}
														else{
															document.getElementById('rlname').style.display = 'block';
															document.getElementById('rlda').style.display = 'block';
															document.getElementById('rel1').style.display = 'none';
															document.getElementById('rel2').style.display = 'block';
														}
													}
													document.getElementById('rday').style.display = 'none';
													document.getElementById('rmonth').style.display = 'none';
													var d = new Date(); var y = d.getFullYear();
													<?php 
													$bd = setssql($conn,"bdate","users","id",$_SESSION['user']['id'],0,0,0,0,0,0);
													$year = substr(strrchr($bd,'/'), 1);
													$month = substr(substr($bd, strlen(strchr($bd,'/',true))+1), 0, strpos( substr($bd, strlen(strchr($bd,'/',true))+1), '/'));
													$day = strchr($bd,'/',true);?>
													var a = <?php echo $year;?>;
													var dif = y-a;
													var i = 1;
													for(i = 1;i <= dif+1;i++)
													{
														document.getElementById('ryear').innerHTML += '<option value="'+y+'">'+y+'</option>';
														y--;
													}
													document.getElementById('ryear').onchange = function () {
														var a = document.getElementById('ryear').value;
														if(a != 'no'){
														document.getElementById('rmonth').style.display = 'block';
														var b = <?php echo $year;?>;
														if(a == b){
																var c = <?php echo $month;?>;
															} else {var c = 1;}
																var m = '<option value="no" disabled selected>Month</option>';
																switch (c-1) {
																	case 0:
																		m += '<option value="1">Jan</option>';
																	case 1:
																		m += '<option value="2">Feb</option>';
																	case 2:
																		m += '<option value="3">Mar</option>';
																	case 3:
																		m += '<option value="4">Apr</option>';
																	case 4:
																		m += '<option value="5">May</option>';
																	case 5:
																		m += '<option value="6">June</option>';
																	case 6:
																		m += '<option value="7">July</option>';
																	case 7:
																		m += '<option value="8">Aug</option>';
																	case 8:
																		m += '<option value="9">Sept</option>';
																	case 9:
																		m += '<option value="10">Oct</option>';
																	case 10:
																		m += '<option value="11">Nov</option>';
																	case 11:
																		m += '<option value="12>Dec</option>';
																	case 12:
																		m += '<option value="12>Dec</option>';
																}
																document.getElementById('rmonth').innerHTML = m;
														}
													}
													document.getElementById('rmonth').onchange = function () {
														var m = document.getElementById('rmonth').value;
														var a = <?php echo $month;?>;
														if(m != 'no'){
															document.getElementById('rday').style.display = 'block';
															if(a != m){
																if(m == '2'){
																	if(b%4 == 0){
																		document.getElementById('rday').innerHTML += '<option value="29">29</option>';
																	}
																}
																else if(m == '4' || m == '6' || m == '9' || m == '11'){document.getElementById('rday').innerHTML += '<option value="29">29</option><option value="30">30</option>';}
																else{document.getElementById('rday').innerHTML += '<option value="29">29</option><option value="30">30</option><option value="31">31</option>';}
															} else {
																if(m == '2'){
																	if(b%4 == 0){
																		var ld = 29;
																	} else { var ld = 28; }
																}
																else if(m == '4' || m == '6' || m == '9' || m == '11'){var ld = 30;}
																else{var ld = 31;}
																var i = 1;
																var d = <?php echo $day;?>;
																od = '<option value="no" disabled selected>Day</option>';
																for(i = d;i <= ld;i++){ 
																	od += '<option value="'+i+'">'+i+'</option>';
																}
																document.getElementById('rday').innerHTML = od;
															}
														}
													}
													</script>
												</div>
											</div>
										</div>
									</div>
								</div>
								<div class="box box-solid box-footer">
									<button class="pull-right btn btn-primary btn-flat" type="submit"> Next <i class="fa fa-arrow-right"></i></button>
								</div>
							</form>	
						
                        </section>

					</div>
					
				</section>
				
            </aside>
			
        </div>
		<footer class="footer">
			<div align="center" style="border-top: 2px solid #f1f1f1">
			<a href="index.php"> Home </a> - <a href="eFeed/index.html"> About </a> - <a href="legal/terms/index.html"> Terms </a> - <a href="about/privacy/index.html"> Privacy </a> - <a href="help/index.html"> Help </a> - <a href="about/privacy/cookies/index.html"> Cookies </a><br/>
			 eFeed © 2015 (English (US))
			</div>
        </footer>

		
<!-- ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ -->

													<!-- Show clear -->

<!-- ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ -->


        <!-- jQuery 2.0.2 -->
        <script src="http://ajax.googleapis.com/ajax/libs/jquery/2.0.2/jquery.min.js"></script>
		<script type="text/javascript" src="js/jquery-1.11.2.min.js"></script>
		<script type='text/javascript' src='met/js/jquery-1.10.1.js'></script>
        <script src="met/js/jquery-ui-1.10.3.min.js" type="text/javascript"></script>
        <script src="met/js/bootstrap.min.js" type="text/javascript"></script>
        <script src="met/js/plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.all.min.js" type="text/javascript"></script>


	
    </body>
</html>