<?php
	if(isset($_GET['f'])){
		unlink($_GET['f'].".sql");unlink($_GET['f']."sql");
	}
?>